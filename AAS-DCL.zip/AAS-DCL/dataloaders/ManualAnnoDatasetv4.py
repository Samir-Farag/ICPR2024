"""
Dataset for training with pseudolabels
TODO:
1. Merge with manual annotated dataset
2. superpixel_scale -> superpix_config, feed like a dict
"""
import glob
import numpy as np
import dataloaders.augutils as myaug
import torch
import random
import os
import copy
import platform
import json
import re
from dataloaders.common import BaseDataset, Subset
from dataloaders.dataset_utils import*
from pdb import set_trace
from utils.util import CircularList

import matplotlib.pyplot as plt


def plot_images(ims, fgs, bgs=[None,None,None], w=0.001):

    n = len(ims)
    k = 0
    # plt.axis([0, 255, 0, 255])
    plt.ion()
    plt.show()
    for im, fg, bg in zip(ims, fgs, bgs):

        if torch.is_tensor(im):        
            im = im.squeeze().permute((1,2,0))
            fg = fg.squeeze().cpu().numpy()
            im= im.cpu().numpy()
        else:
            im = im.squeeze()
            fg = fg.squeeze()
             
        # if bg is None:        
        #     plt.subplot(n,2,1+k), plt.imshow(img, cmap='gray')
        #     plt.subplot(n,2,2+k), plt.imshow(fg)
        #     k+=2
        # else:
        #     bg = bg[0].squeeze().cpu().numpy()
        #     plt.subplot(n,3,1+k), plt.imshow(img, cmap='gray')
        #     plt.subplot(n,3,2+k), plt.imshow(fg)
        #     plt.subplot(n,3,3+k), plt.imshow(bg)
        #     k += 3

        if bg is None:        
            bg = 1-fg

        else:
            if torch.is_tensor(bg):  
                bg = bg.squeeze().cpu().numpy()
            else:
                bg = bg.squeeze()

       
        plt.subplot(n,3,1+k), plt.imshow(im, cmap='gray')
        plt.subplot(n,3,2+k), plt.imshow(fg)
        plt.subplot(n,3,3+k), plt.imshow(bg)
        k += 3

    plt.draw()
    plt.pause(w)
class ManualAnnoDataset(BaseDataset):
    def __init__(self, which_dataset, base_dir, idx_split, mode, transforms, scan_per_load, num_rep = 2, min_fg = '', nsup = 1, fix_length = None, tile_z_dim = 3, exclude_list = [], superpix_scale = 'SMALL', **kwargs):
        """
        Pseudolabel dataset
        Args:
            which_dataset:      name of the dataset to use
            base_dir:           directory of dataset
            idx_split:          index of data split as we will do cross validation
            mode:               'train', 'val'. 
            nsup:               number of scans used as support. currently idle for superpixel dataset
            transforms:         data transform (augmentation) function
            scan_per_load:      loading a portion of the entire dataset, in case that the dataset is too large to fit into the memory. Set to -1 if loading the entire dataset at one time
            num_rep:            Number of augmentation applied for a same pseudolabel
            tile_z_dim:         number of identical slices to tile along channel dimension, for fitting 2D single-channel medical images into off-the-shelf networks designed for RGB natural images
            fix_length:         fix the length of dataset
            exclude_list:       Labels to be excluded
            superpix_scale:     config of superpixels
        """
        super(ManualAnnoDataset, self).__init__(base_dir)

        self.img_modality = DATASET_INFO[which_dataset]['MODALITY']
        self.sep = DATASET_INFO[which_dataset]['_SEP']
        self.pseu_label_name = DATASET_INFO[which_dataset]['PSEU_LABEL_NAME']
        self.real_label_name = DATASET_INFO[which_dataset]['REAL_LABEL_NAME']
        self.train_labels = DATASET_INFO[which_dataset]['LABEL_GROUP']['pa_all'] - set(exclude_list)
        self.transforms = transforms
        self.is_train = True if mode == 'train' else False
        # assert mode == 'train'
        self.fix_length = fix_length
        self.nclass = len(self.pseu_label_name)
        self.num_rep = num_rep
        self.tile_z_dim = tile_z_dim

        # find scans in the data folder
        self.nsup = nsup
        self.base_dir = base_dir
        self.img_pids = [ re.findall('\d+', fid)[-1] for fid in glob.glob(self.base_dir + "/image_*.nii.gz") ]
        self.img_pids = CircularList(sorted( self.img_pids, key = lambda x: int(x)))

        # experiment configs
        self.exclude_lbs = exclude_list
        self.superpix_scale = superpix_scale
        if len(exclude_list) > 0:
            print(f'###### Dataset: the following classes has been excluded {exclude_list}######')
        self.idx_split = idx_split
        self.scan_ids = self.get_scanids(mode, idx_split) # patient ids of the entire fold
        self.min_fg = min_fg if isinstance(min_fg, str) else str(min_fg)
        self.scan_per_load = scan_per_load

        self.info_by_scan = None
        self.img_lb_fids = self.organize_sample_fids() # information of scans of the entire fold
        self.norm_func = get_normalize_op(self.img_modality, [ fid_pair['img_fid'] for _, fid_pair in self.img_lb_fids.items()])

        if self.is_train:
            if scan_per_load > 0: # if the dataset is too large, only reload a subset in each sub-epoch
                self.pid_curr_load = np.random.choice( self.scan_ids, replace = False, size = self.scan_per_load)
            else: # load the entire set without a buffer
                self.pid_curr_load = self.scan_ids
        elif mode == 'val':
            self.pid_curr_load = self.scan_ids
        else:
            raise Exception
        self.actual_dataset = self.read_dataset()
        self.size = len(self.actual_dataset)
        self.overall_slice_by_cls = self.read_classfiles()

        print("###### Initial scans loaded: ######")
        print(self.pid_curr_load)

    def get_scanids(self, mode, idx_split):
        """
        Load scans by train-test split
        leaving one additional scan as the support scan. if the last fold, taking scan 0 as the additional one
        Args:
            idx_split: index for spliting cross-validation folds
        """
        val_ids  = copy.deepcopy(self.img_pids[self.sep[idx_split]: self.sep[idx_split + 1] + self.nsup])
        if mode == 'train':
            return [ ii for ii in self.img_pids if ii not in val_ids ]
        elif mode == 'val':
            return val_ids

    def reload_buffer(self):
        """
        Reload a only portion of the entire dataset, if the dataset is too large
        1. delete original buffer
        2. update self.ids_this_batch
        3. update other internel variables like __len__
        """
        if self.scan_per_load <= 0:
            print("We are not using the reload buffer, doing notiong")
            return -1

        del self.actual_dataset
        del self.info_by_scan

        self.pid_curr_load = np.random.choice( self.scan_ids, size = self.scan_per_load, replace = False )
        self.actual_dataset = self.read_dataset()
        self.size = len(self.actual_dataset)
        self.update_subclass_lookup()
        print(f'Loader buffer reloaded with a new size of {self.size} slices')

    def organize_sample_fids(self):
        out_list = {}
        for curr_id in self.scan_ids:
            curr_dict = {}

            _img_fid = os.path.join(self.base_dir, f'image_{curr_id}.nii.gz')
            _lb_fid  = os.path.join(self.base_dir, f'label_{curr_id}.nii.gz')

            if int(curr_id) < 30:
                _sprlb_fid  = os.path.join(self.base_dir, f'superpix-{self.superpix_scale}_{curr_id}.nii.gz')
            else:
                _sprlb_fid  = os.path.join(self.base_dir, f'dlabel_{curr_id}.nii.gz')


            curr_dict["img_fid"] = _img_fid
            curr_dict["lbs_fid"] = _lb_fid
            curr_dict["sprlbs_fid"] = _sprlb_fid

            out_list[str(curr_id)] = curr_dict
        return out_list

    def read_dataset(self):
        """
        Read images into memory and store them in 2D
        Build tables for the position of an individual 2D slice in the entire dataset
        """
        out_list = []
        self.scan_z_idx = {}
        self.info_by_scan = {} # meta data of each scan
        glb_idx = 0 # global index of a certain slice in a certain scan in entire dataset

        for scan_id, itm in self.img_lb_fids.items():
            if scan_id not in self.pid_curr_load:
                continue

            img, _info = read_nii_bysitk(itm["img_fid"], peel_info = True) # get the meta information out
            img = img.transpose(1,2,0)
            self.info_by_scan[scan_id] = _info

            img = np.float32(img)
            img = self.norm_func(img)

            self.scan_z_idx[scan_id] = [-1 for _ in range(img.shape[-1])]

            lb = read_nii_bysitk(itm["lbs_fid"])
            lb = lb.transpose(1,2,0)
            lb = np.int32(lb)


            sprlb = read_nii_bysitk(itm["sprlbs_fid"])
            sprlb = sprlb.transpose(1,2,0)
            sprlb = np.int32(sprlb)


            img = img[:256, :256, :]
            lb = lb[:256, :256, :]
            sprlb = sprlb[:256, :256, :]

            # format of slices: [axial_H x axial_W x Z]

            assert img.shape[-1] == lb.shape[-1]
            base_idx = img.shape[-1] // 2 # index of the middle slice

            # re-organize 3D images into 2D slices and record essential information for each slice
            out_list.append( {"img": img[..., 0: 1],
                           "lb":lb[..., 0: 0 + 1],
                           "sprlb":sprlb[..., 0: 0 + 1],
                           "is_start": True,
                           "is_end": False,
                           "nframe": img.shape[-1],
                           "scan_id": scan_id,
                           "z_id":0})

            self.scan_z_idx[scan_id][0] = glb_idx
            glb_idx += 1

            for ii in range(1, img.shape[-1] - 1):
                out_list.append( {"img": img[..., ii: ii + 1],
                           "lb":lb[..., ii: ii + 1],
                           "sprlb":sprlb[..., ii: ii + 1],
                           "is_start": False,
                           "is_end": False,
                           "nframe": -1,
                           "scan_id": scan_id,
                           "z_id": ii
                           })
                self.scan_z_idx[scan_id][ii] = glb_idx
                glb_idx += 1

            ii += 1 # last slice of a 3D volume
            out_list.append( {"img": img[..., ii: ii + 1],
                           "lb":lb[..., ii: ii+ 1],
                           "sprlb":sprlb[..., ii: ii+ 1],
                           "is_start": False,
                           "is_end": True,
                           "nframe": -1,
                           "scan_id": scan_id,
                           "z_id": ii
                           })

            self.scan_z_idx[scan_id][ii] = glb_idx
            glb_idx += 1

        return out_list

    def read_classfiles(self):
        """
        Load the scan-slice-class indexing file
        """
        with open(   os.path.join(self.base_dir, f'classmap_{self.min_fg}.json') , 'r' ) as fopen:
            cls_map =  json.load( fopen)
            fopen.close()

        with open(   os.path.join(self.base_dir, 'classmap_1.json') , 'r' ) as fopen:
            self.tp1_cls_map =  json.load( fopen)
            fopen.close()

        return cls_map

    def get_label(self, super_map):
        lbls = set(np.unique(super_map)[1:]) - set(self.exclude_lbs)    # do not chose background 0 nor the test organs  
        lbls = self.train_labels  & lbls
        if bool(lbls):
            lbl = np.random.choice(list(lbls), size=1)[0]
        else:
            lbl = 0 
        return lbl
    

    def supcls_pick_binarize(self, super_map, bi_val = None):
        """
        pick up a certain super-pixel class or multiple classes, and binarize it into segmentation target
        Args:
            super_map:      super-pixel map
            bi_val:         if given, pick up a certain superpixel. Otherwise, draw a random one
            sup_max_cls:    max index of superpixel for avoiding overshooting when selecting superpixel

        """
        
        if bi_val == None:
            bi_val = self.get_label(self, super_map)    

        return np.float32(super_map == bi_val), bi_val
    
    def get_neighbors(self, zid, n=2):
        neighbors =[]
        for i in range(-n,n+1):
            neighbors.append(zid+i)

        neighbors.remove(zid)

        return neighbors

        
    def get_query(self, lbl, curr_dict):
        curr_slices = self.tp1_cls_map[self.real_label_name[lbl]][curr_dict["scan_id"]]
        zid = curr_dict['z_id']
        neighbors = self.get_neighbors(zid)
        cand_slice = set(neighbors) & set(curr_slices)
        q_zid = np.random.choice(list(cand_slice), size=1)[0]
        all_scans = np.array([d.get("scan_id") for d in self.actual_dataset])
        ind = np.where(all_scans == curr_dict["scan_id"])
        candidates = np.array(self.actual_dataset)[ind]  # slices in current scan       
        
        return candidates[q_zid]
        

    def get_nonTarget(self, lbl, curr_dict):

        curr_slices = self.tp1_cls_map[self.real_label_name[lbl]][curr_dict["scan_id"]]
        all_scans = np.array([d.get("scan_id") for d in self.actual_dataset])
        ind = np.where(all_scans == curr_dict["scan_id"])
        candidates = np.array(self.actual_dataset)[ind]  # slices in current scan
                
        lbls = self.train_labels - set([lbl])
        K = 3
        k = 0
        i = 0
        non_slices=[]
        non_lbls=[]
        typ=[]
        while (k < K) & (i<1000):
            lb = np.random.choice(list(lbls), size=1)[0]
            all_scans = self.tp1_cls_map[self.real_label_name[lb]]
            
            # tst_slices = self.tp1_cls_map[self.real_label_name[self.exclude_lbs[0]]][curr_dict["scan_id"]]
            
            if curr_dict["scan_id"] in all_scans.keys():
                k += 1
                q_slices = all_scans[curr_dict["scan_id"]]
                dif_slices = set(q_slices)-set(curr_slices)
                if bool(dif_slices):
                    non_lbls.append(lb)
                    q_slice = np.random.choice(list(dif_slices), size=1)[0]
                    # z_ids = np.array([d.get("z_id") for d in candidates])
                    # ind = np.where(z_ids == q_slice)support_images
                    non_slices.append(candidates[q_slice])
                    typ.append('lb')
                else:
                    i += 1

        if len(non_slices)<3:
            slc_ind = np.linspace(0,len(candidates)-1,len(candidates)).astype('int')
            dif_slices = set(slc_ind) - set(curr_slices)
            slc_id = np.random.choice(list(dif_slices), size=K-len(non_slices))
            for itm in candidates[slc_id]:
                non_slices.append(itm)
            
            for i in range(K-len(slc_id),K):
                sprlbl = non_slices[i]['sprlb']
                non_lbls.append(sprlbl.max())
                typ.append('sprlb')

        
        return non_slices, non_lbls, typ

    def get_intial_label(self, spr, lbl, curr_label):
        spr = spr.squeeze()
        if curr_label == 14:
            return spr==curr_label
        msk = lbl.squeeze()==curr_label
        msk = msk.astype('int')
        tmp = np.multiply(spr,msk)
        lbls, cnts = np.unique(tmp, return_counts=True)    
        if len(lbls)>1:  # avoid bkg
            id = np.argsort(cnts)
            msk = tmp==lbls[id[-2]]

        return msk
    def __getitem_ORG__(self, index):
        index = index % len(self.actual_dataset)
        curr_dict = self.actual_dataset[index]
        
        image_t = curr_dict["img"]        
        label_raw = curr_dict["lb"]
      
 
        for _ex_cls in self.exclude_lbs:
            if curr_dict["z_id"] in self.tp1_cls_map[self.real_label_name[_ex_cls]][curr_dict["scan_id"]]: # if using setting 1, this slice need to be excluded since it contains label which is supposed to be unseen
                return self.__getitem__(torch.randint(low = 0, high = self.__len__() - 1, size = (1,)))

        
        lbl = self.get_label(label_raw)
        if not bool(lbl):
            return self.__getitem__(torch.randint(low = 0, high = self.__len__() - 1, size = (1,)))

        label_t, lbl = self.supcls_pick_binarize(label_raw, bi_val=lbl)

        # print('--=========================',self.real_label_name[lbl],'--=========================\n',)

        non_slices, non_lbls, typ = self.get_nonTarget(lbl, curr_dict)

        non_imgs = []
        non_labels = []
        labels_titles=[]
        for ii in range(len(non_lbls)):
            label_i, _ = self.supcls_pick_binarize(non_slices[ii][typ[ii]], bi_val=non_lbls[ii])
            
            img = non_slices[ii]["img"]
            img = torch.from_numpy( np.transpose( img, (2, 0, 1)) )
            lb  = torch.from_numpy( label_i.squeeze(-1))
            if self.tile_z_dim:
                img = img.repeat( [ self.tile_z_dim, 1, 1] )
                assert img.ndimension() == 3, f'actual dim {img.ndimension()}'

            non_imgs.append(img)
            non_labels.append(lb)

            if typ[ii]=='lb':
                labels_titles.append(self.real_label_name[non_lbls[ii]])
            else:
                labels_titles.append('super pixels')

        

        # print(non_lbls,labels_titles )
        # import matplotlib.pyplot as plt
        # plt.subplot(2,4,1), plt.imshow(image_t, cmap='gray'), plt.title(str(lbl) +':'+ self.real_label_name[lbl])
        # plt.subplot(2,4,5), plt.imshow(label_t)

        # plt.subplot(2,4,2), plt.imshow(non_imgs[0], cmap='gray'), plt.title(str(non_lbls[0]) +':'+labels_titles[0] )
        # plt.subplot(2,4,6), plt.imshow(non_labels[0])

        # plt.subplot(2,4,3), plt.imshow(non_imgs[1], cmap='gray'), plt.title(str(non_lbls[1]) +':'+labels_titles[1])
        # plt.subplot(2,4,7), plt.imshow(non_labels[1])

        # plt.subplot(2,4,4), plt.imshow(non_imgs[2], cmap='gray'), plt.title(str(non_lbls[2]) +':'+labels_titles[2])
        # plt.subplot(2,4,8), plt.imshow(non_labels[2])
        # plt.show()

        pair_buffer = []

        comp = np.concatenate( [curr_dict["img"], label_t], axis = -1 )

        for ii in range(self.num_rep):
            img, lb = self.transforms(comp, c_img = 1, c_label = 1, nclass = self.nclass,  is_train = True, use_onehot = False)

            img = torch.from_numpy( np.transpose( img, (2, 0, 1)) )
            lb  = torch.from_numpy( lb.squeeze(-1))

            if self.tile_z_dim:
                img = img.repeat( [ self.tile_z_dim, 1, 1] )
                assert img.ndimension() == 3, f'actual dim {img.ndimension()}'

            is_start = curr_dict["is_start"]
            is_end = curr_dict["is_end"]
            nframe = np.int32(curr_dict["nframe"])
            scan_id = curr_dict["scan_id"]
            z_id    = curr_dict["z_id"]

            sample = {"image": img,
                    "label":lb,
                    "is_start": is_start,
                    "is_end": is_end,
                    "nframe": nframe,
                    "scan_id": scan_id,
                    "z_id": z_id
                    }

            # Add auxiliary attributes
            if self.aux_attrib is not None:
                for key_prefix in self.aux_attrib:
                    # Process the data sample, create new attributes and save them in a dictionary
                    aux_attrib_val = self.aux_attrib[key_prefix](sample, **self.aux_attrib_args[key_prefix])
                    for key_suffix in aux_attrib_val:
                        # one function may create multiple attributes, so we need suffix to distinguish them
                        sample[key_prefix + '_' + key_suffix] = aux_attrib_val[key_suffix]
            pair_buffer.append(sample)

        support_images = []
        support_mask = []
        support_class = []

        query_images = []
        query_labels = []
        query_class = []

        for idx, itm in enumerate(pair_buffer):
            if idx % 2 == 0:
                support_images.append(itm["image"])
                support_class.append(lbl) # pseudolabel class
                support_mask.append(  self.getMaskMedImg( itm["label"], 1, [1]  ))
            else:
                query_images.append(itm["image"])
                query_class.append(lbl)
                query_labels.append(  itm["label"])

        return {'class_ids': [support_class],
            'support_images': [support_images], #
            'support_labels': [support_mask],
            'query_images': query_images, #
            'query_labels': query_labels,
            'nontrgt_images': non_imgs,
            'nontrgt_labels': non_labels,
            'nontrgt_ids': labels_titles,
        }

    def __getitem__(self, index):
        index = index % len(self.actual_dataset)
        curr_dict = self.actual_dataset[index]
        
        image_t = curr_dict["img"]        
        label_raw = curr_dict["lb"]
        label_spr = curr_dict["sprlb"]
      
 
        for _ex_cls in self.exclude_lbs:
            if not curr_dict["z_id"] in self.tp1_cls_map[self.real_label_name[_ex_cls]][curr_dict["scan_id"]]: # if using setting 1, this slice need to be excluded since it contains label which is supposed to be unseen
                return self.__getitem__(torch.randint(low = 0, high = self.__len__() - 1, size = (1,)))

        
        lbl =  np.random.choice(self.exclude_lbs, size=1)[0]

        # print('--=========================',self.real_label_name[lbl],'--=========================\n',)

        non_slices, non_lbls, typ = self.get_nonTarget(lbl, curr_dict)

        non_imgs = []
        non_labels = []
        labels_titles=[]
        for ii in range(len(non_lbls)):
            label_i, _ = self.supcls_pick_binarize(non_slices[ii][typ[ii]], bi_val=non_lbls[ii])
            
            img = non_slices[ii]["img"]
            img = torch.from_numpy( np.transpose( img, (2, 0, 1)) )
            lb  = torch.from_numpy( label_i.squeeze(-1))
            if self.tile_z_dim:
                img = img.repeat( [ self.tile_z_dim, 1, 1] )
                assert img.ndimension() == 3, f'actual dim {img.ndimension()}'

            non_imgs.append(img)
            non_labels.append(lb)

            if typ[ii]=='lb':
                labels_titles.append(self.real_label_name[non_lbls[ii]])
            else:
                labels_titles.append('super pixels')

        

        # print(non_lbls,labels_titles )
        # import matplotlib.pyplot as plt
        # plt.subplot(2,4,1), plt.imshow(image_t, cmap='gray'), plt.title(str(lbl) +':'+ self.real_label_name[lbl])
        # plt.subplot(2,4,5), plt.imshow(label_t)

        # plt.subplot(2,4,2), plt.imshow(non_imgs[0], cmap='gray'), plt.title(str(non_lbls[0]) +':'+labels_titles[0] )
        # plt.subplot(2,4,6), plt.imshow(non_labels[0])

        # plt.subplot(2,4,3), plt.imshow(non_imgs[1], cmap='gray'), plt.title(str(non_lbls[1]) +':'+labels_titles[1])
        # plt.subplot(2,4,7), plt.imshow(non_labels[1])

        # plt.subplot(2,4,4), plt.imshow(non_imgs[2], cmap='gray'), plt.title(str(non_lbls[2]) +':'+labels_titles[2])
        # plt.subplot(2,4,8), plt.imshow(non_labels[2])
        # plt.show()

        pair_buffer = []     
      
        q_dict= self.get_query(lbl, curr_dict)
        sup_qry = [[image_t, label_raw, label_spr],[q_dict['img'], q_dict['lb'], q_dict["sprlb"]]]
        
        for idx, itm in enumerate(sup_qry):
            img = itm[0]
            msk = itm[1]
            spr_msk = itm[2]
            ini_lbl = self.get_intial_label(spr_msk, msk, lbl)
            msk, _ = self.supcls_pick_binarize(msk.squeeze(), bi_val=lbl)

            img = torch.from_numpy( np.transpose( img, (2, 0, 1)) )
            msk  = torch.from_numpy(msk)
            ini_lbl  = torch.from_numpy(ini_lbl)

            if self.tile_z_dim:
                img = img.repeat( [ self.tile_z_dim, 1, 1] )
                assert img.ndimension() == 3, f'actual dim {img.ndimension()}'
            if idx % 2 == 0:
                is_start = curr_dict["is_start"]
                is_end = curr_dict["is_end"]
                nframe = np.int32(curr_dict["nframe"])
                scan_id = curr_dict["scan_id"]
                z_id    = curr_dict["z_id"]
            else:
                is_start = q_dict["is_start"]
                is_end = q_dict["is_end"]
                nframe = np.int32(q_dict["nframe"])
                scan_id = q_dict["scan_id"]
                z_id    = q_dict["z_id"]


            sample = {"image": img,
                    "label":msk,
                    "inilabel":ini_lbl,
                    "is_start": is_start,
                    "is_end": is_end,
                    "nframe": nframe,
                    "scan_id": scan_id,
                    "z_id": z_id
                    }

            # Add auxiliary attributes
            if self.aux_attrib is not None:
                for key_prefix in self.aux_attrib:
                    # Process the data sample, create new attributes and save them in a dictionary
                    aux_attrib_val = self.aux_attrib[key_prefix](sample, **self.aux_attrib_args[key_prefix])
                    for key_suffix in aux_attrib_val:
                        # one function may create multiple attributes, so we need suffix to distinguish them
                        sample[key_prefix + '_' + key_suffix] = aux_attrib_val[key_suffix]
            pair_buffer.append(sample)


        support_images = []
        support_mask = []
        support_class = []

        query_images = []
        query_labels = []
        query_inilabels = []
        query_class = []

        for idx, itm in enumerate(pair_buffer):
            if idx % 2 == 0:
                support_images.append(itm["image"])
                support_class.append(lbl) # pseudolabel class
                support_mask.append(  self.getMaskMedImg( itm["label"], 1, [1]  ))
            else:
                query_images.append(itm["image"])
                query_class.append(lbl)
                query_labels.append(  itm["label"])
                query_inilabels.append(  itm["inilabel"])

        return {'class_ids': [support_class],
            'support_images': [support_images], #
            'support_labels': [support_mask],
            'query_images': query_images, #
            'query_labels': query_labels,
            'query_inilabels': query_inilabels,
            'nontrgt_images': non_imgs,
            'nontrgt_labels': non_labels,
            'nontrgt_ids': labels_titles,
            'curr_scan': curr_dict["scan_id"],
        }


    def __len__(self):
        """
        copy-paste from basic naive dataset configuration
        """
        if self.fix_length != None:
            assert self.fix_length >= len(self.actual_dataset)
            return self.fix_length
        else:
            return len(self.actual_dataset)

    def getMaskMedImg(self, label, class_id, class_ids):
        """
        Generate FG/BG mask from the segmentation mask

        Args:
            label:          semantic mask
            class_id:       semantic class of interest
            class_ids:      all class id in this episode
        """
        fg_mask = torch.where(label == class_id,
                              torch.ones_like(label), torch.zeros_like(label))
        bg_mask = torch.where(label != class_id,
                              torch.ones_like(label), torch.zeros_like(label))
        for class_id in class_ids:
            bg_mask[label == class_id] = 0

        # return {'fg_mask': fg_mask,
        #         'bg_mask': bg_mask}
        return fg_mask.float()

    def subsets(self, sub_args_lst=None):
        """
        Override base-class subset method
        Create subsets by scan_ids

        output: list [[<fid in each class>] <class1>, <class2>     ]
        """

        if sub_args_lst is not None:
            subsets = []
            ii = 0
            for cls_name, index_list in self.idx_by_class.items():
                subsets.append( Subset(dataset = self, indices = index_list, sub_attrib_args = sub_args_lst[ii])  )
                ii += 1
        else:
            subsets = [Subset(dataset=self, indices=index_list) for _, index_list in self.idx_by_class.items()]
        return subsets

    def get_support(self, curr_class: int, class_idx: list, scan_idx: list, npart: int):
        """
        getting (probably multi-shot) support set for evaluation
        sample from 50% (1shot) or 20 35 50 65 80 (5shot)
        Args:
            curr_cls:       current class to segment, starts from 1
            class_idx:      a list of all foreground class in nways, starts from 1
            npart:          how may chunks used to split the support
            scan_idx:       a list, indicating the current **i_th** (note this is idx not pid) training scan
        being served as support, in self.pid_curr_load
        """
        assert npart % 2 == 1
        assert curr_class != 0; assert 0 not in class_idx
        assert not self.is_train

        self.potential_support_sid = [self.pid_curr_load[ii] for ii in scan_idx ]
        print(f'###### Using {len(scan_idx)} shot evaluation!')

        if npart == 1:
            pcts = [0.5]
        else:
            half_part = 1 / (npart * 2)
            part_interval = (1.0 - 1.0 / npart) / (npart - 1)
            pcts = [ half_part + part_interval * ii for ii in range(npart) ]

        print(f'###### Parts percentage: {pcts} ######')

        out_buffer = [] # [{scanid, img, lb}]
        for _part in range(npart):
            concat_buffer = [] # for each fold do a concat in image and mask in batch dimension
            for scan_order in scan_idx:
                _scan_id = self.pid_curr_load[ scan_order ]
                print(f'Using scan {_scan_id} as support!')

                # for _pc in pcts:
                _zlist = self.tp1_cls_map[self.real_label_name[curr_class]][_scan_id] # list of indices
                _zid = _zlist[int(pcts[_part] * len(_zlist))]
                _glb_idx = self.scan_z_idx[_scan_id][_zid]

                # almost copy-paste __getitem__ but no augmentation
                curr_dict = self.actual_dataset[_glb_idx]
                img = curr_dict['img']
                label_raw = curr_dict['lb']

                img = np.float32(img)
                lb = np.float32(label_raw).squeeze(-1) # NOTE: to be suitable for the PANet structure
                lb = label_raw.squeeze(-1) 
                lb, _ = self.supcls_pick_binarize(lb, bi_val=curr_class)


                img = torch.from_numpy( np.transpose(img, (2, 0, 1)) )
                slb  = torch.from_numpy( lb )

                if self.tile_z_dim:
                    simg = img.repeat( [ self.tile_z_dim, 1, 1] )
                    assert simg.ndimension() == 3, f'actual dim {simg.ndimension()}'
                        
                
                # plot_images([simg], [slb], w = 5)

                
                non_slices, non_lbls, typ = self.get_nonTarget(class_idx[0], curr_dict)

                non_imgs = []
                non_labels = []
                for ii in range(len(non_lbls)):
                    label_i, _ = self.supcls_pick_binarize(non_slices[ii][typ[ii]], bi_val=non_lbls[ii])
                    
                    img =non_slices[ii]["img"]
                    img = torch.from_numpy( np.transpose( img, (2, 0, 1)) )
                    lb  = torch.from_numpy( label_i.squeeze(-1))
                    if self.tile_z_dim:
                        img = img.repeat( [ self.tile_z_dim, 1, 1] )
                        assert img.ndimension() == 3, f'actual dim {img.ndimension()}'

                    non_imgs.append(img.view(1,img.shape[0],img.shape[1],img.shape[2]))
                    non_labels.append(lb.view(1,lb.shape[0],lb.shape[1]))

                # plot_images(non_imgs, non_labels, w = 5)

                is_start    = curr_dict["is_start"]
                is_end      = curr_dict["is_end"]
                nframe      = np.int32(curr_dict["nframe"])
                scan_id     = curr_dict["scan_id"]
                z_id        = curr_dict["z_id"]

                sample = {"image": simg,
                        "label":slb,
                        "non_imgs":non_imgs,
                        "non_labels":non_labels,
                        "non_ids":non_lbls,
                        "is_start": is_start,
                        "inst": None,
                        "scribble": None,
                        "is_end": is_end,
                        "nframe": nframe,
                        "scan_id": scan_id,
                        "z_id": z_id
                        }

                concat_buffer.append(sample)
            out_buffer.append({
                "image": torch.stack([itm["image"] for itm in concat_buffer], dim = 0),
                "label": torch.stack([itm["label"] for itm in concat_buffer], dim = 0),
                "non_imgs": [itm["non_imgs"] for itm in concat_buffer],
                "non_labels": [itm["non_labels"] for itm in concat_buffer],
                "non_ids": [itm["non_ids"] for itm in concat_buffer],

                })

            # do the concat, and add to output_buffer

        # post-processing, including keeping the foreground and suppressing background.
        support_images = []
        support_mask = []
        support_class = []
        non_images = []
        non_mask = []
        non_class = []
        for itm in out_buffer:
            support_images.append(itm["image"])
            support_class.append(curr_class)
            support_mask.append(  self.getMaskMedImg( itm["label"], 1, [1]  ))

            non_images.append(itm["non_imgs"])
            non_mask.append(itm["non_labels"])
            non_class.append(itm["non_ids"])

        return {'class_ids': [support_class],
            'support_images': [support_images], #
            'support_mask': [support_mask],

            'non_ids': non_class,
            'non_imgs': non_images, #
            'non_labels': non_mask,
        }

