#!/bin/bash
 
# ./examples/test_ssl_abdominal_ct.sh
GPUID=1
# export CUDA_VISIBLE_DEVICES=$GPUID
# CUDA_VISIBLE_DEVICES=$GPUID #'./cuda_executable'
####### Shared configs ######
PROTO_GRID=8 # using 32 / 8 = 4, 4-by-4 prototype pooling window during training
## CPT="myexp"
## DATASET='SABS_Superpix'

# CPT="myexp_CTC"
# DATASET='SABS_Superpix_CTC'
# DATASET='CTC_SABS'

# DATASET='SABS_Superpix_CTC_Classic'

# CPT="seven_foldvalid_mySSL_CTC_fold_0_of4fold"
# CPT="mySSL_CTC_Onefoldonlytraining"
# CPT="mySSL_CTC_Onefoldonlytraining100k_actualannotation_setting_2"
# CPT="CTC68_Correct_Train100k_actualannotation_setting1_30test"
CPT="SABS30_Correct_Train100k_actualannotation_setting1_CTC30Test"

# CPT="ASS_DCL_30SABS_training100k_Actualannot_setting1_38ctctest"
# mySSL_CTC_updated
DATASET='CTC_Correct_30Test'
NWORKER=4

# # CTC_SABS Dataset 
# ALL_EV=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18) # 
ALL_EV=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14) # cover 38 ctc scans

# ALL_EV=(0, 1, 2, 3, 4, 5, 6) # using 128 scans; 30 SABS + 30 CTC: np.arange(30,60,4).tolist()  ---> [30, 34, 38, 42, 46, 50, 54, 58]
## CTC_SABS DAataset
# ALL_EV=(0) # Here, we are testing with the trained model of fold 0
# ALL_EV=(0, 1, 2, 3) # 3-fold  #(0) # one fold # 5-fold cross validation (0, 1, 2, 3, 4)
ALL_SCALE=("MIDDLE") # config of pseudolabels

# ### Use L/R kidney as testing classes
# LABEL_SETS=0 
# EXCLU='[2,3]' # setting 2: excluding kidneies in training set to test generalization capability even though they are unlabeled. Use [] for setting 1 by Roy et al.

## Use Liver and spleen as testing classes
# LABEL_SETS=1 
# EXCLU='[1,6]' 
### Use COLON as testing class
LABEL_SETS=0
EXCLU='[14]'
# EXCLU='[]' # setting1

###### Training configs (irrelavent in testing) ######
NSTEP=100100
DECAY=0.95

MAX_ITER=1000 # defines the size of an epoch
SNAPSHOT_INTERVAL=25000 # interval for saving snapshot
SEED='1234'

###### Validation configs ######
# SUPP_ID='[6]' # using the additionally loaded scan as support for the 128 scan and partition the colon scans as #[30, 42, 54, 66, 78, 90, 102, 114, 126]
SUPP_ID='[2]' # indicating which scan is used as support in testing. for the 60 scan and partition the colon scans as ## [30, 34, 38, 42, 46, 50, 54, 58]

echo ===================================

for EVAL_FOLD in "${ALL_EV[@]}"
do
    for SUPERPIX_SCALE in "${ALL_SCALE[@]}"
    do
    PREFIX="test_vfold${EVAL_FOLD}"
    echo $PREFIX
    LOGDIR="./temp_exps/${CPT}"

    if [ ! -d $LOGDIR ]
    then
        mkdir $LOGDIR
    fi

    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs/myDCL__CTC_SABS_sets_0_1shot/11/snapshots/100000.pth'
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs_temp/myDCL__CTC_Correct_60Train_sets_0_1shot/17/snapshots/100000.pth'
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs_temp/myDCL__CTC_SABS_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    #30SABS 
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs_temp/ASS_DCL_SABS_only__SABS_sets_0_1shot/1/snapshots/100000.pth'

    #68CTC
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs_temp/CTC68_Correct_Train100k_actualannotation_setting1_CTC30Test__CTC68_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    # 68CTC+30SABS
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs_temp/CTC68_SABS30_Correct_Train100k_actualannotation_setting1_CTC30Test__CTC68_SABS30_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    #30SABS
    RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/AAS_DCL_2022/AAS-DCL_FSS-main/runs_temp/SABS30_Correct_Train100k_actualannotation_setting1_CTC30Test__SABS_sets_0_1shot/1/snapshots/100000.pth'
    python3 validation.py with \
    'modelname=dlfcn_res101' \
    'usealign=True' \
    'optim_type=sgd' \
    reload_model_path=$RELOAD_PATH \
    num_workers=$NWORKER \
    scan_per_load=-1 \
    label_sets=$LABEL_SETS \
    'use_wce=True' \
    exp_prefix=$PREFIX \
    'clsname=grid_proto' \
    n_steps=$NSTEP \
    exclude_cls_list=$EXCLU \
    eval_fold=$EVAL_FOLD \
    dataset=$DATASET \
    proto_grid_size=$PROTO_GRID \
    max_iters_per_load=$MAX_ITER \
    min_fg_data=1 seed=$SEED \
    gpu_id=$GPUID\
    save_snapshot_every=$SNAPSHOT_INTERVAL \
    superpix_scale=$SUPERPIX_SCALE \
    lr_step_gamma=$DECAY \
    path.log_dir=$LOGDIR \
    support_idx=$SUPP_ID
    done
done
