"""Util functions
Extended from original PANet code
TODO: move part of dataset configurations to data_utils
"""
import random
import torch
import numpy as np
import operator
import matplotlib.pyplot as plt
from torchvision import utils
from torch import nn

def set_seed(seed):
    """
    Set the random seed
    """
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

CLASS_LABELS = {
    'SABS': {
        'pa_all': set( [1,2,3,6]  ),
        0: set([1,2,3]  ), # upper_abdomen: spleen + liver as training, kidneis are testing
        1: set( [6] ), # lower_abdomen
    },
    'C0': {
        'pa_all': set(range(1, 4)),
        0: set([2,3]),
        1: set([1,3]),
        2: set([1,2]),
    },
    'CHAOST2': {
        'pa_all': set(range(1, 5)),
        0: set([1, 4]), # upper_abdomen, leaving kidneies as testing classes
        1: set([2, 3]), # lower_abdomen
    },
    'CTC_SABS': {
        'pa_all': set(range(1,15)),
        0: set(range(1,14)), # upper_abdomen: spleen + liver as training, kidneis are testing
        1: set( [14] ), # COLON
        # 2: set( [2,3] ), # lower_abdomen

    },
    
    'CTC_Correct_38Test': {
        'pa_all': set(range(1,15)),
        0: set(range(1,14)), # upper_abdomen: spleen + liver as training, kidneis are testing
        1: set( [14] ), # COLON
        # 2: set( [2,3] ), # lower_abdomen

    },
    
    'CTC_Correct_60Train': {
        'pa_all': set(range(1,15)),
        0: set(range(1,14)), # upper_abdomen: spleen + liver as training, kidneis are testing
        1: set( [14] ), # COLON
        # 2: set( [2,3] ), # lower_abdomen

    },
}

def get_bbox(fg_mask, inst_mask):
    """
    Get the ground truth bounding boxes
    """

    fg_bbox = torch.zeros_like(fg_mask, device=fg_mask.device)
    bg_bbox = torch.ones_like(fg_mask, device=fg_mask.device)

    inst_mask[fg_mask == 0] = 0
    area = torch.bincount(inst_mask.view(-1))
    cls_id = area[1:].argmax() + 1
    cls_ids = np.unique(inst_mask)[1:]

    mask_idx = np.where(inst_mask[0] == cls_id)
    y_min = mask_idx[0].min()
    y_max = mask_idx[0].max()
    x_min = mask_idx[1].min()
    x_max = mask_idx[1].max()
    fg_bbox[0, y_min:y_max+1, x_min:x_max+1] = 1

    for i in cls_ids:
        mask_idx = np.where(inst_mask[0] == i)
        y_min = max(mask_idx[0].min(), 0)
        y_max = min(mask_idx[0].max(), fg_mask.shape[1] - 1)
        x_min = max(mask_idx[1].min(), 0)
        x_max = min(mask_idx[1].max(), fg_mask.shape[2] - 1)
        bg_bbox[0, y_min:y_max+1, x_min:x_max+1] = 0
    return fg_bbox, bg_bbox

def t2n(img_t):
    """
    torch to numpy regardless of whether tensor is on gpu or memory
    """
    if img_t.is_cuda:
        return img_t.data.cpu().numpy()
    else:
        return img_t.data.numpy()

def to01(x_np):
    """
    normalize a numpy to 0-1 for visualize
    """
    return (x_np - x_np.min()) / (x_np.max() - x_np.min() + 1e-5)

def compose_wt_simple(is_wce, data_name):
    """
    Weights for cross-entropy loss
    """
    if is_wce:
        if data_name in ['SABS', 'CTC_SABS', 'CTC68_SABS30_Correct', 'CTC68_Correct_Train' ,'CTC68_SABS30_Correct_Train', 'CTC_Correct_18Test','CTC_Correct_60Train', 'CTC_Correct_38Test','CTC_Correct_30Test', 'CTC_SABS_Correct_Train','CTC_SABS_Correct_Test', 'SABS_Superpix', 'C0', 'C0_Superpix', 'CHAOST2', 'CHAOST2_Superpix']:
            return torch.FloatTensor([0.05, 1.0]).cuda()
        else:
            raise NotImplementedError
    else:
        return torch.FloatTensor([1.0, 1.0]).cuda()


class CircularList(list):
    """
    Helper for spliting training and validation scans
    Originally: https://stackoverflow.com/questions/8951020/pythonic-circular-list/8951224
    """
    def __getitem__(self, x):
        if isinstance(x, slice):
            return [self[x] for x in self._rangeify(x)]

        index = operator.index(x)
        try:
            return super().__getitem__(index % len(self))
        except ZeroDivisionError:
            raise IndexError('list index out of range')

    def _rangeify(self, slice):
        start, stop, step = slice.start, slice.stop, slice.step
        if start is None:
            start = 0
        if stop is None:
            stop = len(self)
        if step is None:
            step = 1
        return range(start, stop, step)

def plot_images(ims, fgs, bgs=[None,None,None], w=0.001):

    n = len(ims)
    k = 0
    # plt.axis([0, 255, 0, 255])
    plt.ion()
    plt.show()
    for im, fg, bg in zip(ims, fgs, bgs):

        im = im.squeeze().permute((1,2,0))
        fg = fg.squeeze().cpu().numpy()
        
    
        img = im.cpu().numpy()
        img = img - img.min()
        img = img/img.max()

        # if bg is None:        
        #     plt.subplot(n,2,1+k), plt.imshow(img, cmap='gray')
        #     plt.subplot(n,2,2+k), plt.imshow(fg)
        #     k+=2
        # else:
        #     bg = bg[0].squeeze().cpu().numpy()
        #     plt.subplot(n,3,1+k), plt.imshow(img, cmap='gray')
        #     plt.subplot(n,3,2+k), plt.imshow(fg)
        #     plt.subplot(n,3,3+k), plt.imshow(bg)
        #     k += 3

        if bg is None:        
            bg = 1-fg
        else:
            bg = bg.squeeze().cpu().numpy()

       
        plt.subplot(n,3,1+k), plt.imshow(img, cmap='gray')
        plt.subplot(n,3,2+k), plt.imshow(fg)
        plt.subplot(n,3,3+k), plt.imshow(bg)
        k += 3

    plt.draw()
    plt.pause(w)


def vistensor(tensor, ch=0, allkernels=False, nrow=8, padding=1): 
    '''
    vistensor: visuzlization tensor
        @ch: visualization channel 
        @allkernels: visualization all tensores
    ''' 
    
    n,c,w,h = tensor.shape
    if allkernels: tensor = tensor.view(n*c,-1,w,h )
    elif c != 3: tensor = tensor[:,ch,:,:].unsqueeze(dim=1)
        
    rows = np.min( (tensor.shape[0]//nrow + 1, 64 )  )    
    grid = utils.make_grid(tensor.cpu(), nrow=nrow, normalize=True, padding=padding)
    plt.figure( figsize=(nrow,rows) )
    plt.ion()
    plt.show()
    plt.imshow(grid.numpy().transpose((1, 2, 0)))
    plt.draw()
    plt.pause(w)
    plt.close()


def weight_histograms_conv2d(writer, step, weights, layer_number):
  weights_shape = weights.shape
  num_kernels = weights_shape[0]
  for k in range(num_kernels):
    flattened_weights = weights[k].flatten()
    tag = f"layer_{layer_number}/kernel_{k}"
    writer.add_histogram(tag, flattened_weights, global_step=step, bins='tensorflow')


def weight_histograms_linear(writer, step, weights, layer_number):
  flattened_weights = weights.flatten()
  tag = f"layer_{layer_number}"
  writer.add_histogram(tag, flattened_weights, global_step=step, bins='tensorflow')


def weight_histograms(writer, step, model):
  print("Visualizing model weights...")
  # Iterate over all model layers
  for layer_number in range(len(model.layers)):
    # Get layer
    layer = model.layers[layer_number]
    # Compute weight histograms for appropriate layer
    if isinstance(layer, nn.Conv2d):
      weights = layer.weight
      weight_histograms_conv2d(writer, step, weights, layer_number)
    elif isinstance(layer, nn.Linear):
      weights = layer.weight
      weight_histograms_linear(writer, step, weights, layer_number)