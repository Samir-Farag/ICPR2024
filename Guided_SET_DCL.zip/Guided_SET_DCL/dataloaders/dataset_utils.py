"""
Utils for datasets
"""
import numpy as np

import os
import sys
import nibabel as nib
import numpy as np
import pdb
import SimpleITK as sitk

DATASET_INFO = {
  
    "SABS": {
            'PSEU_LABEL_NAME': ["BG", "SUPFG"],

            'REAL_LABEL_NAME': ["BG", "SPLEEN", "KID_R", "KID_l", "GALLBLADDER", "ESOPHAGUS", "LIVER", "STOMACH", "AORTA", "IVC",\
              "PS_VEIN", "PANCREAS", "AG_R", "AG_L", "COLON"],
            '_SEP': [0, 6, 12, 18, 24, 30],
            # '_SEP': np.arange(0,39,2).tolist(), # using 38 scans CTC

            'MODALITY': 'CT',
            'LABEL_GROUP':{
                'pa_all': set( range(1, 14) ),
                0: set(range(2, 14)), # upper_abdomen: spleen + liver as training, kidneis are testing
                1: set( [1] ), # COLOn
                    }
            },

    "CTC_GT_Classic_Correct": {
            'PSEU_LABEL_NAME': ["BG", "SUPFG"],
            'REAL_LABEL_NAME': ["BG", "SPLEEN", "KID_R", "KID_L", "GALLBLADDER", "ESOPHAGUS", "LIVER", "STOMACH", "AORTA", "IVC",\
              "PS_VEIN", "PANCREAS", "AG_R", "AG_L", "COLON"],
            # '_SEP': [],#np.arange(0,90,20).tolist(), # using 30 scans SABS + 30 scans CTC
            #Samirmodifications
            # '_SEP': [0, 21, 42, 68, 97], #[0, 21, 42, 98, 127],#np.arange(0,99,35).tolist(), # using 30 scans SABS + 68 scans CTC
             
            # '_SEP': [0, 21, 42, 86, 90], #[0, 21, 42, 98, 127],#np.arange(0,99,35).tolist(), # using 30 scans SABS + 68 scans CTC
            '_SEP': [0, 21, 42, 91, 97], #[0, 21, 42, 98, 127],#np.arange(0,99,35).tolist(), # using 30 scans SABS + 68 scans CTC

            # import numpy as np; np.arange(30,90,5).tolist()
            # [0, 20, 40, 60, 80]

            # '_SEP': np.arange(30,128,7).tolist(),
            'trian_data' : 'colon',   # or 'all'

            'MODALITY': 'CT',
            'LABEL_GROUP':{
                'pa_all': set( range(1, 15) ),
                0: set(range(1, 14)), # upper_abdomen: spleen + liver as training, kidneis are testing
                1: set( [14] ), # COLOn
                # 2: set( [2, 3] ), # lower_abdomen
                    }
            },
    
    "CTC68_Correct_Train": {
            'PSEU_LABEL_NAME': ["BG", "SUPFG"],
            'REAL_LABEL_NAME': ["BG", "SPLEEN", "KID_R", "KID_L", "GALLBLADDER", "ESOPHAGUS", "LIVER", "STOMACH", "AORTA", "IVC",\
              "PS_VEIN", "PANCREAS", "AG_R", "AG_L", "COLON"],
            # '_SEP': [],#np.arange(0,90,20).tolist(), # using 30 scans SABS + 30 scans CTC
            '_SEP': np.arange(0,68,7).tolist(), # using 30 scans SABS + 30 scans CTC

            # import numpy as np; np.arange(30,90,5).tolist()
            # [0, 20, 40, 60, 80]

            # '_SEP': np.arange(30,128,7).tolist(),
            'MODALITY': 'CT',
            'LABEL_GROUP':{
                'pa_all': set( range(1, 15) ),
                0: set(range(1, 15)), # upper_abdomen: spleen + liver as training, kidneis are testing
                1: set( [] ), # COLOn
                # 2: set( [2, 3] ), # lower_abdomen
                    }
            },
    "CTC_Correct_30Test": {
            'PSEU_LABEL_NAME': ["BG", "SUPFG"],

            'REAL_LABEL_NAME': ["BG", "SPLEEN", "KID_R", "KID_L", "GALLBLADDER", "ESOPHAGUS", "LIVER", "STOMACH", "AORTA", "IVC",\
              "PS_VEIN", "PANCREAS", "AG_R", "AG_L", "COLON"],
            '_SEP': np.arange(0,31,2).tolist(), # using 38 scans CTC
            # import numpy as np; np.arange(0,38,2).tolist()
            # [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36]
            'MODALITY': 'CT',
            'LABEL_GROUP':{
                'pa_all': set( range(1, 15) ),
                0: set(range(1, 14)), # upper_abdomen: spleen + liver as training, kidneis are testing
                1: set( [14] ), # COLOn
                # 2: set( [2, 3] ), # lower_abdomen
                    }
            }

}

def read_nii_bysitk(input_fid, peel_info = False):
    """ read nii to numpy through simpleitk

        peelinfo: taking direction, origin, spacing and metadata out
    """
    img_obj = sitk.ReadImage(input_fid)
    img_np = sitk.GetArrayFromImage(img_obj)
    if peel_info:
        info_obj = {
                "spacing": img_obj.GetSpacing(),
                "origin": img_obj.GetOrigin(),
                "direction": img_obj.GetDirection(),
                "array_size": img_np.shape
                }
        return img_np, info_obj
    else:
        return img_np

def get_normalize_op(modality, fids):
    """
    As title
    Args:
        modality:   CT or MR
        fids:       fids for the fold
    """

    def get_CT_statistics(scan_fids):
        """
        As CT are quantitative, get mean and std for CT images for image normalizing
        As in reality we might not be able to load all images at a time, we would better detach statistics calculation with actual data loading
        """
        total_val = 0
        n_pix = 0
        for fid in scan_fids:
            in_img = read_nii_bysitk(fid)
            total_val += in_img.sum()
            n_pix += np.prod(in_img.shape)
            del in_img
        meanval = total_val / n_pix

        total_var = 0
        for fid in scan_fids:
            in_img = read_nii_bysitk(fid)
            total_var += np.sum((in_img - meanval) ** 2 )
            del in_img
        var_all = total_var / n_pix

        global_std = var_all ** 0.5

        return meanval, global_std

    if modality == 'MR':

        def MR_normalize(x_in):
            return (x_in - x_in.mean()) / x_in.std()

        return MR_normalize #, {'mean': None, 'std': None} # we do not really need the global statistics for MR

    elif modality == 'CT':
        ct_mean, ct_std = get_CT_statistics(fids)
        # debug
        print(f'###### DEBUG_DATASET CT_STATS NORMALIZED MEAN {ct_mean / 255} STD {ct_std / 255} ######')

        def CT_normalize(x_in):
            """
            Normalizing CT images, based on global statistics
            """
            return (x_in - ct_mean) / ct_std

        return CT_normalize #, {'mean': ct_mean, 'std': ct_std}


