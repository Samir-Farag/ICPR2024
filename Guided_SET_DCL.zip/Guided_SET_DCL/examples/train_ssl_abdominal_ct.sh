#!/bin/bash
# train a model to segment abdominal CT 
# ./examples/train_ssl_abdominal_ct.sh
GPUID1=0
export CUDA_VISIBLE_DEVICES=$GPUID1

####### Shared configs ######
PROTO_GRID=8 # using 32 / 8 = 4, 4-by-4 prototype pooling window during training
# CPT="myexp"
# DATASET='SABS_Superpix'

# CPT="mySSL_CTC_updated"
# CPT="mySSL_CTC_Onefoldonlytraining300k"
CPT="mySSL_CTC_Onefoldonlytraining100k_actualannotation_setting1_60scan"

DATASET='CTC_SABS'
# DATASET='SABS_Actualann_CTC'
# DATASET='SABS_Superpix_CTC_Classic'
NWORKER=4

# ALL_EV=(0, 1, 2, 3) # We have 128 scans. So, we decided to do 4-fold  #(0) # one fold # 5-fold cross validation (0, 1, 2, 3, 4)
ALL_EV=(0) # Latter, we decided one fold only for the whole 128 scans
# ALL_SCALE= ("MIDDLE") # config of pseudolabels
ALL_SCALE=( "MIDDLE")
### Use L/R kidney as testing classes
# EXCLU='[2, 3]' # setting 2: excluding kidneies in training set to test generalization capability even though 
#they are unlabeled. Use [] for setting 1 by Roy et al.

# ### Use Liver and spleen as testing classes
# LABEL_SETS=1 
# EXCLU='[1, 6]'

### Use COLON as testing class
LABEL_SETS=0
# LABEL_SETS=1 
EXCLU='[]'  #---------------> setting1: train with organs (labels) from 1-13 and test with colon (label 14)
# EXCLU='[1, 6]'
# EXCLU='[14]'  #---------------> setting2: train with organs (labels) from 1-13 and test with colon (label 14)
###### Training configs ######
# NSTEP=300000 #300k iterations
NSTEP=100100
DECAY=0.95
MAX_ITER=1000 # defines the size of an epoch
SNAPSHOT_INTERVAL=25000 # interval for saving snapshot
# SNAPSHOT_INTERVAL=50000 # interval for saving snapshot

SEED='1234'
###### Validation configs ######
# SUPP_ID='[6]' # using the additionally loaded scan as support for the 128 scan and partition the colon scans as #[30, 42, 54, 66, 78, 90, 102, 114, 126]
SUPP_ID='[4]' # indicating which scan is used as support in testing. for the 60 scan and partition the colon scans as ## [30, 34, 38, 42, 46, 50, 54, 58]

echo ===================================

for EVAL_FOLD in "${ALL_EV[@]}"
do
    for SUPERPIX_SCALE in "${ALL_SCALE[@]}"
    do
    PREFIX="train_${DATASET}_lbgroup${LABEL_SETS}_scale_${SUPERPIX_SCALE}_vfold${EVAL_FOLD}"
    echo $PREFIX
    LOGDIR="./runs/${CPT}_${SUPERPIX_SCALE}_${LABEL_SETS}"
    # LOGDIR="./runs_temp/${CPT}_${SUPERPIX_SCALE}_${LABEL_SETS}"
    echo "log directory fo debugging:------>   $LOGDIR"
    # LOGDIR="./exps/${SUPERPIX_SCALE}_${LABEL_SETS}"

    # if [ ! -d $LOGDIR ]
    
    # then
    #     mkdir $LOGDIR
    # fi

    echo "Creating directory: $LOGDIR"
    if [ ! -d "$LOGDIR" ]; then
        mkdir -p "$LOGDIR"  # Use -p option to avoid error if directory already exists
        if [ $? -eq 0 ]; then
            echo "Directory created successfully: $LOGDIR"
        else
            echo "Failed to create directory: $LOGDIR"
        fi
    else
        echo "Directory already exists: $LOGDIR"
    fi

    python3 training.py with \
    'modelname=dlfcn_res101' \
    'usealign=True' \
    'optim_type=sgd' \
    num_workers=$NWORKER \
    scan_per_load=-1 \
    label_sets=$LABEL_SETS \
    'use_wce=True' \
    exp_prefix=$PREFIX \
    'clsname=grid_proto' \
    n_steps=$NSTEP \
    exclude_cls_list=$EXCLU \
    eval_fold=$EVAL_FOLD \
    dataset=$DATASET \
    proto_grid_size=$PROTO_GRID \
    max_iters_per_load=$MAX_ITER \
    min_fg_data=1 seed=$SEED \
    save_snapshot_every=$SNAPSHOT_INTERVAL \
    superpix_scale=$SUPERPIX_SCALE \
    lr_step_gamma=$DECAY \
    path.log_dir=$LOGDIR \
    support_idx=$SUPP_ID
    done
done
# /media/hd2/Colon/Data_GT_Annotaion$
    # log_dir=$LOGDIR \

    # exclude_cls_list=${EXCLU//[[:blank:]]/} \
    # echo "Error here:---------->$EVAL_FOLD"