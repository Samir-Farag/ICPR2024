def calculate_sensitivity_specificity_old(polyb_scores):
    # True positives (TP), False positives (FP), True negatives (TN), False negatives (FN)
    TP = sum(score > 0 for score in polyb_scores)
    FN = sum(score == 0 for score in polyb_scores)
    # Calculate sensitivity and specificity
    sensitivity = TP / (TP + FN)
    Acc = sum(score/2 for score in polyb_scores)
    return sensitivity, Acc/(10+12)

def calculate_sensitivity_specificity(polyb_scores):
    # True positives (TP), False positives (FP), True negatives (TN), False negatives (FN)
    TP = sum(score > 0 for score in polyb_scores)
    FN = sum(score == 0 for score in polyb_scores)
    # Calculate sensitivity and specificity
    sensitivity = TP / (TP + FN)
    accuracy = sum(score / 2 for score in polyb_scores) / len(polyb_scores)
    
    return sensitivity, accuracy
# Polyb scores for each model
model_scores = {# first numbers are scores of 10 polyps in scans 36p&s, 40p&s and 44p&s.       scan 36p&s has 6 polyps. Each of the rest has 2 in both prone and supine
                # Next numbers are scores of 12 polyps in scans 45p&s, 47p&s, 48p&s and 49p&s. Each of scans 47p&s and 49p&s has 4 polyps. Each of the rest has 2 in both prone and supine
    "SSL_APLNet2020 (30SABS+60CTC)": [2, 2, 2, 1, 1, 1, 1, 2, 2, 2,    1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 2, 1],
    "SSL_APLNet2020 (60CTC)":        [2, 2, 2, 0, 1, 1, 1, 2, 2, 2,    1, 0, 1, 1, 2, 1, 2, 0, 2, 2, 2, 2],
    "SSL_APLNet2020 (30SABS)":       [2, 1, 2, 1, 1, 1, 0, 2, 0, 2,    1, 1, 0, 0, 1, 0, 1, 0, 2, 2, 0, 2],
    "AAS_DCL2022 (30SABS+60CTC)":    [1, 2, 1, 1, 2, 1, 1, 2, 1, 2,    1, 0, 0, 0, 1, 1, 1, 0, 2, 2, 2, 2],
    "AAS_DCL2022 (60CTC)":           [1, 2, 1, 1, 2, 1, 1, 2, 1, 2,    1, 0, 0, 1, 0, 0, 1, 1, 2, 2, 2, 2],
    "AAS_DCL2022 (30SABS)":          [2, 2, 2, 2, 1, 0, 2, 1, 0, 2,    0, 0, 0, 0, 0, 0, 1, 0, 2, 0, 0, 2],
    "Base model": [1, 2, 1, 1, 1, 2, 1, 2, 2, 2,    2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 2, 2],
    "Classic":    [1, 1, 1, 1, 1, 0, 1, 2, 2, 1,    2, 2, 1, 0, 2, 0, 2, 0, 2, 2, 2, 2],
    "Guided-SET-DCL": [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]}

# Calculate sensitivity and specificity for each model
# for model, scores in model_scores.items():
#     sensitivity, Acc = calculate_sensitivity_specificity(scores)
#     print(f"{model}:")
#     print(f"  Sensitivity: {sensitivity}")
#     print(f"  Accuracy: {Acc}")
#     print()

# Calculate sensitivity and accuracy for each model
for model, scores in model_scores.items():
    sensitivity, accuracy = calculate_sensitivity_specificity(scores)
    print(f"{model}:")
    print(f"  Sensitivity: {sensitivity * 100:.2f}%")
    print(f"  Accuracy: {accuracy * 100:.2f}%")
    print()


    # "Guided-SET-DCL":    [2, 2, 2,
    #                       2,
    #                       2,
    #                       2,
    #                       2,
    #                       2, 2, 2,
    #                       2, 2, 2, 2, 1, 2,
    #                       2, 2,
    #                       2, 2, 2,
    #                       2, #recheck
    #                       2, #recheck
    #                       2, #recheck
    #                       2, 2,
    #                       2,
    #                       2, 2
    #                       ]