"""
Training the model
Extended from original implementation of PANet by Wang et al.
"""
import os
import shutil
import torch
import torch.nn as nn
import torch.optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import torch.backends.cudnn as cudnn
import numpy as np

from models.AAS_DCL import AAS_DCL
from dataloaders.dev_customized_med import med_fewshot
from dataloaders.GenericSuperDatasetv2 import SuperpixelDataset
from dataloaders.ManualAnnoDatasetv3 import ManualAnnoDataset
from dataloaders.dataset_utils import DATASET_INFO
import dataloaders.augutils as myaug
from torch.utils.tensorboard import SummaryWriter

from utils.util import set_seed, t2n, to01, compose_wt_simple
from utils.metrics import Metric
from utils.util import plot_images, vistensor, weight_histograms

from config_ssl_upload import ex
import tqdm

# config pre-trained model caching path
os.environ['TORCH_HOME'] = "./pretrained_model"

@ex.automain
def main(_run, _config, _log):
    if _run.observers:
        os.makedirs(f'{_run.observers[0].dir}/snapshots', exist_ok=True)
        for source_file, _ in _run.experiment_info['sources']:
            os.makedirs(os.path.dirname(f'{_run.observers[0].dir}/source/{source_file}'),
                        exist_ok=True)
            _run.observers[0].save_file(source_file, f'source/{source_file}')
        shutil.rmtree(f'{_run.observers[0].basedir}/_sources')

    set_seed(1234)
    cudnn.enabled = True
    cudnn.benchmark = True
    torch.cuda.set_device(device=_config['gpu_id'])
    torch.set_num_threads(1)

    _log.info('###### Create model ######')
    model = AAS_DCL()

    model = model.cuda()
    # model.load_state_dict(torch.load(_config['reload_model_path']))    

    model.train()

    _log.info('###### Load data ######')
    ### Training set
    data_name = _config['dataset']
    if data_name == 'SABS':
        baseset_name = 'SABS'
    elif data_name == 'C0_Superpix':
        raise NotImplementedError
        baseset_name = 'C0'
    elif data_name == 'CHAOST2_Superpix':
        baseset_name = 'CHAOST2'
    elif data_name == 'CTC_SABS':
        baseset_name = 'CTC_SABS'

    elif data_name == 'CTC_SABS_Correct_Train':
        baseset_name = 'CTC_SABS_Correct_Train'
    
    elif data_name == 'CTC68_Correct_Train':  # 68 CTC scans (34 prone + 34 supine)
        baseset_name = 'CTC68_Correct_Train'

    elif data_name == 'CTC68_SABS30_Correct_Train':  # 30SABS +  60 CTC scans (30 prone + 30 supine)
        baseset_name = 'CTC68_SABS30_Correct_Train'


    else:
        raise ValueError(f'Dataset: {data_name} not found')

    ### Transforms for data augmentation
    tr_transforms = myaug.transform_with_label({'aug': myaug.augs[_config['which_aug']]})
    assert _config['scan_per_load'] < 0 # by default we load the entire dataset directly

    test_labels = DATASET_INFO[baseset_name]['LABEL_GROUP']['pa_all'] - DATASET_INFO[baseset_name]['LABEL_GROUP'][_config["label_sets"]]
    _log.info(f'###### Labels excluded in training : {[lb for lb in _config["exclude_cls_list"]]} ######')
    _log.info(f'###### Unseen labels evaluated in testing: {[lb for lb in test_labels]} ######')

    # tr_parent = SuperpixelDataset( # base dataset
    #     which_dataset = baseset_name,
    #     base_dir=_config['path'][data_name]['data_dir'],
    #     idx_split = _config['eval_fold'],
    #     mode='train',
    #     min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
    #     transforms=tr_transforms,
    #     nsup = _config['task']['n_shots'],
    #     scan_per_load = _config['scan_per_load'],
    #     exclude_list = _config["exclude_cls_list"],
    #     superpix_scale = _config["superpix_scale"],
    #     fix_length = _config["max_iters_per_load"] if (data_name == 'C0_Superpix') or (data_name == 'CHAOST2_Superpix') else None
    # )

    tr_parent = ManualAnnoDataset( # base dataset
        which_dataset = baseset_name,
        base_dir=_config['path'][data_name]['data_dir'],
        idx_split = _config['eval_fold'],
        mode='train',
        min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
        transforms=tr_transforms,
        nsup = _config['task']['n_shots'],
        scan_per_load = _config['scan_per_load'],
        exclude_list = _config["exclude_cls_list"],
        superpix_scale = _config["superpix_scale"],
        fix_length = _config["max_iters_per_load"] if (data_name == 'C0_Superpix') or (data_name == 'CHAOST2_Superpix') else None
    )

    ### dataloaders
    trainloader = DataLoader(
        tr_parent,
        batch_size=_config['batch_size'],
        shuffle=True,
        num_workers=_config['num_workers'],
        pin_memory=True,
        drop_last=True
    )

    _log.info('###### Set optimizer ######')
    if _config['optim_type'] == 'sgd':
        optimizer = torch.optim.SGD(model.parameters(), **_config['optim'])
    elif _config['optim_type'] == 'adam':
        optimizer = torch.optim.Adam(model.parameters(), **_config['optim'])
    else:
        raise NotImplementedError

    scheduler = MultiStepLR(optimizer, milestones=_config['lr_milestones'],  gamma = _config['lr_step_gamma'])

    my_weight = compose_wt_simple(_config["use_wce"], data_name)
    criterion = nn.CrossEntropyLoss(ignore_index=_config['ignore_label'], weight = my_weight)

    i_iter = 0 # total number of iteration
    n_sub_epoches = _config['n_steps'] // _config['max_iters_per_load'] # number of times for reloading

    log_loss = {'loss': 0, 'align_loss': 0}
    # Initialize the SummaryWriter for TensorBoard
    # Its output will be written to ./runs/
    writer = SummaryWriter()

    _log.info('###### Training ######')
    for sub_epoch in range(n_sub_epoches):
        _log.info(f'###### This is epoch {sub_epoch} of {n_sub_epoches} epoches ######')
        for _, sample_batched in enumerate(trainloader):
            # Prepare input
            i_iter += 1
            # add writers
            support_images = [[shot.cuda() for shot in way]
                              for way in sample_batched['support_images']]
            support_labels = [[shot.cuda() for shot in way]
                               for way in sample_batched['support_labels']]
            class_id =  sample_batched['class_ids']   

            nontrgt_images = [nonimg.cuda() for nonimg in sample_batched['nontrgt_images']]
            nontrgt_labels = [nonlabel.cuda() for nonlabel in sample_batched['nontrgt_labels']]
            nontrgt_ids =  sample_batched['nontrgt_ids']                      
            

            query_images = [query_image.cuda()
                            for query_image in sample_batched['query_images']]
            query_labels = torch.cat(
                [query_label.long().cuda() for query_label in sample_batched['query_labels']], dim=0)

            optimizer.zero_grad()
            # FIXME: in the model definition, filter out the failure case where pseudolabel falls outside of image or too small to calculate a prototype
            try:
                query_pred, mse, dcl_loss = model(support_images[0][0], support_labels[0][0], class_id[0][0], query_images[0], nontrgt_images, nontrgt_labels, nontrgt_ids)                    

            except:
                print('Faulty batch detected, skip')
                continue

            query_loss = criterion(query_pred, query_labels)
            loss = query_loss + dcl_loss
            loss.backward()
            optimizer.step()
            scheduler.step() #If you don’t call it, the learning rate won’t be changed and stays at the initial value

            # Log loss
            query_loss = query_loss.detach().data.cpu().numpy()
            dcl_loss = dcl_loss.detach().data.cpu().numpy() if dcl_loss != 0 else 0

            _run.log_scalar('loss', query_loss)
            _run.log_scalar('align_loss', dcl_loss)
            log_loss['loss'] += query_loss
            log_loss['align_loss'] += dcl_loss

            writer.add_scalar("query", query_loss, i_iter)
            writer.add_scalar("dcl", dcl_loss, i_iter)


            # print loss and take snapshots
            if (i_iter + 1) % _config['print_interval'] == 0:

                loss = log_loss['loss'] / _config['print_interval']
                dcl_loss = log_loss['align_loss'] / _config['print_interval']

                writer.add_scalar("query/epoch", query_loss, sub_epoch)
                writer.add_scalar("dcl/epoch", dcl_loss, sub_epoch)
                # Visualize weight histograms
                # weight_histograms(writer, sub_epoch, model)


                log_loss['loss'] = 0
                log_loss['align_loss'] = 0

                print(f'step {i_iter+1}: loss: {loss}, dcl_loss: {dcl_loss},')

            if (i_iter + 1) % _config['save_snapshot_every'] == 0:
                _log.info('###### Taking snapshot ######')
                torch.save(model.state_dict(),
                           os.path.join(f'{_run.observers[0].dir}/snapshots', f'{i_iter + 1}.pth'))

            if data_name == 'C0_Superpix' or data_name == 'CHAOST2_Superpix':
                if (i_iter + 1) % _config['max_iters_per_load'] == 0:
                    _log.info('###### Reloading dataset ######')
                    trainloader.dataset.reload_buffer()
                    print(f'###### New dataset with {len(trainloader.dataset)} slices has been loaded ######')

            if (i_iter - 2) > _config['n_steps']:
                return 1 # finish up

