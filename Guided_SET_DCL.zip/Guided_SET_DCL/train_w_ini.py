"""
Training the model
Extended from original implementation of PANet by Wang et al.
"""
import os
import shutil
import torch
import torch.nn as nn
import torch.optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR, CosineAnnealingWarmRestarts
import torch.backends.cudnn as cudnn
import numpy as np

from models.AAS_DCL import AAS_DCL, AAS_DCL_w_ini
from dataloaders.dev_customized_med import med_fewshot
from dataloaders.GenericSuperDatasetv2 import SuperpixelDataset
from dataloaders.ManualAnnoDatasetv5 import ManualAnnoDataset
from dataloaders.dataset_utils import DATASET_INFO
import dataloaders.augutils as myaug
from torch.utils.tensorboard import SummaryWriter

from utils.util import set_seed, t2n, to01, compose_wt_simple
from utils.metrics import Metric
from utils.util import plot_images, vistensor, weight_histograms

from config_ssl_upload import ex
import tqdm

# config pre-trained model caching path
os.environ['TORCH_HOME'] = "./pretrained_model"

@ex.automain
def main(_run, _config, _log):
    if _run.observers:
        os.makedirs(f'{_run.observers[0].dir}/snapshots', exist_ok=True)
        for source_file, _ in _run.experiment_info['sources']:
            os.makedirs(os.path.dirname(f'{_run.observers[0].dir}/source/{source_file}'),
                        exist_ok=True)
            _run.observers[0].save_file(source_file, f'source/{source_file}')
        shutil.rmtree(f'{_run.observers[0].basedir}/_sources')

    set_seed(1234)
    cudnn.enabled = True
    cudnn.benchmark = True
    torch.cuda.set_device(device=_config['gpu_id'])
    torch.set_num_threads(1)

    _log.info('###### Create model ######')
    model = AAS_DCL_w_ini()
    # model = AAS_DCL()

    model = model.cuda()
    # model.load_state_dict(torch.load(_config['reload_model_path']))    

    model.train()

    _log.info('###### Load data ######')
    ### Training set
    data_name = _config['dataset']
    if data_name == 'SABS':
        baseset_name = 'SABS'
    elif data_name == 'C0_Superpix':
        raise NotImplementedError
        baseset_name = 'C0'
    elif data_name == 'CHAOST2_Superpix':
        baseset_name = 'CHAOST2'
    elif data_name == 'CTC_GT_Classic_Correct':
        baseset_name = 'CTC_GT_Classic_Correct'
    else:
        raise ValueError(f'Dataset: {data_name} not found')

    ### Transforms for data augmentation
    tr_transforms = myaug.transform_with_label({'aug': myaug.augs[_config['which_aug']]})
    # assert _config['scan_per_load'] < 0 # by default we load the entire dataset directly

    test_labels = DATASET_INFO[baseset_name]['LABEL_GROUP']['pa_all'] - DATASET_INFO[baseset_name]['LABEL_GROUP'][_config["label_sets"]]
    _log.info(f'###### Labels excluded in training : {[lb for lb in _config["exclude_cls_list"]]} ######')
    _log.info(f'###### Unseen labels evaluated in testing: {[lb for lb in test_labels]} ######')

    # tr_parent = SuperpixelDataset( # base dataset
    #     which_dataset = baseset_name,
    #     base_dir=_config['path'][data_name]['data_dir'],
    #     idx_split = _config['eval_fold'],
    #     mode='train',
    #     min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
    #     transforms=tr_transforms,
    #     nsup = _config['task']['n_shots'],
    #     scan_per_load = _config['scan_per_load'],
    #     exclude_list = _config["exclude_cls_list"],
    #     superpix_scale = _config["superpix_scale"],
    #     fix_length = _config["max_iters_per_load"] if (data_name == 'C0_Superpix') or (data_name == 'CHAOST2_Superpix') else None
    # )

    tr_parent = ManualAnnoDataset( # base dataset
        which_dataset = baseset_name,
        base_dir=_config['path'][data_name]['data_dir'],
        idx_split = _config['eval_fold'],
        mode='train',
        min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
        transforms=tr_transforms,
        nsup = _config['task']['n_shots'],
        scan_per_load = _config['scan_per_load'],
        exclude_list = _config["exclude_cls_list"],
        superpix_scale = _config["superpix_scale"],
        fix_length = _config["max_iters_per_load"] if (data_name == 'C0_Superpix') or (data_name == 'CHAOST2_Superpix') else None
    )

    ### dataloaders
    trainloader = DataLoader(
        tr_parent,
        batch_size=_config['batch_size'],
        shuffle=True,
        num_workers=_config['num_workers'],
        pin_memory=True,
        drop_last=True
    )

    _log.info('###### Set optimizer ######')
    if _config['optim_type'] == 'sgd':
        optimizer = torch.optim.SGD(model.parameters(), **_config['optim'])
    elif _config['optim_type'] == 'adam':
        optimizer = torch.optim.Adam(model.parameters(), **_config['optim'])
    else:
        raise NotImplementedError

    # scheduler = MultiStepLR(optimizer, milestones=_config['lr_milestones'],  gamma = _config['lr_step_gamma'])
    scheduler = CosineAnnealingWarmRestarts(optimizer,T_0=100, T_mult=2,eta_min=1.0e-8)
    my_weight = compose_wt_simple(_config["use_wce"], data_name)
    criterion = nn.CrossEntropyLoss(ignore_index=_config['ignore_label'], weight = my_weight)

    i_iter = 0 # total number of iteration
    n_sub_epoches = _config['n_steps'] // _config['max_iters_per_load'] # number of times for reloading

    log_loss = {'qloss': 0, 'dcl_loss': 0}
    # Initialize the SummaryWriter for TensorBoard
    # Its output will be written to ./runs/
    writer = SummaryWriter()

    _log.info('###### Training ######')
    for sub_epoch in range(n_sub_epoches):
        _log.info(f'###### This is epoch {sub_epoch} of {n_sub_epoches} epoches ######')
        batch_sz = 0
        for _, sample_batched in enumerate(trainloader):
            # Prepare input
            i_iter += 1
            batch_sz += 1
            # add writers
            support_images = [[shot.cuda() for shot in way]
                              for way in sample_batched['support_images']]
            support_labels = [[shot.cuda() for shot in way]
                               for way in sample_batched['support_labels']]
            class_id =  sample_batched['class_ids']   

            nontrgt_images = [nonimg.cuda() for nonimg in sample_batched['nontrgt_images']]
            nontrgt_labels = [nonlabel.cuda() for nonlabel in sample_batched['nontrgt_labels']]
            nontrgt_ids =  sample_batched['nontrgt_ids']                     
            

            query_images = [query_image.cuda()
                            for query_image in sample_batched['query_images']]
            query_labels = torch.cat(
                [query_label.long().cuda() for query_label in sample_batched['query_labels']], dim=0)
            
            query_inilabels = torch.cat(
                [query_inilabel.long().cuda() for query_inilabel in sample_batched['query_inilabels']], dim=0)
            
            # plot_images([support_images[0][0],query_images[0].squeeze()],[support_labels[0][0],query_labels[0,...]], w = 3, title='support')
            # plot_images(nontrgt_images,  nontrgt_labels, w = 3, title='negatives')
            # plot_images([query_images[0].squeeze()],[query_labels[0,...]], [query_inilabels.squeeze()], w = 3, title='query')

            optimizer.zero_grad()
            # FIXME: in the model definition, filter out the failure case where pseudolabel falls outside of image or too small to calculate a prototype
            try:
                query_pred, mse, dcl_loss = model(support_images[0][0], support_labels[0][0], class_id[0][0], query_images[0], query_inilabels, nontrgt_images, nontrgt_labels, nontrgt_ids)                    
                # query_pred, mse, dcl_loss = model(support_images[0][0], support_labels[0][0], class_id[0][0], query_images[0], nontrgt_images, nontrgt_labels, nontrgt_ids)                    

            except:
                print('Faulty batch detected, skip')
                continue

            query_loss = criterion(query_pred, query_labels)
            loss = 0.9*query_loss + 0.1*dcl_loss
            loss.backward()
            optimizer.step()
            scheduler.step(sub_epoch + i_iter/n_sub_epoches)

            # Log loss
            query_loss = query_loss.detach().data.cpu().numpy()
            dcl_loss = dcl_loss.detach().data.cpu().numpy() if dcl_loss != 0 else 0

            _run.log_scalar('loss', query_loss)
            _run.log_scalar('dcl_loss', dcl_loss)
            log_loss['qloss'] += query_loss
            log_loss['dcl_loss'] += dcl_loss

            writer.add_scalar("query", query_loss, i_iter)
            writer.add_scalar("dcl", dcl_loss, i_iter)


            # print loss and take snapshots
            if (i_iter + 1) % _config['print_interval'] == 0:
                print(f'step {i_iter+1}: loss: {loss}, qloss: {query_loss}, dcl_loss: {dcl_loss},')


        query_loss = log_loss['qloss'] / batch_sz
        dcl_loss = log_loss['dcl_loss'] / batch_sz
        # lr = get_lr(optimizer)

        writer.add_scalar("query/epoch", query_loss, sub_epoch)
        writer.add_scalar("dcl/epoch", dcl_loss, sub_epoch)
        # writer.add_scalar("lr/epoch", lr, sub_epoch)
        # Visualize weight histograms
        # weight_histograms(writer, sub_epoch, model)

        log_loss['qloss'] = 0
        log_loss['dcl_loss'] = 0


        # if (i_iter + 1) % _config['save_snapshot_every'] == 0:
        if (sub_epoch+1) % _config['save_snapshot_every'] == 0:
            _log.info('###### Taking snapshot ######')
            torch.save(model.state_dict(),
                        os.path.join(f'{_run.observers[0].dir}/snapshots', f'{sub_epoch}.pth'))

           
            # if (i_iter - 2) > _config['n_steps']:
            #     return 1 # finish up
