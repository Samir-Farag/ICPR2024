"""
Validation script
"""
import os
import shutil
import torch
import torch.nn as nn
import torch.optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import torch.backends.cudnn as cudnn
import numpy as np
import os
import matplotlib.pyplot as plt
# from models.grid_proto_fewshot import FewShotSeg
from models.AAS_DCL import AAS_DCL, AAS_DCL_w_ini
from PIL import Image

from dataloaders.dev_customized_med import med_fewshot_val
# from dataloaders.ManualAnnoDatasetv2 import ManualAnnoDataset
from dataloaders.GenericSuperDatasetv2 import SuperpixelDataset
from dataloaders.ManualAnnoDatasetv5 import ManualAnnoDataset

from dataloaders.dataset_utils import DATASET_INFO, get_normalize_op
from dataloaders.niftiio import convert_to_sitk

from utils.metricV2 import Metric
# from util.metric import Metric
from utils.util import plot_images, vistensor
from config_ssl_upload import ex

import tqdm
import SimpleITK as sitk
from torchvision.utils import make_grid

# config pre-trained model caching path
os.environ['TORCH_HOME'] = "./pretrained_model"

@ex.automain
def main(_run, _config, _log):
        # Create a directory to store intermediate predictions
    intermediate_preds_dir = os.path.join(_run.observers[0].dir, 'interm_preds')
    os.makedirs(intermediate_preds_dir, exist_ok=True)


    if _run.observers:
        os.makedirs(f'{_run.observers[0].dir}/interm_preds', exist_ok=True)
        for source_file, _ in _run.experiment_info['sources']:
            os.makedirs(os.path.dirname(f'{_run.observers[0].dir}/source/{source_file}'),
                        exist_ok=True)
            _run.observers[0].save_file(source_file, f'source/{source_file}')
        shutil.rmtree(f'{_run.observers[0].basedir}/_sources')

    cudnn.enabled = True
    # cudnn.benchmark = True
    torch.cuda.set_device(device=_config['gpu_id'])
    torch.set_num_threads(1)

    _log.info(f'###### Reload model {_config["reload_model_path"]} ######')
    # model = FewShotSeg(pretrained_path = _config['reload_model_path'], cfg=_config['model'])
    model = AAS_DCL_w_ini()
    # model = AAS_DCL()

    model = model.cuda()
    model.load_state_dict(torch.load(_config['reload_model_path']))    
    model.train()

    # prnt_stat_dict = {}
    # for param in model.parameters():
    #     shp = param.shape
    #     if len(shp)>1:
    #         if shp[1]>5:
    #             vistensor(param, ch=5, allkernels=False)
    #         else:
    #             vistensor(param, ch=5, allkernels=True)

    # print(prnt_stat_dict)

    _log.info('###### Load data ######')
    ### Training set
    data_name = _config['dataset']
    if data_name == 'SABS':
        baseset_name = 'SABS'
        max_label = 13
    elif data_name == 'C0_Superpix':
        raise NotImplementedError
        baseset_name = 'C0'
        max_label = 3
    elif data_name == 'CHAOST2_Superpix':
        baseset_name = 'CHAOST2'
        max_label = 4
    elif data_name == 'CTC_GT_Classic_Correct':
        baseset_name = 'CTC_GT_Classic_Correct'
        max_label = 14
    else:
        raise ValueError(f'Dataset: {data_name} not found')

    test_labels = DATASET_INFO[baseset_name]['LABEL_GROUP']['pa_all'] - DATASET_INFO[baseset_name]['LABEL_GROUP'][_config["label_sets"]]

    ### Transforms for data augmentation
    te_transforms = None

    # assert _config['scan_per_load'] < 0 # by default we load the entire dataset directly

    _log.info(f'###### Labels excluded in training : {[lb for lb in _config["exclude_cls_list"]]} ######')
    _log.info(f'###### Unseen labels evaluated in testing: {[lb for lb in test_labels]} ######')

    if baseset_name == 'CTC_GT_Classic_Correct': # for CT we need to know statistics of 
        tr_parent = ManualAnnoDataset( # base dataset   /// use neighbor
            which_dataset = baseset_name,
            base_dir=_config['path'][data_name]['data_dir'],
            idx_split = _config['eval_fold'],
            mode='val',
            min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
            transforms=None,
            nsup = _config['task']['n_shots'],
            scan_per_load = _config['scan_per_load'],
            exclude_list = _config["exclude_cls_list"],
            superpix_scale = _config["superpix_scale"],
            fix_length = _config["max_iters_per_load"] if (data_name == 'C0_Superpix') or (data_name == 'CHAOST2_Superpix') else None
        )
        norm_func = tr_parent.norm_func
    else:
        norm_func = get_normalize_op(modality = 'MR', fids = None)
    
    ### dataloaders
    testloader = DataLoader(
        tr_parent,
        batch_size = 1,
        shuffle=False,
        num_workers=1,
        pin_memory=False,
        drop_last=False
    )

    _log.info('###### Set validation nodes ######')
    n_scans= 128
    mar_val_metric_node = Metric(max_label=max_label, n_scans= n_scans)

    _log.info('###### Starting validation ######')
    mar_val_metric_node.reset()


    _pred={'98':[], '99':[], '100':[], '101':[], '102':[], '103':[], '104':[], '105':[], '106':[], '107':[], '108':[], '109':[], '110':[], '111':[], '112':[],
            '113':[], '114':[], '115':[], '116':[], '117':[], '118':[], '119':[], '120':[], '121':[], '122':[], '123':[], '124':[], '125':[], '126':[], '127':[]}
    _grnd={'98':[], '99':[], '100':[], '101':[], '102':[], '103':[], '104':[], '105':[], '106':[], '107':[], '108':[], '109':[], '110':[], '111':[], '112':[],
            '113':[], '114':[], '115':[], '116':[], '117':[], '118':[], '119':[], '120':[], '121':[], '122':[], '123':[], '124':[], '125':[], '126':[], '127':[]}
    _imgs={'98':[], '99':[], '100':[], '101':[], '102':[], '103':[], '104':[], '105':[], '106':[], '107':[], '108':[], '109':[], '110':[], '111':[], '112':[],
            '113':[], '114':[], '115':[], '116':[], '117':[], '118':[], '119':[], '120':[], '121':[], '122':[], '123':[], '124':[], '125':[], '126':[], '127':[]}
 
    with torch.no_grad():
        save_pred_buffer = {} # indexed by class
        cnt = 0

        while True:
            try:
                sample_batched = tr_parent.get_support_query()
            except:
                break

            # way(1 for now) x part x shot x 3 x H x W] #
            support_images = [[shot.cuda() for shot in way]
                              for way in sample_batched['support_images']]# way x part x [shot x C x H x W]
            support_labels = [[shot.cuda() for shot in way]
                               for way in sample_batched['support_labels']]
            class_ids =  sample_batched['class_ids']   

            nontrgt_images = [itm.cuda() for itm in sample_batched['nontrgt_images']]
            nontrgt_labels = [lb.cuda() for lb in sample_batched['nontrgt_labels']]
            nontrgt_ids =  [i for i  in sample_batched['nontrgt_ids']]                     
            
            query_images = [query_image.cuda()
                            for query_image in sample_batched['query_images']]
            query_labels = torch.cat(
                [query_label.long().cuda() for query_label in sample_batched['query_labels']], dim=0)
            query_inilabels = torch.cat(
                [qlabel.long().cuda() for qlabel in sample_batched['query_inilabels']], dim=0)
            
            stcnt = sample_batched['curr_scan']+'_'+str(cnt)
           
            # plot_images([support_images[0][0]],[support_labels[0][0]], w =0.1, title='sup',cnt=stcnt)           
            # plot_images(nontrgt_images,  nontrgt_labels, w = 0.1, title='unrelated',cnt=stcnt)
            # plot_images(query_images, [query_inilabels], w=0.1, title='qry_ini',cnt=stcnt)
            # plot_images(query_images,[query_labels], w=0.1, title='qry_gt',cnt=stcnt)
            cnt += 1

            query_pred, _, _ = model(support_images[0][0], support_labels[0][0], class_ids[0], query_images[0], query_inilabels, nontrgt_images, nontrgt_labels, nontrgt_ids)                    
            # query_pred, _, _ = model(support_images[0][0], support_labels[0][0], class_ids[0][0], query_images[0], nontrgt_images, nontrgt_labels, nontrgt_ids)
           
            query_pred = np.array(query_pred.argmax(dim=1)[0].cpu())

            # #save predictions
            # # Create a directory to store the prediction images
            # if not os.path.exists('prediction_images'):
            #     os.makedirs('prediction_images')
            # # Create a SimpleITK image from the prediction numpy array
            # prediction_sitk = sitk.GetImageFromArray(query_pred)
            # # Save the prediction SimpleITK image to a file
            # filename = f'prediction_{cnt}.nii.gz'  # Define a unique filename for each prediction
            # sitk.WriteImage(prediction_sitk, filename)
            # # #save predictions


            _pred[sample_batched['curr_scan']].append(query_pred.copy())
            _grnd[sample_batched['curr_scan']].append(np.array(query_labels[0].cpu()).copy())
            im = query_images[0].squeeze().permute((1,2,0))
            _imgs[sample_batched['curr_scan']].append(im.cpu().numpy().copy())
            mar_val_metric_node.record(query_pred, np.array(query_labels[0].cpu()), labels=sample_batched['class_ids'][0], n_scan=int(sample_batched['curr_scan'])) 

            # # #save predictions
            # for idx, curr_lb in enumerate(sample_batched['class_ids'][0]):
            #     # print(type(curr_lb))
            #     if curr_lb not in save_pred_buffer:
            #         save_pred_buffer[curr_lb] = {}
            #     save_pred_buffer[curr_lb][sample_batched['curr_scan'][idx]] = query_pred.copy()
            # # #save predictions

    del sample_batched, support_images, query_images, query_labels, query_pred


    # Saving predictions

    # for curr_lb, _preds in save_pred_buffer.items():
    #     for _scan_id, _pred in _preds.items():
    #         if _scan_id in tr_parent.info_by_scan:
    #             itk_pred = convert_to_sitk(_pred, tr_parent.info_by_scan[_scan_id])
    #             file_path = os.path.join(intermediate_preds_dir, f'prediction_scan_{_scan_id}_label_{curr_lb}.nii.gz')
    #             sitk.WriteImage(itk_pred, file_path, True)
    #             _log.info(f'Prediction saved: {file_path}')
    #         else:
    #             # Handle the case when the scan ID is not found
    #             print(f"Scan ID {_scan_id} not found in tr_parent.info_by_scan")

    # Saving predictions
    non_empty_elements = {key: value for key, value in _pred.items() if value}
    for key in non_empty_elements.keys():
    # for key in _pred.keys():
        itk_pred = sitk.GetImageFromArray(np.array(_pred[key]))
        file_path = os.path.join(intermediate_preds_dir, f'prediction_scan_{key}.nii.gz')
        sitk.WriteImage(itk_pred, file_path, True)

        itk_grnd= sitk.GetImageFromArray(np.array(_grnd[key]))
        file_path = os.path.join(intermediate_preds_dir, f'grnd_scan_{key}.nii.gz')
        sitk.WriteImage(itk_grnd, file_path, True)

        itk_imgs= sitk.GetImageFromArray(np.array(_imgs[key]))
        file_path = os.path.join(intermediate_preds_dir, f'ct_scan_{key}.nii.gz')
        sitk.WriteImage(itk_imgs, file_path, True)

        _log.info(f'Prediction saved: {key}')

    # for curr_lb, _preds in _pred.items():
    #     for _scan_id, _pred in _preds.items():
    #         if _scan_id in tr_parent.info_by_scan:
    #             itk_pred = convert_to_sitk(_pred, tr_parent.info_by_scan[_scan_id])
    #             file_path = os.path.join(intermediate_preds_dir, f'prediction_scan_{_scan_id}_label_{curr_lb}.nii.gz')
    #             try:
    #                 sitk.WriteImage(itk_pred, file_path, True)
    #                 _log.info(f'Prediction saved: {file_path}')
    #             except Exception as e:
    #                 _log.error(f'Error saving prediction for scan {_scan_id} and label {curr_lb}: {e}')
    #         else:
    #             # Handle the case when the scan ID is not found
    #             _log.warning(f"Scan ID {_scan_id} not found in tr_parent.info_by_scan")

    # # compute dice scores by scan
    m_classDice,_, m_meanDice,_, m_rawDice = mar_val_metric_node.get_mDice(labels=sorted(test_labels), n_scan=None, give_raw = True)
    # Compute mean IoU
    mIoU_class,_, mIoU_mean,_= mar_val_metric_node.get_mIoU(labels=list(test_labels), n_scan=None)

    m_classPrec,_, m_meanPrec,_,  m_classRec,_, m_meanRec,_, m_rawPrec, m_rawRec = mar_val_metric_node.get_mPrecRecall(labels=sorted(test_labels), n_scan=None, give_raw = True)

    mar_val_metric_node.reset() # reset this calculation node

    # write validation result to log file
    _run.log_scalar('mar_val_batches_classDice', m_classDice.tolist())
    _run.log_scalar('mar_val_batches_meanDice', m_meanDice.tolist())
    _run.log_scalar('mar_val_batches_rawDice', m_rawDice.tolist())


  # write validation result to log file
    _run.log_scalar('mar_val_batches_classIoU', mIoU_class.tolist())
    _run.log_scalar('mar_val_batches_meanIoU', mIoU_mean.tolist())


    _run.log_scalar('mar_val_batches_classPrec', m_classPrec.tolist())
    _run.log_scalar('mar_val_batches_meanPrec', m_meanPrec.tolist())
    _run.log_scalar('mar_val_batches_rawPrec', m_rawPrec.tolist())

    _run.log_scalar('mar_val_batches_classRec', m_classRec.tolist())
    _run.log_scalar('mar_val_al_batches_meanRec', m_meanRec.tolist())
    _run.log_scalar('mar_val_al_batches_rawRec', m_rawRec.tolist())

    _log.info(f'mar_val batches classDice: {m_classDice}')
    _log.info(f'mar_val batches meanDice: {m_meanDice}')
    
    _log.info(f'mar_val batches classIoU: {mIoU_class}')
    _log.info(f'mar_val batches meanIoU: {mIoU_mean}')

    _log.info(f'mar_val batches classPrec: {m_classPrec}')
    _log.info(f'mar_val batches meanPrec: {m_meanPrec}')

    _log.info(f'mar_val batches classRec: {m_classRec}')
    _log.info(f'mar_val batches meanRec: {m_meanRec}')

    print("============ ============")

    _log.info(f'End of validation')
    return 1


