#==================================
import nibabel as nib
import numpy as np
import matplotlib.pyplot as plt
import glob
import nibabel as nib
import numpy as np
import matplotlib.pyplot as plt
import glob
import json
import SimpleITK as sitk


# DATASET='CTC68_SABS30_Correct/test'

# root_img = '/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/data/CTC_Correct_Ordering/Image.nii.gz'
# root_img_path = '/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/data'
root_label= '/mnt/Shared/Asem/Colon/AAS-DCL_FSS-main_oldserver/tmp_runs/myDCL__CTC_GT_Classic_Correct_sets_0_1shot/ct_pred_GT98_127/interm_preds'
# basemodel_lab_path= f"/media/hd1/colon_sample/samir/ICIP_metrics/metrics_eval/EvaluateSegmentation-master/source/TestSuite"
volume_index=0
################################################ Load orignal Images&Labels nii.gz files ############################################## 
DATA_IMGS = glob.glob(root_label + '/ct_scan*.nii.gz') 
DATA_IMGS = [fid for fid in sorted(DATA_IMGS, key=lambda x: int(x.split("_")[-1].split(".")[0]))] # DATA_IMGS = [fid for fid in sorted(DATA_IMGS)]
print(f'All Image volumes are: {len(DATA_IMGS)}')

DATA_LABLS_GT = glob.glob(root_label + '/grnd_scan*.nii.gz') 
DATA_LABLS_GT = [fid for fid in sorted(DATA_LABLS_GT, key=lambda x: int(x.split("_")[-1].split(".")[0]))] # DATA_LABLS = [fid for fid in sorted(DATA_LABLS)]

DATA_LABLS_PRD = glob.glob(root_label + '/prediction_scan*.nii.gz') 
DATA_LABLS_PRD = [fid for fid in sorted(DATA_LABLS_PRD, key=lambda x: int(x.split("_")[-1].split(".")[0]))] # DATA_LABLS = [fid for fid in sorted(DATA_LABLS)]


nii_ct = sitk.ReadImage(DATA_IMGS[volume_index]) #DICOM slices
# nii_img = sitk.ReadImage(root_img_path + '/TCIA_classic_clean103/image/img_3.000000-NA-18592_supine_tcia_1.nii.gz') #DICOM slices
nii_data_ct = sitk.GetArrayFromImage(nii_ct)
print('shape of orignal image vlume:', nii_data_ct.shape) #num_slices_img = nii_data_img.shape[2] # slice_index_img = num_slices_img // 2
# DATA_LABLS_PRD[volume_index]

nii_GT = sitk.ReadImage(DATA_LABLS_GT[volume_index]) #DICOM slices
nii_data_labelGT= sitk.GetArrayFromImage(nii_GT)
print('shape of orignal image vlume:', nii_data_labelGT.shape) #num_slices_img = nii_data_img.shape[2] # slice_index_img = num_slices_img // 2

nii_pred= sitk.ReadImage(DATA_LABLS_PRD[volume_index]) #DICOM slices
nii_data_lablPRD = sitk.GetArrayFromImage(nii_pred)

print('shape of label vlume:', nii_data_lablPRD.shape)

#### Load basemodel Labels nii.gz files####
# nii_label_base = nib.load(basemodel_lab_path + '/test_volumes_Basemodel/Seg_45s.nii.gz')  # Ground truth labels
# nii_data_labl_base = nii_label_base.get_fdata()

# nii_label_base = sitk.ReadImage(basemodel_lab_path + '/test_volumes_Basemodel/Seg_50s.nii.gz')  
# nii_data_labl_base = sitk.GetArrayFromImage(nii_label_base)
# print('shape of label vlume:', nii_data_labl_base.shape)

print(f'Maximum value of orignal image slice: {nii_data_ct.max()}\n and minmum value is {nii_data_ct.min()}')
print(f'Maximum value label slice: {nii_data_labelGT.max()}\n and minmum value is {nii_data_labelGT.min()}')
print(f'Maximum value label slice: {nii_data_lablPRD.max()}\n and minmum value is {nii_data_lablPRD.min()}')


print('-' * 121) 

# plt.ion()
# plt.show()
# plt.subplots_adjust(wspace=0.5)  # Adjust the horizontal space between subplots
plt.figure(figsize=(12, 5))  # Set the figure size

for x in range(0, min(nii_data_labelGT.shape[0], nii_data_labelGT.shape[0]) , 3):
    if nii_data_labelGT.shape[0]>200: # this condition since the SABS data is around 100 slices, whereas CTC data is around 300 slices
        slice_index = x + 100
    else:
        slice_index = x + 20

    plt.subplot(1, 3, 2)
    if slice_index < nii_data_labelGT.shape[0]:
        plt.imshow(nii_data_labelGT[slice_index, :, :], cmap='gray')
        plt.axis('off')
        plt.title(f'Axial slice GT label {slice_index} - Image')

    plt.subplot(1, 3, 3)
    if slice_index < nii_data_lablPRD.shape[0]:
        plt.imshow(nii_data_lablPRD[slice_index, :, :], cmap='gray')
        plt.axis('off')
        plt.title(f'Axial slice {slice_index} - Pred label')

    plt.subplot(1, 3, 1)
    if slice_index < nii_data_ct.shape[0]:
        img = nii_data_ct[slice_index, :, :] - nii_data_ct[slice_index, :, :].min()
        img = img/img.max()
        plt.imshow(img)
        plt.axis('off')
        plt.title(f'Axial slice {slice_index} CT')
    plt.draw()
    plt.pause(.1)
