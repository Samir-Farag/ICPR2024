"""
Experiment configuration file
Extended from config file from original PANet Repository
"""
import os
import re
import glob
import itertools

import sacred
from sacred import Experiment
from sacred.observers import FileStorageObserver
from sacred.utils import apply_backspaces_and_linefeeds

from platform import node
from datetime import datetime

sacred.SETTINGS['CONFIG']['READ_ONLY_CONFIG'] = False
sacred.SETTINGS.CAPTURE_MODE = 'no'

# ex = Experiment('CTC68_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569_TestCTC30')
# ex=Experiment('SABS30_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569_TestCTC30')
#
# ex=Experiment('SABS30_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_TestCTC30')
ex=Experiment('LAST_CTC_68_SABS30_Train_100k_setting1_labelinsteadof_superpix_dlfcn_res101')

# ex=Experiment('SABS30_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101')
# ex=Experiment('SABS30_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_TestCTC30')

# ex=Experiment('CTC68_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101')

# ex= Experiment('mySSL_CTC_updated') # This will be overrided by value given by the value when we run training or testing using .sh file
# ex = Experiment('mySSL')
ex.captured_out_filter = apply_backspaces_and_linefeeds

source_folders = ['.', './dataloaders', './models', './util']
sources_to_save = list(itertools.chain.from_iterable(
    [glob.glob(f'{folder}/*.py') for folder in source_folders]))
for source_file in sources_to_save:
    ex.add_source_file(source_file)

@ex.config
def cfg():
    """Default configurations"""
    seed = 1234
    gpu_id = 0
    mode = 'train' # for now only allows 'train' 
    # mode= 'valid'
    num_workers = 4 # 0 for debugging. 
    # dataset= 'CTC_SABS_Correct_Train'
    # dataset= 'CTC_SABS_Correct_Test'
    dataset='CTC68_SABS30_Correct_Train'


    # dataset= 'CTC_SABS'
    # dataset='CTC_Correct_60Train'
    # dataset='CTC_Correct_38Test'

    # dataset= 'CTC_SABS_Correct_30ctc'

    use_coco_init = True # initialize backbone with MS_COCO initialization. Anyway coco does not contain medical images

    ################################################### Training ###################################################
    n_steps = 100100
    batch_size = 1
    lr_milestones = [ (ii + 1) * 1000 for ii in range(n_steps // 1000 - 1)]
    lr_step_gamma = 0.95
    ignore_label = 255
    print_interval = 100
    save_snapshot_every = 25000
    max_iters_per_load = 1000#1000 # epoch size, interval for reloading the dataset
    scan_per_load = -1 # numbers of 3labwd scans per load for saving memory. If -1, load the entire dataset to the memory
    # which_aug = 'sabs_aug_CTC' # standard data augmentation with intensity and geometric transforms
    which_aug = 'sabs_aug' # standard data augmentation with intensity and geometric transforms
    input_size = (256, 256)
    # input_size = (256, 256)

    min_fg_data='1' # when training with manual annotations, indicating number of foreground pixels in a single class single slice. This empirically stablizes the training process
    # label_sets = 0 # which group of labels taking as training (the rest are for testing)
    # exclude_cls_list = [2, 3] # testing classes to be excluded in training. Set to [] if testing under setting 1

    # label_sets = 1 # which group of labels taking as training (the rest are for testing)
    # exclude_cls_list = [1, 6] # testing classes to be excluded in training. Set to [] if testing under setting 1


    label_sets = 0 # which group of labels taking as training (the rest are for testing)
    # label_sets= 1 # 
    # exclude_cls_list = [14] # sETTING 2: COLON testing classes to be excluded in training. Set to [] if testing under setting 1
    exclude_cls_list = [] #SETTING 1

    usealign = True # see vanilla PANet
    use_wce = True

    ################################################### Validation ###################################################
    z_margin = 0 
    # With cross validation
    # eval_fold =(0, 1, 2, 3, 4, 5, 6)# which fold for 5 fold cross validation
    # Without cross validation:
    eval_fold =(0)
    # support_idx=[6] # indicating which scan is used as support in testing. for the 128 scan and partition the colon scans as #[30, 42, 54, 66, 78, 90, 102, 114, 126]
    support_idx=[2] # indicating which scan is used as support in testing. for the 60 scan and partition the colon scans as ## [30, 34, 38, 42, 46, 50, 54, 58]

    val_wsize=2 # L_H, L_W in testing
    n_sup_part = 3 # number of chuncks in testing


    ################################################### Network ###################################################
#https://pytorch.org/vision/main/models.html
    # DeepLabV3_ResNet50_Weights.COCO_WITH_VOC_LABELS_V1: 66.4 92.4 42.0M  178.72
    # modelname ='dlfcn_res101' # resnet 101 backbone from torchvision fcn-deeplab
    clsname ='grid_proto' # 
    
    modelname='dlv3_res50'
    # # First 100k epoch-trained model using Pesudo labels + setting 1 (i.e. using all 14 labels in training witout any execluding)
    # reload_model_path=RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs/CTC_SABS_90Train_100k_setting1_superpix_38Test/CTC_SABS_Correct_Train_train_CTC_SABS_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC_SABS_Correct_Train_sets_0_1shot/1/snapshots/100000.pth' 
    
    # Second 100k epoch-trained model changing superpix- in GenericSuperDatasetv2.py to labels + setting 1 (i.e. using all 14 labels in training witout any execluding)
    # reload_model_path=RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs/CTC_SABS_90Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/CTC_SABS_Correct_Train_train_CTC_SABS_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC_SABS_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    reload_model_path='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs/CTC_SABS_60Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/CTC_60Correct_Trian_temp_train_CTC_Correct_60Train_lbgroup0_scale_MIDDLE_vfold0_CTC_Correct_60Train_sets_0_1shot/1/snapshots/100000.pth'
    
    proto_grid_size = 8 # L_H, L_W = (32, 32) / 8 = (4, 4)  in training
    feature_hw = [32, 32] # feature map size, should couple this with backbone in future

    # SSL
    superpix_scale = 'MIDDLE' #MIDDLE/ LARGE

    model = {
        'align': usealign,
        'use_coco_init': use_coco_init,
        'which_model': modelname,
        'cls_name': clsname,
        'proto_grid_size' : proto_grid_size,
        'feature_hw': feature_hw,
        'reload_model_path': reload_model_path
    }

    task = {
        'n_ways': 1,
        'n_shots': 1,
        'n_queries': 1,
        'npart': n_sup_part 
    }

    optim_type = 'sgd'
    optim = {
        'lr': 1e-3, 
        'momentum': 0.9,
        'weight_decay': 0.0005,
    }

    exp_prefix = ''

    exp_str = '_'.join(
        [exp_prefix]
        + [dataset,]
        + [f'sets_{label_sets}_{task["n_shots"]}shot'])

    path = {
        # 'log_dir': './runs',
        'log_dir': './runs_temp',
        # 'log_dir': './exps',  # when you run training from the training.py file itself
        'SABS':{'data_dir': "./data/SABS/sabs_CT_normalized1"},        
        'CTC_SABS_Correct_Train':{'data_dir': "./data/CTC_SABS_Correct/train/sabs_CT_normalized_90scan"}, # 30 scan of SABS + 60 CTC scan (30 prone + 30 supine)
        'CTC_SABS_Correct_Test':{'data_dir': "./data/CTC_SABS_Correct/test/sabs_CT_normalized_38scan"}, # 38 CTC scan (19 prone + 19 supine)
        'CTC_Correct_10Test':{'data_dir': "./data/CTC_SABS_Correct/test10/CTC_normalized_10scan"}, # 10 CTC scan (5 prone + 5 supine)  (prone31 --> prone 35 & supine31 --> supine 35)

        
        'CTC_Correct_60Train':{'data_dir': "./data/CTC_Correct60/train/CTC_normalized_60scan"}, # 60 CTC scan (30 prone + 30 supine)
        'CTC_Correct_38Test':{'data_dir': "./data/CTC_Correct60/test/CTC_normalized_38scan"}, # 38 CTC scan (19 prone + 19 supine)

        'CTC68_SABS30_Correct_Train':{'data_dir': "./data/CTC68_SABS30_Correct/train/sabs_CT_normalized_98scan"}, # 30 scan of SABS + 68 CTC scan (30 prone + 30 supine)
        'CTC_Correct_18Test':{'data_dir': "./data/CTC68_SABS30_Correct/test/CTC_normalized_18scan"}, # 18 CTC scan (pro_35-->pro_44 prone + sup_35-->sup_44 supine)
        'CTC_Correct_30Test':{'data_dir': "/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/data/CTC68_SABS30_Correct/test/CTC_normalized_30scan"}, # 30 CTC scan (pro_35, pro_38, pro_38-->pro_50 prone + sup_35, sup_36, sup_38-->sup_50 supine)
        'CTC68_Correct_Train':{'data_dir': "./data/CTC_Correct68/train/CTC_normalized_68scan"}, # 68 CTC scan (30 prone + 30 supine)

        'CTC_SABS_Correct_30ctc':{'data_dir': "./data/CTC_SABS_Correct_30ctc/train/sabs_CT_normalized_60scan"}, # 30 scan of SABS + 30 scan of SABS + 30 CTC scan (15 prone + 15 supine) (prone1 --> prone 15 & supine --> supine 15)
        # 'CTC_Correct_10Test':{'data_dir': "./data/CTC_SABS_Correct_30ctc/test/CTC_normalized_10scan"}, # 10 CTC scan (5 prone + 5 supine)  (prone16 --> prone 20 & supine16 --> supine 20)
        }


@ex.config_hook
def add_observer(config, command_name, logger):
    """A hook fucntion to add observer"""
    exp_name = f'{ex.path}_{config["exp_str"]}'
    observer = FileStorageObserver.create(os.path.join(config['path']['log_dir'], exp_name))
    ex.observers.append(observer)
    return config




# DATASET_INFO = {
#     "CHAOST2": {
#             'PSEU_LABEL_NAME': ["BGD", "SUPFG"],
#             'REAL_LABEL_NAME': ["BG", "LIVER", "RK", "LK", "SPLEEN"],
#             '_SEP': [0, 4, 8, 12, 16, 20],
#             'MODALITY': 'MR',
#             'LABEL_GROUP': {
#                 'pa_all': set(range(1, 5)),
#                 0: set([1, 4]), # upper_abdomen, leaving kidneies as testing classes
#                 1: set([2, 3]), # lower_abdomen
#                 },
#             },

#     "SABS": {
#             'PSEU_LABEL_NAME': ["BG", "SUPFG"],

#             'REAL_LABEL_NAME': ["BG", "SPLEEN", "KID_R", "KID_L", "GALLBLADDER", "ESOPHAGUS", "LIVER", "STOMACH", "AORTA", "IVC",\
#               "PS_VEIN", "PANCREAS", "AG_R", "AG_L"],
#             '_SEP': [0, 6, 12, 18, 24, 30],
#             'MODALITY': 'CT',
#             'LABEL_GROUP':{
#                 'pa_all': set( [1,2,3,6]  ),
#                 0: set([1,6]  ), # upper_abdomen: spleen + liver as training, kidneis are testing
#                 1: set( [2,3] ), # lower_abdomen
#                     }
#             }
