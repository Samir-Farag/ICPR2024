#!/bin/bash
 
# ./examples/test_ssl_abdominal_ct.sh
GPUID1=1
export CUDA_VISIBLE_DEVICES=$GPUID1

####### Shared configs ######
PROTO_GRID=8 # using 32 / 8 = 4, 4-by-4 prototype pooling window during training

# DATASET='CTC_SABS_Correct_Test' # Dataset to test with
# CPT="CTC_SABS_90Train_100k_setting1_superpix_38Test"

# DATASET='CTC_SABS_Correct_Train' # Dataset to test with
# CPT="CTC_SABS_90Train_100k_setting1_superpix_90Test"

# DATASET='CTC_SABS_Correct_Test' # Dataset to test with
# CPT="CTC_SABS_90Train_100k_setting1_labelinsteadof_superpix_38Test"

# DATASET='CTC_SABS_Correct_Train' # Dataset to test with
# CPT="SABS_30_Train_100k_setting1_labelinsteadof_superpix_CTC18Test"
# CPT="SABS_30_CTC68_Train_100k_setting1_labelinsteadof_superpix_CTC18Test"
# CPT="CTC_68_Train_100k_setting1_labelinsteadof_superpix_CTC30Test"
# CPT="CTC68_SABS30_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_TestCTC30"
# CPT="CTC68_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_TestCTC30"
# CPT="SABS30_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_TestCTC30"
CPT="Modified_spatialattention_CTC_68_SABS30_Train_100k_setting1_labelinsteadof_superpix_dlfcn_res101_TestCTC30"


# DATASET=CTC_Correct_38Test # or "CTC_Correct_38Test" ____________good
DATASET='CTC_Correct_30Test'
# CPT="Samir_CTC60_SABS30_Train_100k_setting1_labelinsteadof_superpix_10Test" # 30 SABS + 30 CTC
# DATASET="CTC_Correct_10Test"

NWORKER=4

# # CTC_SABS Dataset 
# ALL_EV=(0, 1, 2, 3, 4, 5, 6, 7) # using 128 scans; 30 SABS + 98 CTC: np.arange(30,128,12).tolist()  ---> [30, 42, 54, 66, 78, 90, 102, 114, 126]
# import numpy as np; np.arange(30,128,12).tolist()
# [30, 42, 54, 66, 78, 90, 102, 114, 126]
# ALL_EV=(7) #5-fold cross validation #ALL_EV=(0)for one fold for testing code harmony  

# ALL_EV=(14) # using 128 scans; 30 SABS + 30 CTC: np.arange(30,60,4).tolist()  ---> [30, 34, 38, 42, 46, 50, 54, 58]
ALL_EV=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14) # cover 38 ctc scans
# ALL_EV=(0, 1, 2, 3, 4, 5, 6, 7, 8) # cover 18 ctc scans

## CTC_SABS DAataset
# ALL_EV=(8) # Here, we are testing with the trained model of fold 0
# ALL_EV=(0, 1, 2, 3, 4) # 3-fold  #(0) # one fold # 5-fold cross validation (0, 1, 2, 3, 4)
ALL_SCALE=( "MIDDLE") # config of pseudolabels

# ### Use L/R kidney as testing classes
# LABEL_SETS=0 
# EXCLU='[2,3]' # setting 2: excluding kidneies in training set to test generalization capability even though they are unlabeled. Use [] for setting 1 by Roy et al.

## Use Liver and spleen as testing classes
# LABEL_SETS=1 
# EXCLU='[1,6]' 
### Use COLON as testing class
LABEL_SETS=0
# EXCLU='[14]' # setting2
EXCLU='[]' # setting1

###### Training configs (irrelavent in testing) ######
NSTEP=100100
DECAY=0.95

MAX_ITER=1000 # defines the size of an epoch
SNAPSHOT_INTERVAL=25000 # interval for saving snapshot
SEED='1234'

###### Validation configs ######
# SUPP_ID='[6]' # using the additionally loaded scan as support for the 128 scan and partition the colon scans as #[30, 42, 54, 66, 78, 90, 102, 114, 126]
SUPP_ID='[2]' # indicating which scan is used as support in testing. for the 60 scan and partition the colon scans as ## [30, 34, 38, 42, 46, 50, 54, 58]


echo ===================================

for EVAL_FOLD in "${ALL_EV[@]}"
do
    for SUPERPIX_SCALE in "${ALL_SCALE[@]}"
    do
    PREFIX="test_vfold${EVAL_FOLD}"
    echo $PREFIX
    LOGDIR="./temp_exps_temp/${CPT}"
    # LOGDIR="./exps/${CPT}"

    if [ ! -d $LOGDIR ]
    then
        mkdir $LOGDIR
    fi

    #RELOAD_PATH='please feed the path to the trained weights here' # path to the reloaded model
    # Training SSL-ALPNet model with 90 scans (30 scans SABS + 30 prone scans CTC + 30 supine scans CTC)
    # Testing SSL-ALPNet model with 38 scans (19 prone scans CTC + 19 supine scans CTC)
    
    # First 100k epoch-trained model using Pesudo labels + setting 1 (i.e. using all 14 labels in training witout any execluding)
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs/CTC_SABS_90Train_100k_setting1_superpix_38Test/CTC_SABS_Correct_Train_train_CTC_SABS_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC_SABS_Correct_Train_sets_0_1shot/1/snapshots/100000.pth' 
    
    
    # # Second 100k epoch-trained model changing superpix- in GenericSuperDatasetv2.py to labels + setting 1 (i.e. using all 14 labels in training witout any execluding)
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs/CTC_SABS_90Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/CTC_SABS_Correct_Train_train_CTC_SABS_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC_SABS_Correct_Train_sets_0_1shot/1/snapshots/100000.pth' # 30SABS + 60CTC train and 38 CTC test

    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs/CTC_SABS_60Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/CTC_60Correct_Trian_temp_train_CTC_Correct_60Train_lbgroup0_scale_MIDDLE_vfold0_CTC_Correct_60Train_sets_0_1shot/1/snapshots/100000.pth'

    #30SABS
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/SABS30_Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/SABS30_CTC30_Correct_Trian_train_SABS_lbgroup0_scale_MIDDLE_vfold0_SABS_sets_0_1shot/1/snapshots/100000.pth' # trained on 30 SABS scans
    

    # 30SABS + 68CTC
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/SABS30_CTC68__Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/SABS30_CTC68_Correct_Trian_train_CTC68_SABS30_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC68_SABS30_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    # # 68CTC
    RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/CTC68__Train_100k_setting1_labelinsteadof_superpix_MIDDLE_0/SABS30_CTC68_Correct_Trian_train_CTC68_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC68_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'

    # 30SABS+68CTC  and deeplabv3_renet50 backbone
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/CTC68_SABS30_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569__CTC68_SABS30_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    # 68CTC deeplabv3_renet50 backbone
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/CTC68_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569_MIDDLE_0/CTC68_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569_train_CTC68_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC68_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    # 30SABS deeplabv3_renet50 backbone
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/SABS30_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569_MIDDLE_0/SABS30_Train_100k_setting1_labelinsteadof_superpix_deeplabv3_resnet50_coco_cd0a2569_TestCTC30_train_SABS_lbgroup0_scale_MIDDLE_vfold0_SABS_sets_0_1shot/1/snapshots/100000.pth'
    
    # 30SABS+68CTC and fcn_resnet101 backbone
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/CTC68_SABS30_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_MIDDLE_0/CTC68_SABS30_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_train_CTC68_SABS30_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC68_SABS30_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    # 30SABS+68CTC and fcn_resnet101 backbone
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/CTC68_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_MIDDLE_0/CTC68_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_train_CTC68_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC68_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    # 68CTC and fcn_resnet101 backbone
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/CTC68_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_MIDDLE_0/CTC68_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_train_CTC68_Correct_Train_lbgroup0_scale_MIDDLE_vfold0_CTC68_Correct_Train_sets_0_1shot/1/snapshots/100000.pth'
    #30SABS
    # RELOAD_PATH='/media/hd1/colon_sample/samir/Few_shotsgementation/Self-supervised-Fewshot-Medical-Image-Segmentation-master/runs_temp/SABS30_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_MIDDLE_0/SABS30_Correct_Train_100k_setting1_labelinsteadof_superpix_fcn_resnet101_train_SABS_lbgroup0_scale_MIDDLE_vfold0_SABS_sets_0_1shot/1/snapshots/100000.pth'

    # Choose between different encoders but adjust get_encoder in grid_proto_fewshot.py
    #old setting
    # 'modelname=dlfcn_res101' \
    MODELNAME='dlfcn_res101'  # first encoder tried
    # MODELNAME='dlv3_res50'  # second encoder
    # MODELNAME='fcn_resnet101'
    # MODELNAME='PL_LightingResnest200eEncoder'
    python3 validation.py with \
    modelname=$MODELNAME \
    'usealign=True' \
    'optim_type=sgd' \
    reload_model_path=$RELOAD_PATH \
    num_workers=$NWORKER \
    scan_per_load=-1 \
    label_sets=$LABEL_SETS \
    'use_wce=True' \
    exp_prefix=$PREFIX \
    'clsname=grid_proto' \
    n_steps=$NSTEP \
    exclude_cls_list=$EXCLU \
    eval_fold=$EVAL_FOLD \
    dataset=$DATASET \
    proto_grid_size=$PROTO_GRID \
    max_iters_per_load=$MAX_ITER \
    min_fg_data=1 seed=$SEED \
    save_snapshot_every=$SNAPSHOT_INTERVAL \
    superpix_scale=$SUPERPIX_SCALE \
    lr_step_gamma=$DECAY \
    path.log_dir=$LOGDIR \
    support_idx=$SUPP_ID
    done
done
