"""
Backbones supported by torchvison.
"""
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F

import torchvision

import segmentation_models_pytorch as smp
import pytorch_lightning as pl
import segmentation_models_pytorch as smp
import torch.nn as nn
import segmentation_models_pytorch as smp
import torch.nn as nn

class TVDeeplabRes101Encoder(nn.Module):
    """
    FCN-Resnet101 backbone from torchvision deeplabv3
    No ASPP is used as we found emperically it hurts performance
    """
    def __init__(self, use_coco_init, aux_dim_keep = 64, use_aspp = False):
        super().__init__()
        _model = torchvision.models.segmentation.deeplabv3_resnet101(pretrained=use_coco_init, progress=True, num_classes=21, aux_loss=None)
        if use_coco_init:
            print("###### NETWORK: Using ms-coco initialization ######")
        else:
            print("###### NETWORK: Training from scratch ######")

        _model_list = list(_model.children())
        self.aux_dim_keep = aux_dim_keep
        self.backbone = _model_list[0]
        self.localconv = nn.Conv2d(2048, 256,kernel_size = 1, stride = 1, bias = False) # reduce feature map dimension
        self.asppconv = nn.Conv2d(256, 256,kernel_size = 1, bias = False)

        _aspp = _model_list[1][0]
        _conv256 = _model_list[1][1]
        self.aspp_out = nn.Sequential(*[_aspp, _conv256] )
        self.use_aspp = use_aspp

    def forward(self, x_in, low_level):
        """
        Args:
            low_level: whether returning aggregated low-level features in FCN
        """
        fts = self.backbone(x_in)
        if self.use_aspp:
            fts256 = self.aspp_out(fts['out'])
            high_level_fts = fts256
        else:
            fts2048 = fts['out']
            high_level_fts = self.localconv(fts2048)

        if low_level:
            low_level_fts = fts['aux'][:, : self.aux_dim_keep]
            return high_level_fts, low_level_fts
        else:
            return high_level_fts

# modified on Wednesday 27, 2024

class TVDeeplabRes50Encoder(nn.Module):
    def __init__(self, use_coco_init, aux_dim_keep=64, use_aspp=False):
        super().__init__()
        _model = torchvision.models.segmentation.deeplabv3_resnet50(pretrained=use_coco_init, progress=True, num_classes=21, aux_loss=None)
        if use_coco_init:
            print("###### NETWORK: Using MS COCO initialization ######")
        else:
            print("###### NETWORK: Training from scratch ######")

        _model_list = list(_model.children())
        self.aux_dim_keep = aux_dim_keep
        self.backbone = _model_list[0]
        self.localconv = nn.Conv2d(2048, 256, kernel_size=1, stride=1, bias=False)  # reduce feature map dimension
        self.asppconv = nn.Conv2d(256, 256, kernel_size=1, bias=False)

        if use_aspp:
            _aspp = _model_list[1][0]
            _conv256 = _model_list[1][1]
            self.aspp_out = nn.Sequential(*[_aspp, _conv256])
        self.use_aspp = use_aspp

    def forward(self, x_in, low_level):
        fts = self.backbone(x_in)
        if self.use_aspp:
            fts256 = self.aspp_out(fts['out'])
            high_level_fts = fts256
        else:
            fts2048 = fts['out']
            high_level_fts = self.localconv(fts2048)

        if low_level:
            low_level_fts = fts['aux'][:, :self.aux_dim_keep]
            return high_level_fts, low_level_fts
        else:
            return high_level_fts

# modified on Thursday 28, 2024

class TV_FCN_ResNet101Encoder(nn.Module):
    def __init__(self, use_coco_init, aux_dim_keep=64, use_aspp=False):
        super().__init__()
        # _model = torchvision.models.segmentation.FCN_ResNet101_Weights(pretrained=use_coco_init, progress=True, num_classes=21, aux_loss=None)
        _model = torchvision.models.segmentation.fcn_resnet101(pretrained=use_coco_init, progress=True, num_classes=21, aux_loss=None)

        if use_coco_init:
            print("###### NETWORK: Using MS COCO initialization ######")
        else:
            print("###### NETWORK: Training from scratch ######")

        _model_list = list(_model.children())
        self.aux_dim_keep = aux_dim_keep
        self.backbone = _model_list[0]
        self.localconv = nn.Conv2d(2048, 256, kernel_size=1, stride=1, bias=False)  # reduce feature map dimension
        self.asppconv = nn.Conv2d(256, 256, kernel_size=1, bias=False)

        if use_aspp:
            _aspp = _model_list[1][0]
            _conv256 = _model_list[1][1]
            self.aspp_out = nn.Sequential(*[_aspp, _conv256])
        self.use_aspp = use_aspp

    def forward(self, x_in, low_level):
        fts = self.backbone(x_in)
        if self.use_aspp:
            fts256 = self.aspp_out(fts['out'])
            high_level_fts = fts256
        else:
            fts2048 = fts['out']
            high_level_fts = self.localconv(fts2048)

        if low_level:
            low_level_fts = fts['aux'][:, :self.aux_dim_keep]
            return high_level_fts, low_level_fts
        else:
            return high_level_fts


class PL_LightingResnest200eEncoder(pl.LightningModule):
    def __init__(self, use_coco_init, aux_dim_keep=64, use_aspp=False):
        super().__init__()
        ENCODER = 'timm-resnest269e'#  timm-resnest200e
        ENCODER_WEIGHTS = 'imagenet' if use_coco_init else None
        self.encoder = smp.encoders.get_encoder(ENCODER, in_channels=3, depth=5, weights=ENCODER_WEIGHTS)
        self.aux_dim_keep = aux_dim_keep
        self.localconv = nn.Conv2d(2048, 256, kernel_size=1, stride=1, bias=False)
        self.asppconv = nn.Conv2d(256, 256, kernel_size=1, bias=False)
        if use_aspp:
            # ASPP Layers
            dilations = [1, 2, 3, 4]  # Dilation rates for ASPP
            self.aspp = nn.ModuleList([
                nn.Conv2d(2048, 256, kernel_size=1, bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[0], dilation=dilations[0], bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[1], dilation=dilations[1], bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[2], dilation=dilations[2], bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[3], dilation=dilations[3], bias=False)
            ])
            self.global_avg_pool = nn.AdaptiveAvgPool2d((1, 1))
            self.aspp_out = nn.Conv2d(256 * (len(dilations) + 1), 256, kernel_size=1, bias=False)
        self.use_aspp = use_aspp

    def forward(self, x_in, low_level):
        fts = self.encoder(x_in)
        if self.use_aspp:
            aspp_outs = [F.relu(aspp(fts[-1])) for aspp in self.aspp]
            aspp_outs.append(F.relu(self.global_avg_pool(fts[-1])).expand_as(fts[-1]))
            aspp_out = self.aspp_out(torch.cat(aspp_outs, dim=1))
            high_level_fts = aspp_out
        else:
            high_level_fts = self.localconv(fts[-1])  # Using the output of the last layer as high-level features
        if low_level:
            low_level_fts = fts[-2][:, :self.aux_dim_keep]  # Extracting auxiliary features if needed
            return high_level_fts, low_level_fts
        else:
            return high_level_fts



# Resnest smp encoders:  https://github.com/qubvel/segmentation_models.pytorch/blob/master/segmentation_models_pytorch/encoders/timm_resnest.py
        

# modified on Thursday 28, 2024


class PL_LightingResnest269eEncoder(pl.LightningModule):
    def __init__(self, use_coco_init, aux_dim_keep=64, use_aspp=False):
        super().__init__()
        ENCODER = 'timm-resnest269e'
        ENCODER_WEIGHTS = 'imagenet' if use_coco_init else None
        self.encoder = smp.encoders.get_encoder(ENCODER, in_channels=3, depth=5, weights=ENCODER_WEIGHTS)
        self.aux_dim_keep = aux_dim_keep
        self.localconv = nn.Conv2d(2048, 256, kernel_size=1, stride=1, bias=False)
        self.asppconv = nn.Conv2d(256, 256, kernel_size=1, bias=False)
        if use_aspp:
            # ASPP Layers
            dilations = [1, 6, 12, 18]  # Dilation rates for ASPP
            self.aspp = nn.ModuleList([
                nn.Conv2d(2048, 256, kernel_size=1, bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[0], dilation=dilations[0], bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[1], dilation=dilations[1], bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[2], dilation=dilations[2], bias=False),
                nn.Conv2d(2048, 256, kernel_size=3, padding=dilations[3], dilation=dilations[3], bias=False)
            ])
            self.global_avg_pool = nn.AdaptiveAvgPool2d((1, 1))
            self.aspp_out = nn.Conv2d(256 * (len(dilations) + 1), 256, kernel_size=1, bias=False)
        self.use_aspp = use_aspp

    def forward(self, x_in, low_level):
        fts = self.encoder(x_in)
        if self.use_aspp:
            aspp_outs = [F.relu(aspp(fts[-1])) for aspp in self.aspp]
            aspp_outs.append(F.relu(self.global_avg_pool(fts[-1])).expand_as(fts[-1]))
            aspp_out = self.aspp_out(torch.cat(aspp_outs, dim=1))
            high_level_fts = aspp_out
        else:
            high_level_fts = self.localconv(fts[-1])  # Using the output of the last layer as high-level features
        if low_level:
            low_level_fts = fts[-2][:, :self.aux_dim_keep]  # Extracting auxiliary features if needed
            return high_level_fts, low_level_fts
        else:
            return high_level_fts
