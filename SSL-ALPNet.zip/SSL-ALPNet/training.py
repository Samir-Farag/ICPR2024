"""
Training the model
Extended from original implementation of PANet by Wang et al.
"""
import os
import shutil
import torch
import torch.nn as nn
import torch.optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
import torch.backends.cudnn as cudnn
import numpy as np

from models.grid_proto_fewshot import FewShotSeg
from dataloaders.dev_customized_med import med_fewshot
from dataloaders.ManualAnnoDatasetv2 import ManualAnnoDataset # used for traing with actual annotations
from dataloaders.GenericSuperDatasetv2 import SuperpixelDataset
from dataloaders.dataset_utils import DATASET_INFO
import dataloaders.augutils as myaug
from torch.utils.tensorboard import SummaryWriter

import matplotlib.pyplot as plt

from util.utils import set_seed, t2n, to01, compose_wt_simple
from util.metric import Metric

from config_ssl_upload import ex
import tqdm
import torchvision.transforms.functional as F

# Function to convert PyTorch tensor to PIL image
def to_pil_image(tensor):
    return F.to_pil_image(tensor.squeeze(0))

# config pre-trained model caching path
os.environ['TORCH_HOME'] = "./pretrained_model"

@ex.automain
def main(_run, _config, _log):
    if _run.observers:
        os.makedirs(f'{_run.observers[0].dir}/snapshots', exist_ok=True)
        for source_file, _ in _run.experiment_info['sources']:
            os.makedirs(os.path.dirname(f'{_run.observers[0].dir}/source/{source_file}'),
                        exist_ok=True)
            _run.observers[0].save_file(source_file, f'source/{source_file}')
        shutil.rmtree(f'{_run.observers[0].basedir}/_sources')

    set_seed(_config['seed'])
    cudnn.enabled = True
    cudnn.benchmark = True
    torch.cuda.set_device(device=_config['gpu_id'])
    torch.set_num_threads(1)

    _log.info('###### Create model ######')
    model = FewShotSeg(pretrained_path=None, cfg=_config['model'])

    model = model.cuda()
    model.train()

    _log.info('###### Load data ######')
    ### Training set
    data_name = _config['dataset']
    if data_name == 'CTC_SABS':
        baseset_name = 'CTC_SABS'

    elif data_name == 'CTC_SABS_Correct_Train':
        baseset_name = 'CTC_SABS_Correct_Train'

    elif data_name == 'C0_Superpix':
        raise NotImplementedError
        baseset_name = 'C0'
    elif data_name == 'CHAOST2_Superpix':
        baseset_name = 'CHAOST2'
    else:
        raise ValueError(f'Dataset: {data_name} not found')

    print('-------------------------- data_name is', data_name, '--------------------------')
    ### Transforms for data augmentation
    tr_transforms = myaug.transform_with_label({'aug': myaug.augs[_config['which_aug']]})
    assert _config['scan_per_load'] < 0 # by default we load the entire dataset directly

    test_labels = DATASET_INFO[baseset_name]['LABEL_GROUP']['pa_all'] - DATASET_INFO[baseset_name]['LABEL_GROUP'][_config["label_sets"]]
    _log.info(f'###### Labels excluded in training : {[lb for lb in _config["exclude_cls_list"]]} ######')
    _log.info(f'###### Unseen labels evaluated in testing: {[lb for lb in test_labels]} ######')

    # Approach 1: Self Supervised learning --> Using Pesudo labels for training the model
    tr_parent = SuperpixelDataset( # base dataset
        which_dataset = baseset_name,
        base_dir=_config['path'][data_name]['data_dir'],
        idx_split = _config['eval_fold'],
        mode='train',
        min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
        transforms=tr_transforms,
        nsup = _config['task']['n_shots'],
        scan_per_load = _config['scan_per_load'],
        exclude_list = _config["exclude_cls_list"],
        superpix_scale = _config["superpix_scale"],
        # fix_length = _config["max_iters_per_load"] if (data_name == 'CTC_SABS_Correct') or (data_name == 'CHAOST2_Superpix') else None
        fix_length = _config["max_iters_per_load"] if (data_name == 'C0_Superpix') or (data_name == 'CHAOST2_Superpix') else None
    )

    # # Approach 2: Supervised learning --> Using Actual annotated (GT) labels for training the model
    # tr_parent1 = ManualAnnoDataset( # base dataset
    #         which_dataset = baseset_name,
    #         base_dir=_config['path'][data_name]['data_dir'],
    #         idx_split = _config['eval_fold'],
    #         mode='train',
    #         min_fg=str(_config["min_fg_data"]), # dummy entry for superpixel dataset
    #         transforms=tr_transforms,  # None
    #         nsup = _config['task']['n_shots'],
    #         scan_per_load = _config['scan_per_load'],
    #         exclude_list = _config["exclude_cls_list"],
    #         superpix_scale = _config["superpix_scale"],
    #         fix_length = _config["max_iters_per_load"] if (data_name == 'CTC_SABS_Correct') or (data_name == 'CHAOST2_Superpix') else None
    #     )
    ### dataloaders
    trainloader = DataLoader(
        tr_parent,
        batch_size=_config['batch_size'],
        shuffle=True,
        num_workers=_config['num_workers'],
        pin_memory=True,
        drop_last=True
    )

    _log.info('###### Set optimizer ######')
    if _config['optim_type'] == 'sgd':
        optimizer = torch.optim.SGD(model.parameters(), **_config['optim'])
    else:
        raise NotImplementedError

    scheduler = MultiStepLR(optimizer, milestones=_config['lr_milestones'],  gamma = _config['lr_step_gamma'])

    my_weight = compose_wt_simple(_config["use_wce"], data_name)
    criterion = nn.CrossEntropyLoss(ignore_index=_config['ignore_label'], weight = my_weight)

    i_iter = 0 # total number of iteration
    n_sub_epoches = _config['n_steps'] // _config['max_iters_per_load'] # number of times for reloading

    log_loss = {'loss': 0, 'align_loss': 0}
    # Initialize the SummaryWriter for TensorBoard
    # Its output will be written to ./runs/
    # writer = SummaryWriter()
    _log.info('###### Training ######')
    for sub_epoch in range(n_sub_epoches):
        _log.info(f'###### This is epoch {sub_epoch} of {n_sub_epoches} epoches ######')
        for _, sample_batched in enumerate(trainloader):
            # print(sample_batched.keys())
            # Prepare input
            i_iter += 1
            # add writers
            support_images = [[shot.cuda() for shot in way]
                              for way in sample_batched['support_images']]
            support_fg_mask = [[shot[f'fg_mask'].float().cuda() for shot in way]
                               for way in sample_batched['support_mask']]
            support_bg_mask = [[shot[f'bg_mask'].float().cuda() for shot in way]
                               for way in sample_batched['support_mask']]

            query_images = [query_image.cuda()
                            for query_image in sample_batched['query_images']]
            query_labels = torch.cat(
                [query_label.long().cuda() for query_label in sample_batched['query_labels']], dim=0)

                    # # Print shapes
            # print("Support Images Shapes:")
            # for way in support_images:
            #     for shot in way:
            #         print(shot.shape)

            # print("\nSupport Foreground Masks Shapes:")
            # for way in support_fg_mask:
            #     for shot in way:
            #         print(shot.shape)

            # print("\nSupport Background Masks Shapes:")
            # for way in support_bg_mask:
            #     for shot in way:
            #         print(shot.shape)

            # print("\nQuery Images Shapes:")
            # for query_image in query_images:
            #     print(query_image.shape)

            # print("\nQuery Labels Shape:")
            # print(query_labels.shape)
            
            # Create a subplot with multiple rows and columns
            # # Create a subplot with 2 rows and 3 columns
            # fig, axs = plt.subplots(2, 3, figsize=(15, 10))

            # # Display Support Image
            # support_image_tensor = support_images[0][0].squeeze(0).permute(1, 2, 0).cpu().numpy()
            # # Normalize pixel values to the range [0, 1]
            # support_image_tensor = (support_image_tensor - support_image_tensor.min()) / (
            #             support_image_tensor.max() - support_image_tensor.min())
            # axs[0, 0].imshow(support_image_tensor)
            # axs[0, 0].set_title('Support Image')

            # # Display Support Foreground Mask
            # support_fg_mask_pil = to_pil_image(support_fg_mask[0][0])
            # axs[0, 1].imshow(support_fg_mask_pil, cmap='gray')
            # axs[0, 1].set_title('Support Foreground Mask')

            # # Display Support Background Mask
            # support_bg_mask_pil = to_pil_image(support_bg_mask[0][0])
            # axs[0, 2].imshow(support_bg_mask_pil, cmap='gray')
            # axs[0, 2].set_title('Support Background Mask')

            # # Display Query Image
            # query_image_tensor = query_images[0][0].squeeze(0).cpu()
            # # Convert sparse tensor to dense tensor before displaying
            # query_image_tensor_dense = query_image_tensor.to_dense()
            # query_image_tensor_permuted = query_image_tensor_dense.permute(1, 2, 0).numpy()

            # # Normalize pixel values to the range [0, 1]
            # query_image_tensor_permuted = (query_image_tensor_permuted - query_image_tensor_permuted.min()) / (
            #             query_image_tensor_permuted.max() - query_image_tensor_permuted.min())
            # axs[1, 0].imshow(query_image_tensor_permuted)
            # axs[1, 0].set_title('Query Image')

            # # Display Query Labels
            # query_labels_pil = to_pil_image(query_labels[0].unsqueeze(0).cpu().numpy().astype(np.uint8))
            # # print(query_labels_pil)
            # axs[1, 1].imshow(query_labels_pil, cmap='gray')
            # axs[1, 1].set_title('Query Labels')

            # # # Remove empty subplots in the last column
            # # for i in range(2):
            # axs[1, 2].axis('off')

            # # Adjust layout and show the figure
            # plt.tight_layout()
            # plt.show()

            # print('Start debugging')
            # break
            # Forward and Backward

            optimizer.zero_grad()
            # FIXME: in the model definition, filter out the failure case where pseudolabel falls outside of image or too small to calculate a prototype
            try:
                query_pred, align_loss, debug_vis, assign_mats = model(support_images, support_fg_mask, support_bg_mask, query_images, isval = False, val_wsize = None)
            except:
                print('Faulty batch detected, skip')
                continue

            query_loss = criterion(query_pred, query_labels)
            loss = query_loss + align_loss
            loss.backward()
            optimizer.step()
            scheduler.step()

            # Log loss
            query_loss = query_loss.detach().data.cpu().numpy()
            align_loss = align_loss.detach().data.cpu().numpy() if align_loss != 0 else 0

            _run.log_scalar('loss', query_loss)
            _run.log_scalar('align_loss', align_loss)
            log_loss['loss'] += query_loss
            log_loss['align_loss'] += align_loss

            # writer.add_scalar("query", query_loss, i_iter)
            # writer.add_scalar("align", align_loss, i_iter)

            # print loss and take snapshots
            if (i_iter + 1) % _config['print_interval'] == 0:

                loss = log_loss['loss'] / _config['print_interval']
                align_loss = log_loss['align_loss'] / _config['print_interval']
                
                # writer.add_scalar("query/epoch", query_loss, sub_epoch)
                # writer.add_scalar("dcl/epoch", align_loss, sub_epoch)

                log_loss['loss'] = 0
                log_loss['align_loss'] = 0

                print(f'step {i_iter+1}: loss: {loss}, align_loss: {align_loss},')

            if (i_iter + 1) % _config['save_snapshot_every'] == 0:
                _log.info('###### Taking snapshot ######')
                torch.save(model.state_dict(),
                           os.path.join(f'{_run.observers[0].dir}/snapshots', f'{i_iter + 1}.pth'))
                print(f'Model Saved to path: {_run.observers[0].dir}/snapshots/{i_iter + 1}.pth')


            if data_name == 'C0_Superpix' or data_name == 'CHAOST2_Superpix':
                if (i_iter + 1) % _config['max_iters_per_load'] == 0:
                    _log.info('###### Reloading dataset ######')
                    trainloader.dataset.reload_buffer()
                    print(f'###### New dataset with {len(trainloader.dataset)} slices has been loaded ######')

            if (i_iter - 2) > _config['n_steps']:
                return 1 # finish up

