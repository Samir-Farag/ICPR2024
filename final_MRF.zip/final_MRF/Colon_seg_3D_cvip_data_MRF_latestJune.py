
import matplotlib

import glob
import matplotlib
matplotlib.use('Agg')

# from all_functions_segmentation import *
from all_functions_segmentation_latestJune import *
from scipy.stats import norm
import multiprocessing
import os
import pydicom
import natsort
from matplotlib import pyplot as plt
import time


from mayavi import mlab
from PIL import Image
import time
import numpy as np
import pydicom as dicom
import os
import matplotlib.pyplot as plt
# from glob import glob
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import scipy.ndimage
from skimage import morphology
from skimage import measure
from skimage.transform import resize
from sklearn.cluster import KMeans
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
from plotly.tools import FigureFactory as FF
from plotly.graph_objs import *
import cv2
from stl import mesh
from vtkplotter import show, load, probePlane, vector, splitByConnectivity, extractLargestRegion
from vtkplotter import show, load, probePlane, vector, extractLargestRegion
import vtkplotter as vtkplt
import vtk
import pydicom as dicom

def Dovelop_colon_segmentation(scan_vol):
    start_time = time.time()
    try:
        print('#######################Started')
        dicom_files = glob.glob(scan_vol+'//*.dcm')                   # REMEMBER replace fldr by scan_vol
        if len(dicom_files)>300:
            # print(scan_vol)  # file to be processed
            dicom_files.sort()
            scan_vol = scan_vol + 'samir_output_June'
            if not os.path.exists(scan_vol):
                os.makedirs(scan_vol)
            dicom_scan= dicom_files
            try:
                patient = load_scan(dicom_scan)
                # print("The Volume slices have been read successfully")
            except:
                print('Error loading DICOM files. Check the path and files and try again.')
            volume = get_pixels_hu(patient)
            print("The Volume slices have been read successfully")
            if current_plane=='axial':
                imgs_to_process=volume

            apply_GC= True

            # 4.a) Histogram: axial

            plt.tight_layout(pad=2)
            fig, axes= plt.subplots(1, 1, figsize= (11, 5))
            # print(imgs_to_process.shape)
            axes.hist(imgs_to_process[np.logical_and(imgs_to_process>-1000, imgs_to_process<1000)].flatten(), bins=150, density=True, color='red', alpha=0.5)
            axes.set_title(f'Volume histogram {current_plane}, HU: -1000:1000');
            axes.grid()
            axes.set_xlabel("Hounsfield Units (HU)")
            axes.set_ylabel("Frequency")
            plot4= plt.hist(imgs_to_process[np.logical_and(imgs_to_process>-1000, imgs_to_process<1000)].flatten(), bins=150, density=True, color='red', alpha=0.5)
            Hu_axial= plot4[1][:-1]
            ImgHist_axial =  plot4[0]
            # plt.savefig(output_path+f'VolumeHist_{current_plane}.png')
            plt.close()
            # plt.show()
            # print('#######################AfterLOadScan2')
            '''5) EM on all planes'''
            '''Assume there 4 Gaussian components, find two thresholds (th1 & th2) with Expectation Maximization algorithm (EM), 
                then we have 2 classes: colon (air&liquid) & non colon (rest tissues)'''

            omu_axial, oSeg_axial, w_axial= EM4mHist(ImgHist_axial, Hu_axial, mu=[-950, -100, 100, 500], Seg=[400,400,400,400], classes=4, weights=[], iter=10000)
            # print(omu_axial, oSeg_axial, w_axial)
            # print('#######################EM4mHist')
            means = omu_axial
            variances = oSeg_axial**2
            coefs = w_axial

            m1, m2, m3, m4= means.squeeze()[0], means.squeeze()[1], means.squeeze()[2], means.squeeze()[3]
            var1, var2, var3, var4= variances.squeeze()[0], variances.squeeze()[1], variances.squeeze()[2], variances.squeeze()[3]
            std1, std2, std3, std4= np.sqrt(var1), np.sqrt(var2), np.sqrt(var3), np.sqrt(var4)
            coef1, coef2, coef3, coef4= coefs[0], coefs[1], coefs[2], coefs[3]
            # x = np.linspace(0,4000,4000)
            x = np.linspace(-2000,1500,4000)
            pxw1 = norm.pdf(x, m1, std1)
            pxw2 = norm.pdf(x, m2, std2)
            pxw3 = norm.pdf(x, m3, std3)
            pxw4 = norm.pdf(x, m4, std4)

            ppxw1 = coef1 * pxw1
            ppxw2 = coef2 * pxw2
            ppxw3 = coef3 * pxw3
            ppxw4 = coef4 * pxw4

            fig, axes= plt.subplots(1, 1, figsize= (11, 5))

            plot1= plt.plot(x, ppxw1,'r')
            plot2= plt.plot(x, ppxw2,'g')
            plot3= plt.plot(x, ppxw3,'b')
            plot4= plt.plot(x, ppxw4,'c')

            plot5= plt.hist(imgs_to_process[np.logical_and(imgs_to_process>-1000, imgs_to_process<1000)].flatten(), bins=150, density=True, color='blue', alpha=0.5)
            plt.grid()
            # plt.savefig(F'D:/SY_paper/{current_DICOM}/{current_plane}/FourGaussiansHistogram_{current_plane}.png')
            plt.close()

            # plt.legend(['P(I|f_background) P(f_background)', 'P(I|f_object) P(f_object)']);
            ind1 = np.greater(ppxw2, ppxw1)
            optimal_threshold1 = x[np.argmax(ind1 == True)]
            # print(optimal_threshold1)

            ind2 = np.greater(ppxw4, ppxw3)
            optimal_threshold2 = x[np.argmax(ind2 == True)]
            # print(optimal_threshold2)
            '''
            # 6) voi EM based on optimal_threshold1 & optimal_threshold2
            '''
            dicom_vol=imgs_to_process  
            EM_seg_vol, _=get_voi(images=dicom_vol, th1=optimal_threshold1, th2=optimal_threshold2)  # Remember that I turned off displying image_rgb    #Remember:  th2=1500 
            # print('#######################get_voi')
            '''
            # 7) errosion for seg_vol. 
            Remember: DICOM --> axial --> EM ---> get optimal_threshold1 & optimal_threshold2 --> voi (separate air, fluid and tissues) --> errosion (and Dilation if needed))
            '''
            EM_seg_vol_ero= []
            # EM_seg_vol_dil= []
            for im in range(EM_seg_vol.shape[0]):
                kernel = np.ones((3, 3), np.uint8)    #  kernel = np.ones((5,5), np.uint8)
                EM_seg_vol_ero.append(cv2.erode(EM_seg_vol[im], kernel, iterations=4))
                # EM_seg_vol_dilation.append(cv2.dilate(EM_seg_vol[im], kernel, iterations=1))
            EM_seg_vol_ero =np.asarray(EM_seg_vol_ero)
            print("EM Step been done successfully.---> GC")

            # ''' 8) Graph cut '''
            if apply_GC:
            # gamma_factor= 0.3
                gamma_factor= 10000000
                # print(dicom_vol.shape)
                GC_seg_vol= graph_cut_volume(EM_seg_vol_ero, m1, m3, var1, var3, coef1, coef3, gamma_factor) # print(seg_mask_vol.shape)
           
                print("GC Step been done successfully.---> RG")

            ''' 9) region growing'''
            # seed= (107, 218, 393) # slice number, y, x ---> SY_paper for    DICOM7  okay
            if apply_GC:
                x= GC_seg_vol

            else:   
                x= EM_seg_vol_ero   #  good

            ##########calculate seed#################
            colon_seeds= []
            for candidate in range(5, 200, 5):
                for c in range(imgs_to_process.shape[0]-1, imgs_to_process.shape[0]-candidate, -1):
                    im = EM_seg_vol[c].astype(np.uint8)  
                    img_dcm = imgs_to_process[c] 
                    img = img_dcm.astype(np.uint8) 
                    
                    # Find contours
                    contours, _ = cv2.findContours(im, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                    # image_rgb = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

                    for cnt in contours:
                        mask = np.zeros_like(im)
                        region_mask = cv2.fillPoly(mask, pts=[cnt], color=(255, 255, 255)) 
                        roi = img_dcm.flatten()[region_mask.flatten()==255]

                        if roi.mean() < -850:
                            # image_rgb = cv2.drawContours(image_rgb, [cnt], -1, (0, 0, 255), 1)
                                # compute the center of the contour
                            M = cv2.moments(cnt)
                            cX = int(M["m10"] / M["m00"])
                            cY = int(M["m01"] / M["m00"])
                            # cv2.circle(image_rgb, (cX, cY), 7, (0, 0, 255), -1)
                            colon_seeds.append((c, cY, cX))
                if len(colon_seeds) != 0:
                    print(f"the seed candidate for scan volume {scan_vol} is at slice: {candidate}")
                    break
                # print(candidate)
            seed= colon_seeds[-1]

            RG_EM_ero_seg_vol = grow(x, seed, 2)   #   seg_mask_vol

            '''# 10) dilation final'''
            # Remember: DICOM --> axial --> EM ---> get optimal_threshold1 & optimal_threshold2 --> voi (separate air, fluid and tissues) --> errosion (kernel= 7x7, iter=1) 
            # in step 10, we dilate the RG result (with same mask and iter as done before in step 7), then multiply result by orignal output of voi (i.e. EM_seg_vol) 
            # to get rid of extracolonic components
            RG_EM_ero_seg_vol_dil= []
            for im in range(RG_EM_ero_seg_vol.shape[0]):
                kernel = np.ones((3,3), np.uint8)    #  kernel = np.ones((5,5), np.uint8)
                # kernel= cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
                RG_EM_ero_seg_vol_dil.append(cv2.dilate(RG_EM_ero_seg_vol[im].astype(np.uint8), kernel, iterations=3))
            RG_EM_ero_seg_vol_dil =np.asarray(RG_EM_ero_seg_vol_dil)
            final_seg_vol= RG_EM_ero_seg_vol_dil * EM_seg_vol
            print("GC Step been done successfully.---> Final Seg ---> 3D")

            '''# 12) Save final segmentation result'''
            # # Save final colon volume as slices AND as npy array
            save_volume_slices(scan_vol + '/'+ f'{current_plane}_final_seg', final_seg_vol)
            # Save seg volume as npy array
            np.save(scan_vol + '/'+  f'{current_plane}_final_seg.npy', final_seg_vol)

            '''# 13) Saving colon as stl & ply files: '''
            # create a separate folder for colon stl and ply files
            output_path_colon = F"{scan_vol}/colon_only_{current_plane}/"
            try:
                os.mkdir(output_path_colon)
            except:
                # print('Output directory already exists!')
                pass

            colon_mesh= make_mesh(final_seg_vol, 0, 1, spacing= (1, 1, 1)) # seg_mask_vol resulted from Graph Cut algorithm
            # colon_mesh.save(output_path + 'colon_mesh_sagittal_new.stl')
            colon_mesh.save(output_path_colon + f'{current_plane}_final_colon.stl')
            # --- Old idea: Sebarate colon from noncolon based on Region Growing (RG). Now, meshprocess just smooth the final_colon---
            obj = meshprocess(output_path_colon + f'{current_plane}_final_colon.stl')
            vtkplt.save(obj, output_path_colon + f'{current_plane}_final_colon_smoothed.ply')
            print(f'the DICOM volume is successfully done in %s seconds ---' % (time.time() - start_time))
            # counter+=1
            print('#######################finished')

        #######################
    except Exception as error:
    # handle the exception
        print(f"An exception occurred in :{scan_vol}", error) # An exception occurred: division by zero, for instance
        # failed_folders.append(scan_vol)
    # print(failed_folders)

if __name__ == '__main__':

    scan_plane = ['axial','sagittal','coronal']
    current_plane = scan_plane[0]
    scan_vol= "/media/hd2/Colon/Data_GT_Annotaion/01/scan/prone/dicom/"
    Dovelop_colon_segmentation(scan_vol)
