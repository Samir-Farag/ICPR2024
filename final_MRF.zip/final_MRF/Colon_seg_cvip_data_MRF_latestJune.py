import matplotlib
import glob
import matplotlib
matplotlib.use('Agg')
from all_functions_segmentation_latestJune import *
from scipy.stats import norm
import multiprocessing
import os
import pydicom
import natsort
from matplotlib import pyplot as plt
import time
from mayavi import mlab
from PIL import Image
import numpy as np
import pydicom as dicom
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import scipy.ndimage
from skimage import morphology
from skimage import measure
from skimage.transform import resize
from sklearn.cluster import KMeans
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
from plotly.tools import FigureFactory as FF
from plotly.graph_objs import *
import cv2
from stl import mesh
from vtkplotter import show, load, probePlane, vector, extractLargestRegion
import vtk
import SimpleITK as sitk

def Dovelop_colon_segmentation(scan_vol):
    start_time = time.time()
    try:
        print('#######################Started')
        dicom_files = glob.glob(scan_vol + '/*.dcm')  # REMEMBER replace fldr by scan_vol
        if len(dicom_files) > 300:
            dicom_files.sort()
            scan_vol = os.path.join(scan_vol, 'samir_output_June')
            if not os.path.exists(scan_vol):
                os.makedirs(scan_vol)
            dicom_scan = dicom_files
            try:
                patient = load_scan(dicom_scan)
            except:
                print('Error loading DICOM files. Check the path and files and try again.')
            volume = get_pixels_hu(patient)
            print("The Volume slices have been read successfully")
            if current_plane == 'axial':
                imgs_to_process = volume

            apply_GC = True

            # 4.a) Histogram: axial
            plt.tight_layout(pad=2)
            fig, axes = plt.subplots(1, 1, figsize=(11, 5))
            axes.hist(imgs_to_process[np.logical_and(imgs_to_process > -1000, imgs_to_process < 1000)].flatten(), bins=150, density=True, color='red', alpha=0.5)
            axes.set_title(f'Volume histogram {current_plane}, HU: -1000:1000')
            axes.grid()
            axes.set_xlabel("Hounsfield Units (HU)")
            axes.set_ylabel("Frequency")
            plot4 = plt.hist(imgs_to_process[np.logical_and(imgs_to_process > -1000, imgs_to_process < 1000)].flatten(), bins=150, density=True, color='red', alpha=0.5)
            Hu_axial = plot4[1][:-1]
            ImgHist_axial = plot4[0]
            plt.close()

            # 5) EM on all planes
            omu_axial, oSeg_axial, w_axial = EM4mHist(ImgHist_axial, Hu_axial, mu=[-950, -100, 100, 500], Seg=[400, 400, 400, 400], classes=4, weights=[], iter=10000)
            means = omu_axial
            variances = oSeg_axial ** 2
            coefs = w_axial

            m1, m2, m3, m4 = means.squeeze()[0], means.squeeze()[1], means.squeeze()[2], means.squeeze()[3]
            var1, var2, var3, var4 = variances.squeeze()[0], variances.squeeze()[1], variances.squeeze()[2], variances.squeeze()[3]
            std1, std2, std3, std4 = np.sqrt(var1), np.sqrt(var2), np.sqrt(var3), np.sqrt(var4)
            coef1, coef2, coef3, coef4 = coefs[0], coefs[1], coefs[2], coefs[3]
            x = np.linspace(-2000, 1500, 4000)
            pxw1 = norm.pdf(x, m1, std1)
            pxw2 = norm.pdf(x, m2, std2)
            pxw3 = norm.pdf(x, m3, std3)
            pxw4 = norm.pdf(x, m4, std4)

            ppxw1 = coef1 * pxw1
            ppxw2 = coef2 * pxw2
            ppxw3 = coef3 * pxw3
            ppxw4 = coef4 * pxw4

            fig, axes = plt.subplots(1, 1, figsize=(11, 5))
            plt.plot(x, ppxw1, 'r')
            plt.plot(x, ppxw2, 'g')
            plt.plot(x, ppxw3, 'b')
            plt.plot(x, ppxw4, 'c')
            plt.hist(imgs_to_process[np.logical_and(imgs_to_process > -1000, imgs_to_process < 1000)].flatten(), bins=150, density=True, color='blue', alpha=0.5)
            plt.grid()
            plt.close()

            ind1 = np.greater(ppxw2, ppxw1)
            optimal_threshold1 = x[np.argmax(ind1)]
            ind2 = np.greater(ppxw4, ppxw3)
            optimal_threshold2 = x[np.argmax(ind2)]

            dicom_vol = imgs_to_process
            EM_seg_vol, _ = get_voi(images=dicom_vol, th1=optimal_threshold1, th2=optimal_threshold2)

            EM_seg_vol_ero = []
            for im in range(EM_seg_vol.shape[0]):
                kernel = np.ones((3, 3), np.uint8)
                EM_seg_vol_ero.append(cv2.erode(EM_seg_vol[im], kernel, iterations=4))
            EM_seg_vol_ero = np.asarray(EM_seg_vol_ero)
            print("EM Step been done successfully.---> GC")

            if apply_GC:
                gamma_factor = 10000000
                GC_seg_vol = graph_cut_volume(EM_seg_vol_ero, m1, m3, var1, var3, coef1, coef3, gamma_factor)
                print("GC Step been done successfully.---> RG")

            if apply_GC:
                x = GC_seg_vol
            else:
                x = EM_seg_vol_ero

            colon_seeds = []
            for candidate in range(5, 200, 5):
                for c in range(imgs_to_process.shape[0] - 1, imgs_to_process.shape[0] - candidate, -1):
                    im = EM_seg_vol[c].astype(np.uint8)
                    img_dcm = imgs_to_process[c]
                    img = img_dcm.astype(np.uint8)

                    contours, _ = cv2.findContours(im, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                    for cnt in contours:
                        mask = np.zeros_like(im)
                        region_mask = cv2.fillPoly(mask, pts=[cnt], color=(255, 255, 255))
                        roi = img_dcm.flatten()[region_mask.flatten() == 255]

                        if roi.mean() < -850:
                            M = cv2.moments(cnt)
                            cX = int(M["m10"] / M["m00"])
                            cY = int(M["m01"] / M["m00"])
                            colon_seeds.append((c, cY, cX))
                if len(colon_seeds) != 0:
                    print(f"the seed candidate for scan volume {scan_vol} is at slice: {candidate}")
                    break
            seed = colon_seeds[-1]

            RG_EM_ero_seg_vol = grow(x, seed, 2)

            RG_EM_ero_seg_vol_dil = []
            for im in range(RG_EM_ero_seg_vol.shape[0]):
                kernel = np.ones((3, 3), np.uint8)
                RG_EM_ero_seg_vol_dil.append(cv2.dilate(RG_EM_ero_seg_vol[im].astype(np.uint8), kernel, iterations=3))
            RG_EM_ero_seg_vol_dil = np.asarray(RG_EM_ero_seg_vol_dil)
            final_seg_vol = RG_EM_ero_seg_vol_dil * EM_seg_vol
            print("GC Step been done successfully.---> Final Seg ---> 3D")

            # Save final colon volume as slices AND as npy array
            save_volume_slices(scan_vol + '/' + f'{current_plane}_final_seg', final_seg_vol)
            np.save(scan_vol + '/' + f'{current_plane}_final_seg.npy', final_seg_vol)

            # Convert the list of masks to a 3D volume and save as NIfTI
            sitk_image = sitk.GetImageFromArray(np.array(final_seg_vol))
            nifti_output_path = os.path.join(scan_vol, f'{current_plane}_final_seg.nii.gz')
            sitk.WriteImage(sitk_image, nifti_output_path)
            print('Segmentation is generated successfully and saved as NIfTI.')

            print(f'the DICOM volume is successfully done in %s seconds ---' % (time.time() - start_time))
            print('#######################finished')

    except Exception as error:
        print(f"An exception occurred in :{scan_vol}", error)

if __name__ == '__main__':
    scan_plane = ['axial', 'sagittal', 'coronal']
    current_plane = scan_plane[0]
    scan_vol = "/media/hd2/Colon/Data_GT_Annotaion/01/scan/prone/dicom/"
    Dovelop_colon_segmentation(scan_vol)
