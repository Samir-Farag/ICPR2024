import os
import glob
import natsort
import numpy as np
import SimpleITK as sitk
from skimage import measure
from stl import mesh
import pyvista as pv
import vtkplotter as vtkplt
from vtkplotter import show, load, probePlane, vector, splitByConnectivity, extractLargestRegion

# def generate_colon_for_targets(targets):
#     for target in targets:
#         segmentation_path = '/media/hd2/Colon/Data_GT_Annotaion/01/scan/prone/dicom/samir_output_June'
#         # segmentation_path = f'/media/safara01/New Volume/Samir_testcode/{target}'
#         generate_colon(segmentation_path)

def generate_colon(segmentation_path):
    
    def make_mesh(image, threshold=-300, step_size=1, spacing=(1, 1, 1)): 
        p = image.transpose(2, 1, 0)
        verts, faces, _, _ = measure.marching_cubes(p, threshold, spacing=spacing, step_size=step_size, allow_degenerate=True, method='lewiner')
        colon_mesh = mesh.Mesh(np.zeros(faces.shape[0], dtype=mesh.Mesh.dtype))
        for i, f in enumerate(faces):
            for j in range(3):
                colon_mesh.vectors[i][j] = verts[f[j], :]
        return colon_mesh

    def meshprocess(fname):
        em = load(fname)
        eml = em.clone().smoothLaplacian()# Smooth the mesh using Laplacian smoothing
        return eml

    segmentation_files_pred = glob.glob(os.path.join(segmentation_path, '*.nii.gz'))
    segmentation_files_pred = natsort.natsorted(segmentation_files_pred)
    #     print('--'*60)
    for file_path in segmentation_files_pred:
    # for idx, file_path in enumerate(segmentation_files_pred):
        # scan_Id= file_path.split('/')[-1].split('.nii.gz')[0].split('prediction_')[-1]
        image = sitk.ReadImage(file_path)
        np_volume = sitk.GetArrayFromImage(image)
        print('Volume shape:', np_volume.shape)
        # np_volume = np_volume[:, 0, :, :] # activate if dimentions for example 429, 3, 512, 512
        print('New Volume shape:', np_volume.shape) # activate if dimentions for example 429, 512, 512
        output_path = os.path.join(segmentation_path, 'colon_ply_stl_pred', 'volume_/')
        os.makedirs(output_path, exist_ok=True)

        colon_mesh = make_mesh(np_volume, threshold=0, step_size=1, spacing=image.GetSpacing())
        colon_mesh.save(os.path.join(output_path, f'axial_final_colon_pred.stl'))

        obj = meshprocess(output_path + f'axial_final_colon_pred.stl')
        vtkplt.save(obj, output_path + f'axial_final_colon_pred.ply')
        print(f"Colon mesh  has been generated and saved as STL and PLY files.")

    print("All colon meshes have been generated and saved.")

if __name__ == "__main__":
    # targets=['Seg_Samples']
    segmentation_path = '/media/hd2/Colon/Data_GT_Annotaion/01/scan/prone/dicom/samir_output_June/'
    generate_colon(segmentation_path)
