import os
import glob
import natsort
import numpy as np
import SimpleITK as sitk
from skimage import measure
from stl import mesh
import pyvista as pv
import vtkplotter as vtkplt
from vtkplotter import show, load, probePlane, vector, splitByConnectivity, extractLargestRegion
from tqdm import tqdm
import time

def generate_colon(segmentation_path):

    def make_mesh(image, threshold=-300, step_size=1, spacing=(1, 1, 1)):
        p = image.transpose(2, 1, 0)
        verts, faces, _, _ = measure.marching_cubes(p, threshold, spacing=spacing, step_size=step_size, allow_degenerate=True, method='lewiner')
        colon_mesh = mesh.Mesh(np.zeros(faces.shape[0], dtype=mesh.Mesh.dtype))
        for i, f in enumerate(faces):
            for j in range(3):
                colon_mesh.vectors[i][j] = verts[f[j], :]
        return colon_mesh

    def meshprocess(fname):
        em = load(fname)
        eml = em.clone().smoothLaplacian()  # Smooth the mesh using Laplacian smoothing
        return eml

    # Recursively find all nii.gz files
    segmentation_files_pred = [os.path.join(root, file)
                               for root, _, files in os.walk(segmentation_path)
                               for file in files if file.endswith('.nii.gz')]
    
    segmentation_files_pred = natsort.natsorted(segmentation_files_pred)
    
    for file_path in tqdm(segmentation_files_pred, desc="Processing files"):
        start_time = time.time()
        
        # Load the NIfTI image
        image = sitk.ReadImage(file_path)
        np_volume = sitk.GetArrayFromImage(image)
        print(f'\nProcessing file: {file_path}')
        print('Volume shape:', np_volume.shape)
        
        # Generate colon mesh
        colon_mesh = make_mesh(np_volume, threshold=0, step_size=1, spacing=image.GetSpacing())
        stl_path = os.path.splitext(file_path)[0].replace('.nii', '') + '.stl'
        colon_mesh.save(stl_path)
        
        # Process the mesh and save as .ply
        obj = meshprocess(stl_path)
        ply_path = os.path.splitext(file_path)[0].replace('.nii', '') + '.ply'
        vtkplt.save(obj, ply_path)
        
        end_time = time.time()
        elapsed_time = end_time - start_time
        print(f"Colon mesh has been generated and saved as STL and PLY files at the same location as the NIfTI file.")
        print(f"Time taken for {file_path}: {elapsed_time:.2f} seconds")

    print("All colon meshes have been generated and saved.")

if __name__ == "__main__":
    segmentation_path = '/home/Shared/Samir_testcode/Seg_Samples/'
    generate_colon(segmentation_path)
