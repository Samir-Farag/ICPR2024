
from mayavi import mlab
from PIL import Image
import time
import numpy as np
import pydicom as dicom
import os
import matplotlib.pyplot as plt
# from glob import glob
import glob

from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import scipy.ndimage
from skimage import morphology
from skimage import measure
from skimage.transform import resize
from sklearn.cluster import KMeans
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
from plotly.tools import FigureFactory as FF
from plotly.graph_objs import *
import cv2
from stl import mesh
from vtkplotter import show, load, probePlane, vector, splitByConnectivity, extractLargestRegion
from vtkplotter import show, load, probePlane, vector, extractLargestRegion
import vtkplotter as vtkplt
import vtk
import pydicom as dicom
# import matplotlib.pylab as plt
from pydicom.data import get_testdata_files
import numpy as np
import glob
from sklearn.mixture import GaussianMixture
from scipy import stats
import math
import maxflow
import numpy as np
from scipy.stats import norm
# %matplotlib widget

import SimpleITK as sitk

from PIL import Image as Img
from skimage.morphology import binary_erosion, ball




def load_scan(dicom_files): # samir_
    slices =[]
    for f in dicom_files:
        # print(f)
        slices.append(dicom.dcmread(f))

    slices.sort(key=lambda x: int(x.InstanceNumber))
    # The slices list is sorted by InstanceNumber, which is a DICOM tag that represents the position of the image in the scanning sequence.
    try:
        slice_thickness = np.abs(slices[0].ImagePositionPatient[2] - slices[1].ImagePositionPatient[2])
        
    except:
        slice_thickness = np.abs(slices[0].SliceLocation - slices[1].SliceLocation)

    for s in slices:
        s.SliceThickness = slice_thickness


    return slices
    '''
    This function is used to load a series of DICOM files (Digital Imaging and Communications in Medicine) and return them as a list of 
    pydicom.dataset.FileDataset objects. DICOM is a standard format used to store medical imaging data, such as CT or MRI scans.

    The function takes a list of file paths dicom_files as input.
    It creates an empty list slices. 
    It loops over each file in dicom_files and reads the DICOM file using dicom.dcmread(f) function. 
    The resulting FileDataset object is appended to the slices list.
    The slices list is sorted by InstanceNumber, which is a DICOM tag that represents the position of the image in the scanning sequence.
    The slice thickness is calculated by subtracting the ImagePositionPatient or SliceLocation attributes of the first two slices 
    (depending on which is available) and taking the absolute value.
    The SliceThickness attribute of each slice in the slices list is set to the calculated thickness.
    The function returns the slices list, which contains all the loaded DICOM images.
    Overall, this function provides a basic way to load a series of DICOM files and ensure that the slice thickness is properly set. 
    Further processing may be necessary depending on the specific use case.'''


    #################################################################################################################################################################
def load_scan(dicom_files): 
    slices =[]
    for f in dicom_files:
        # print(f)   to show each slice
        slices.append(dicom.dcmread(f))

    slices.sort(key=lambda x: int(x.InstanceNumber))
    # The slices list is sorted by InstanceNumber, which is a DICOM tag that represents the position of the image in the scanning sequence.
    try:
        slice_thickness = np.abs(slices[0].ImagePositionPatient[2] - slices[1].ImagePositionPatient[2])
        
    except:
        slice_thickness = np.abs(slices[0].SliceLocation - slices[1].SliceLocation)

    for s in slices:
        s.SliceThickness = slice_thickness


    return slices
    '''
    This function is used to load a series of DICOM files (Digital Imaging and Communications in Medicine) and return them as a list of 
    pydicom.dataset.FileDataset objects. DICOM is a standard format used to store medical imaging data, such as CT or MRI scans.

    The function takes a list of file paths dicom_files as input.
    It creates an empty list slices. 
    It loops over each file in dicom_files and reads the DICOM file using dicom.dcmread(f) function. 
    The resulting FileDataset object is appended to the slices list.
    The slices list is sorted by InstanceNumber, which is a DICOM tag that represents the position of the image in the scanning sequence.
    The slice thickness is calculated by subtracting the ImagePositionPatient or SliceLocation attributes of the first two slices 
    (depending on which is available) and taking the absolute value.
    The SliceThickness attribute of each slice in the slices list is set to the calculated thickness.
    The function returns the slices list, which contains all the loaded DICOM images.
    Overall, this function provides a basic way to load a series of DICOM files and ensure that the slice thickness is properly set. 
    Further processing may be necessary depending on the specific use case.'''

def get_pixels_hu(scans):
    image = np.stack([s.pixel_array for s in scans])
    # Convert to int16 (from sometimes int16),
    # should be possible as values should always be low enough (<32k)
    image = image.astype(np.int16)

    # Set outside-of-scan pixels to 1
    # The intercept is usually -1024, so air is approximately 0
    image[image == -2000] = 0

    # Convert to Hounsfield units (HU)
    intercept = scans[0].RescaleIntercept
    slope = scans[0].RescaleSlope

    if slope != 1:
        image = slope * image.astype(np.float64)
        image = image.astype(np.int16)

    image += np.int16(intercept)

    return np.array(image, dtype=np.int16)

    '''
    This function is used to convert a series of DICOM images (represented as pydicom.dataset.FileDataset objects) into a 3D NumPy array of Hounsfield Units (HU). 
    Here is a summary of what the function does:
    
    The function takes a list of DICOM FileDataset objects as input.
    It creates a NumPy array image by stacking the pixel arrays of all the input scans using np.stack([s.pixel_array for s in scans]).
    The image array is cast to np.int16. Any pixels outside the scan (e.g., those with a value of -2000) are set to 0.The Hounsfield Units (HU) are 
    calculated by applying the transformation: HU = slope * pixel_value + intercept. The intercept and slope values are retrieved from the DICOM metadata. 
    If the slope is not 1, the image is first cast to np.float64, scaled by slope, and then cast back to np.int16. The HU values are stored in the image array, 
    which is returned as the output of the function. 

    Overall, this function provides a way to convert DICOM images to Hounsfield Units, which are a standard measure of radiodensity used in medical imaging. 
    This is a common preprocessing step before performing further analysis or visualization of the images.
    '''

def get_pixels_hu(scans):
    image = np.stack([s.pixel_array for s in scans])
    # Convert to int16 (from sometimes int16),
    # should be possible as values should always be low enough (<32k)
    image = image.astype(np.int16)

    # Set outside-of-scan pixels to 1
    # The intercept is usually -1024, so air is approximately 0
    image[image < -1000] = 0

    # Convert to Hounsfield units (HU)
    intercept = scans[0].RescaleIntercept
    slope = scans[0].RescaleSlope

    if slope != 1:
        image = slope * image.astype(np.float64)
        image = image.astype(np.int16)

    image += np.int16(intercept)

    return np.array(image, dtype=np.int16)

    '''
    This function is used to convert a series of DICOM images (represented as pydicom.dataset.FileDataset objects) into a 3D NumPy array of Hounsfield Units (HU). 
    Here is a summary of what the function does:
    
    The function takes a list of DICOM FileDataset objects as input.
    It creates a NumPy array image by stacking the pixel arrays of all the input scans using np.stack([s.pixel_array for s in scans]).
    The image array is cast to np.int16. Any pixels outside the scan (e.g., those with a value of -2000) are set to 0.The Hounsfield Units (HU) are 
    calculated by applying the transformation: HU = slope * pixel_value + intercept. The intercept and slope values are retrieved from the DICOM metadata. 
    If the slope is not 1, the image is first cast to np.float64, scaled by slope, and then cast back to np.int16. The HU values are stored in the image array, 
    which is returned as the output of the function. 

    Overall, this function provides a way to convert DICOM images to Hounsfield Units, which are a standard measure of radiodensity used in medical imaging. 
    This is a common preprocessing step before performing further analysis or visualization of the images.
    '''

def EM4mHist(ImgHist, Hu, mu=[], Seg=[], classes=3, weights=[], iter=20):
    # print(ImgHist.shape)
    # print(Hu.shape)
    # print(len(ImgHist))
    # ImgHist: image histogram
    # Hu: Hounsfield values wrt histogram
    # mu: vector initial means
    # Seg: vector initial variances
    # weights: vector initial weights
    # iter : number of iterations
    # classes: number of classes (default is 2)
    
    N= ImgHist.shape[0]
    #Or:   N= Hu.shape[0]
    K = classes
    p = weights
    eps = np.finfo(float).eps

    # if mu is None:
    # if (isempty(mu))
    if len(mu) == 0:
    # if not Hu: 
        for j in range(0,K):
            mu.append(j*max(Hu)/(K+1) ) 

    # if (isempty(Seg))
    if len(Seg) == 0:
    # if not Seg: 
        s = (max(Hu)-min(Hu))/12
        Seg = np.ones(K)*s*s #Creating one-dimensional array with ones with length k

    # if (isempty(p))
    if len(p) == 0:
    # if not p: 
        p = np.ones(K)/K

    X = Hu

    # c=[];
    c = np.zeros((K, len(X))) 
    pltC = np.zeros_like(c)
    # c=[]
    mu = np.array(mu).reshape(K,-1)
    Seg = np.array(Seg).reshape(K,-1)
    while iter > 0: # while iter    
        mu = mu.reshape(K,-1)
        Seg = Seg.reshape(K,-1)
        for i in range(0, K):  # for i=1:K
            c[i,:] = p[i]*np.exp(-(X-mu[i])**2/(2*Seg[i]))/(np.sqrt(Seg[i]*2*np.pi))
            # pltC[i,:] = p[i]*np.exp(-(X-mu[i])**2/(2*Seg[i]))/(np.sqrt(Seg[i]*2*np.pi))
        
        c_ = np.diag(p) @ np.exp(-(X-mu)**2/(2*Seg))/(np.sqrt(Seg*2*np.pi))
        # print(c[0],c_[0])
        sumc = np.sum(c, axis=0)
        # print(sumc.shape)

        # c=c./repmat(sumc,K,1); 
        # den=np.tile(sumc, (K,1))
        c = np.divide(c, sumc+eps)
        
        # c=c.*repmat(h,K,1) 
        # temp= np.tile(ImgHist, (K,1))
        c= np.multiply(c, ImgHist)  
        # print(c.shape)
        
        # mu = np.sum(np.tile(X, (K,1))*c, axis=1)/(np.sum(c, axis=1))
        # temp1= np.tile(X, K).reshape(K,-1)
        weight_Hu = np.multiply(X, c)
        mu = np.average(np.repeat(X.reshape(-1, N), K, axis=0),axis=1, weights = c)
        # # temp2= np.multiply(X, c)  
        # num = np.sum(weight_Hu, axis=1)
        # den= np.sum(c, axis=1)
        # mu= num/(den )
        # print(mu)
        

        
        # num= sum(((repmat(X,K,1)-repmat(mu,1,length(X))).^2).*c,2)
        # temp1= np.tile(X, K).reshape(K,-1) - np.tile(mu,  len(X)).reshape(K,-1) 
        # temp1_sq= temp1 ** 2
        # num= np.sum(np.multiply(temp1_sq, c), axis=1)
        # den= np.sum(c, axis=1)
        # # Seg = np.sum(np.tile((X-mu).T**2, (K,1))*c, axis=1)/(np.sum(c, axis=1))
        # Seg= num/den
        # print((np.repeat(X.reshape(-1,150), K, axis=0)-mu.reshape(-1,1)),temp1)
        # weight variance formula
        Seg= np.average((np.repeat(X.reshape(-1, N), K, axis=0)-mu.reshape(-1,1))**2,axis=1, weights=c)
        Seg = np.sqrt(Seg)+eps
        # print(Seg,Seg_)

        p = np.sum(c, axis=1)/len(X)
        p = p/np.sum(p)

        iter -= 1
        # print(iter)

    omu = mu
    oSeg = Seg
    w = p

    return omu, oSeg, w

def get_voi(images, th1, th2):   
    # Apply EM to find m1, m2, m3, var1, var2, var3 --> plot distributions --> calculate: th1, th2 for ex: = -686.1965491372844,  150.33758439609892
    
    # seg_vol =get_voi(images=dicom_vol, th1=optimal_threshold1, th2=optimal_threshold2)
    out =[]
    outputrgb= []
    ind=1

    # from Ipython.display import display, clear_output
    # fig= plt.figure()
    # ax= fig.add_subplot(1, 1, 1)
    
    for j,im in enumerate(images): # loop over all slices in DICOM volume dicom_vol
    # for im in images: # loop over all slices in DICOM volume dicom_vol
        # image_gray = cv2.medianBlur(im, 5)
        # print(im.index)
        # if j>140 and j<180:
        #     print()
        maxval = images.max() # finding the maximum value in an array of images.
        # print('maxval', maxval)
        # --- Binarize image using threshold th1 which is calculated from parameters calculated from EM. th1 separates first probability distributions---
        ret, th = cv2.threshold(im, th1, maxval, 0)        # th = cv2.adaptiveThreshold(image_gray,255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 5, 1)
        '''thresholding the input image (im) using a fixed threshold value (e.g., of -686.1965491372844) Hounsfield units and maximum pixel value (maxval) 
           with cv2.threshold() function.'''

        th = 255*(th / maxval) 
        '''Normalizing the thresholded image to be in the range of 0-255 with a data type of unsigned integer 8-bit'''

        th = th.astype('uint8') 
        ''' Changing the data type of the normalized image to unsigned integer 8-bit.'''
        # print('th.shape', th.shape)
        image_rgb = cv2.cvtColor(th, cv2.COLOR_GRAY2BGR)      # Convert binary image to RGB for drawing contours
        '''Converting the normalized grayscale image into a 3-channel color image (RGB) with cv2.cvtColor() function to draw contours on it.'''

        #--- Find all the contours in the binary image ---
        contours, hierarchy = cv2.findContours(th, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        '''This line finds all the contours in the binary image, th, using the OpenCV findContours function. findContours takes three arguments:
           the binary image, th 
           the contour retrieval mode, which is set to cv2.RETR_TREE 
           the contour approximation method, which is set to cv2.CHAIN_APPROX_SIMPLE
           findContours returns two values: 
           contours, which is a Python list of all the contours in the image 
           hierarchy, which is an optional output vector containing information about the image topology'''

        # ---Find largest contour and fill it in to get mask for object of interest ---
        # if not contours:
        #     continue
        cnt = contours  # which is a Python list of all the contours in the image 
        # print('cnt = contours ', cnt)
        big_contour = np.array([])
        max = 0
        for i in cnt:  # cnt = contours  # which is a Python list of all the contours in the image 
            area = cv2.contourArea(i) #--- find the contour having biggest area ---
            if(area > max):
                max = area
                big_contour = i
        '''Essentially, the for loop is finding the contour with the largest area in the list cnt.'''

        # final = cv2.drawContours(image_rgb, big_contour, -1, (0,255,0), 3)
        # cv2.imshow('final', final)
        # cv2.waitKey(10)
        '''This code takes the largest contour found earlier and draws it onto the original image as a green line with a thickness of 3 pixels. 
           Then it displays the final image in a window named "final" for 10 milliseconds.'''

        # --- fill the largest contour (with white) to get mask for object of interest ---
        # print('th', th.shape)
        # pts=[big_contour]
        
        if  big_contour.any():
            # print('pts', type(pts))
            # print('pts', pts)
            final = cv2.fillPoly(th, pts=[big_contour], color=(255, 255, 255)) # th is the thresholded image. fillPoly() function of OpenCV is used to draw filled polygons like rectangle, triangle, pentagon over an image. This function takes inputs of an image and endpoints of Polygon and color
            
            # final = cv2.fillPoly(th, pts=[np.array(big_contour).astype(int)], color=(255, 255, 255))
            # final = cv2.fillPoly(th, pts=[np.array(big_contour).astype(np.int32).tolist()], color=(255, 255, 255))
            # final = cv2.fillPoly(th, pts=[np.array(big_contour).astype(np.int32).tolist()], color=(255, 255, 255))


            mask = final/final.max()
            bkg = maxval*(1.0 - mask)
            '''final is a binary image with the biggest contour filled with white color, and other pixels in black. The fillPoly() function fills a polygon 
            with a specified color. The polygon to be filled is defined by the big_contour list of points which represents the vertices of the contour. 
            After creating the final binary image, a mask image is created from final by dividing it by its maximum value. 
            The mask image contains values between 0 and 1, where 1 represents the pixels that belong to the biggest contour and 0 the ones that do not belong. 
            The bkg image is created by subtracting the mask image from 1, and then multiplying the result by the maximum value of the input image im. 
            The resulting image bkg is the same size as im and has high intensity in regions that do not belong to the biggest contour and low intensity in regions 
            that do.'''

            # Apply mask to original image
            img = im*mask + bkg  #Overall, this line of code is a simple way to composite an object onto a background using a binary mask
            '''The expression "im*mask" multiplies each pixel in "im" by the corresponding value in "mask". Where "mask" is 1 (white), 
            the corresponding pixel in "im" is retained. Where "mask" is 0 (black), the pixel in "im" is replaced by 0. The result of this multiplication is then 
            added to "bkg". This means that the pixels in "im" that were retained by the mask are superimposed onto the "bkg" image. 
            Where the mask was 0, the "bkg" image is retained. Finally, the resulting image is stored in the variable "img".'''


            # Threshold again to separate air from liquid
            # Remember EM is applied then we calculate th1 and th2 that separate air & water from other tissues

            ret, th_air = cv2.threshold(img,  th1, maxval, 0)  
            '''perform binary thresholding on the input image img using the threshold value th1. Pixels in img with a value greater than or equal to th1 will be 
            set to maxval, while pixels with a value less than th1 will be set to 0. The function returns the threshold value ret and the thresholded image th_air.'''

            ret, th_lqd = cv2.threshold(img, th2, maxval, 0)
            th = th_air + th_lqd.max() - th_lqd + bkg
            '''The expression th_lqd.max() - th_lqd is used to create a binary image where the pixels in the regions that have high intensity values are set to 0 (black), 
            and pixels in the regions that have low intensity values are set to 255 (white). The th_lqd image contains the pixels of the object of interest 
            (in this case, the liquid region), which have lower intensity values than the background. By subtracting th_lqd from th_lqd.max(), 
            we are essentially inverting the intensity values of the th_lqd image, so that the object of interest has the highest intensity values.'''

            '''In summary, the line of code th = th_air + th_lqd.max() - th_lqd + bkg creates a new binary image th by combining two binary images created from 
            the original image through thresholding, and adjusting the brightness of the resulting image (by aading the bkg). The resulting binary image th will 
            contain pixels that are "on" (value 1) in regions where the pixel values in either of the original binary images are above their respective thresholds.'''

            img = img - img.min()  
            '''This line subtracts the minimum pixel value in the input image img from all pixels in the image. This is done to ensure that the pixel values range 
            from 0 to the maximum possible value, which is useful for displaying the image.'''
            
            img = 255*(img/img.max()) 
            '''This line scales the pixel valuvoies in the input image img so that the maximum pixel value is 255. This is done to convert the image to an 8-bit grayscale image 
            that can be displayed easily.'''

            image_rgb = cv2.cvtColor(img.astype('uint8'), cv2.COLOR_GRAY2BGR)
            '''This line converts the grayscale image img to an RGB image image_rgb using the OpenCV cvtColor() function. The input image is first converted to 
            an 8-bit unsigned integer format (uint8) and then converted to RGB format.'''


            # Draw contours around object of interest
            th = 255 * (th / maxval)  # th = th_air + th_lqd.max() - th_lqd + bkg
            th = th.astype('uint8')
            contours, hierarchy = cv2.findContours(th.max() - th, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # th.max() - th is used as the binary image, which is essentially the inverted binary image
            out_img = np.zeros((th.shape[0], th.shape[1], 3), dtype='uint8')
            for contour in contours:
                '''In OpenCV, the first contour found is usually the background of the image. Therefore, to avoid processing the background contour, it is common to start 
                iterating through the contours from the second contour (index 1) in the contours list. That's why in the given code, contours[1:] is used instead of 
                contours[:]'''
                # if cv2.contourArea(contour) >  75 and cv2.contourArea(contour) < 40000: # Remember this was 75
                if cv2.contourArea(contour) >  0 and cv2.contourArea(contour) < 100000: # less than 512x512 to avoid image borders
                    '''75 is a threshold that determines the minimum area of a contour that will be considered an object of interest. In other words, only contours with 
                    an area greater than 75 pixels will be processed and displayed. '''
                    out_img = cv2.fillPoly(out_img, pts=[contour], color=(255, 255, 255))
                    image_rgb = cv2.drawContours(image_rgb, [contour], -1, (0, 0, 255), 1)
                    # img = (im*mask + bkg) - (im*mask + bkg).min -->img = 255*(img/img.max()) -->image_rgb = cv2.cvtColor(img.astype('uint8'), cv2.COLOR_GRAY2BGR)
            
            # Display image with contours                      # samir to facilitate code execution
            # cv2.imshow("slice", image_rgb)
            # cv2.setWindowTitle("slice","slice_%03d/%03d"%(ind, len(images)))
            # cv2.waitKey(10)
            
            
            ind+=1

            #TEST
            # Set plot title and axis labels
    
            # Show plot and clear figure for next iteration
            # plt.imshow(image_rgb)
            # plt.title("slice_%03d/%03d" % (ind, len(images)))
            # plt.show(block=False)
            # plt.pause(0.1)
            # plt.clf()

            # plt.figure(1)
            # plt.imshow(image_rgb)
            # plt.title("slice_%03d/%03d"%(ind, len(images)))
            # plt.show()  
            # plt.pause(0.1)
            # plt.clf()
            # plt.close(1)
            # ind += 1

            out.insert(j, out_img[:, :, 0])
            outputrgb.insert(j, image_rgb)
        else:
            out.insert(j, np.zeros((th.shape[0], th.shape[1]), dtype='uint8'))  # insert dumy image to represent image without contours
            outputrgb.insert(j, np.zeros((th.shape[0], th.shape[1], 3), dtype='uint8'))
 
    
    
    cv2.destroyAllWindows()

    # Return masks for all images
    # return np.asarray(out)
    return np.asarray(out), np.asarray(outputrgb)   # Saturday


# np.asarray(out)

    '''
    This function takes in a list of images and returns a processed version of those images. The processed version contains the region of interest (ROI) 
    for each image.
    For each image, the following processing steps are performed:

    Threshold the image to create a binary image using the maximum pixel value and a threshold value of -700.
    Convert the binary image to a color image.
    Find all contours in the binary image and find the contour with the largest area.
    Create a mask by filling in the area inside the contour with white and the area outside the contour with black.
    Subtract the minimum pixel value of the original image from the image, then scale the image to the range [0, 255].
    Threshold the image again to create two binary images: one for the air and one for the liquid.
    Add the two binary images together and subtract the result from the maximum pixel value to create a binary image of the ROI.
    Find all contours in the binary image of the ROI and fill in each contour with white if the area is greater than 75 pixels.
    Store the resulting ROI in a list and return it as a numpy array.
    The function also displays each image with its ROI and saves the processed images to disk (commented out in the code).'''

def get_voi(images, th1, th2):   
    # Apply EM to find m1, m2, m3, var1, var2, var3 --> plot distributions --> calculate: th1, th2 for ex: = -686.1965491372844,  150.33758439609892
    
    # seg_vol =get_voi(images=dicom_vol, th1=optimal_threshold1, th2=optimal_threshold2)
    out =[]
    outputrgb= []
    ind=1

    # from Ipython.display import display, clear_output
    # fig= plt.figure()
    # ax= fig.add_subplot(1, 1, 1)
    
    for j,im in enumerate(images): # loop over all slices in DICOM volume dicom_vol
    # for im in images: # loop over all slices in DICOM volume dicom_vol
        # image_gray = cv2.medianBlur(im, 5)
        # print(im.index)
        # if j>140 and j<180:
        #     print()
        maxval = images.max() # finding the maximum value in an array of images.
        # print('maxval', maxval)
        # --- Binarize image using threshold th1 which is calculated from parameters calculated from EM. th1 separates first probability distributions---
        ret, th = cv2.threshold(im, th1, maxval, 0)        # th = cv2.adaptiveThreshold(image_gray,255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 5, 1)
        '''thresholding the input image (im) using a fixed threshold value (e.g., of -686.1965491372844) Hounsfield units and maximum pixel value (maxval) 
           with cv2.threshold() function.'''

        th = 255*(th / maxval) 
        '''Normalizing the thresholded image to be in the range of 0-255 with a data type of unsigned integer 8-bit'''

        th = th.astype('uint8') 
        ''' Changing the data type of the normalized image to unsigned integer 8-bit.'''
        # print('th.shape', th.shape)
        image_rgb = cv2.cvtColor(th, cv2.COLOR_GRAY2BGR)      # Convert binary image to RGB for drawing contours
        '''Converting the normalized grayscale image into a 3-channel color image (RGB) with cv2.cvtColor() function to draw contours on it.'''

        #--- Find all the contours in the binary image ---
        contours, hierarchy = cv2.findContours(th, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        '''This line finds all the contours in the binary image, th, using the OpenCV findContours function. findContours takes three arguments:
           the binary image, th 
           the contour retrieval mode, which is set to cv2.RETR_TREE 
           the contour approximation method, which is set to cv2.CHAIN_APPROX_SIMPLE
           findContours returns two values: 
           contours, which is a Python list of all the contours in the image 
           hierarchy, which is an optional output vector containing information about the image topology'''

        # ---Find largest contour and fill it in to get mask for object of interest ---
        # if not contours:
        #     continue
        cnt = contours  # which is a Python list of all the contours in the image 
        # print('cnt = contours ', cnt)
        big_contour = np.array([])
        max = 0
        for i in cnt:  # cnt = contours  # which is a Python list of all the contours in the image 
            area = cv2.contourArea(i) #--- find the contour having biggest area ---
            if(area > max):
                max = area
                big_contour = i
        '''Essentially, the for loop is finding the contour with the largest area in the list cnt.'''

        # final = cv2.drawContours(image_rgb, big_contour, -1, (0,255,0), 3)
        # cv2.imshow('final', final)
        # cv2.waitKey(10)
        '''This code takes the largest contour found earlier and draws it onto the original image as a green line with a thickness of 3 pixels. 
           Then it displays the final image in a window named "final" for 10 milliseconds.'''

        # --- fill the largest contour (with white) to get mask for object of interest ---
        # print('th', th.shape)
        # pts=[big_contour]
        
        if  big_contour.any():
            # print('pts', type(pts))
            # print('pts', pts)
            final = cv2.fillPoly(th, pts=[big_contour], color=(255, 255, 255)) # th is the thresholded image. fillPoly() function of OpenCV is used to draw filled polygons like rectangle, triangle, pentagon over an image. This function takes inputs of an image and endpoints of Polygon and color
            
            # final = cv2.fillPoly(th, pts=[np.array(big_contour).astype(int)], color=(255, 255, 255))
            # final = cv2.fillPoly(th, pts=[np.array(big_contour).astype(np.int32).tolist()], color=(255, 255, 255))
            # final = cv2.fillPoly(th, pts=[np.array(big_contour).astype(np.int32).tolist()], color=(255, 255, 255))


            mask = final/final.max()
            bkg = maxval*(1.0 - mask)
            '''final is a binary image with the biggest contour filled with white color, and other pixels in black. The fillPoly() function fills a polygon 
            with a specified color. The polygon to be filled is defined by the big_contour list of points which represents the vertices of the contour. 
            After creating the final binary image, a mask image is created from final by dividing it by its maximum value. 
            The mask image contains values between 0 and 1, where 1 represents the pixels that belong to the biggest contour and 0 the ones that do not belong. 
            The bkg image is created by subtracting the mask image from 1, and then multiplying the result by the maximum value of the input image im. 
            The resulting image bkg is the same size as im and has high intensity in regions that do not belong to the biggest contour and low intensity in regions 
            that do.'''

            # Apply mask to original image
            img = im*mask + bkg  #Overall, this line of code is a simple way to composite an object onto a background using a binary mask
            '''The expression "im*mask" multiplies each pixel in "im" by the corresponding value in "mask". Where "mask" is 1 (white), 
            the corresponding pixel in "im" is retained. Where "mask" is 0 (black), the pixel in "im" is replaced by 0. The result of this multiplication is then 
            added to "bkg". This means that the pixels in "im" that were retained by the mask are superimposed onto the "bkg" image. 
            Where the mask was 0, the "bkg" image is retained. Finally, the resulting image is stored in the variable "img".'''


            # Threshold again to separate air from liquid
            # Remember EM is applied then we calculate th1 and th2 that separate air & water from other tissues

            ret, th_air = cv2.threshold(img,  th1, maxval, 0)  
            '''perform binary thresholding on the input image img using the threshold value th1. Pixels in img with a value greater than or equal to th1 will be 
            set to maxval, while pixels with a value less than th1 will be set to 0. The function returns the threshold value ret and the thresholded image th_air.'''

            ret, th_lqd = cv2.threshold(img, th2, maxval, 0)
            th = th_air + th_lqd.max() - th_lqd + bkg
            '''The expression th_lqd.max() - th_lqd is used to create a binary image where the pixels in the regions that have high intensity values are set to 0 (black), 
            and pixels in the regions that have low intensity values are set to 255 (white). The th_lqd image contains the pixels of the object of interest 
            (in this case, the liquid region), which have lower intensity values than the background. By subtracting th_lqd from th_lqd.max(), 
            we are essentially inverting the intensity values of the th_lqd image, so that the object of interest has the highest intensity values.'''

            '''In summary, the line of code th = th_air + th_lqd.max() - th_lqd + bkg creates a new binary image th by combining two binary images created from 
            the original image through thresholding, and adjusting the brightness of the resulting image (by aading the bkg). The resulting binary image th will 
            contain pixels that are "on" (value 1) in regions where the pixel values in either of the original binary images are above their respective thresholds.'''

            img = img - img.min()  
            '''This line subtracts the minimum pixel value in the input image img from all pixels in the image. This is done to ensure that the pixel values range 
            from 0 to the maximum possible value, which is useful for displaying the image.'''
            
            img = 255*(img/img.max()) 
            '''This line scales the pixel valuvoies in the input image img so that the maximum pixel value is 255. This is done to convert the image to an 8-bit grayscale image 
            that can be displayed easily.'''

            image_rgb = cv2.cvtColor(img.astype('uint8'), cv2.COLOR_GRAY2BGR)
            '''This line converts the grayscale image img to an RGB image image_rgb using the OpenCV cvtColor() function. The input image is first converted to 
            an 8-bit unsigned integer format (uint8) and then converted to RGB format.'''


            # Draw contours around object of interest
            th = 255 * (th / maxval)  # th = th_air + th_lqd.max() - th_lqd + bkg
            th = th.astype('uint8')
            contours, hierarchy = cv2.findContours(th.max() - th, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # th.max() - th is used as the binary image, which is essentially the inverted binary image
            out_img = np.zeros((th.shape[0], th.shape[1], 3), dtype='uint8')
            for contour in contours:
                '''In OpenCV, the first contour found is usually the background of the image. Therefore, to avoid processing the background contour, it is common to start 
                iterating through the contours from the second contour (index 1) in the contours list. That's why in the given code, contours[1:] is used instead of 
                contours[:]'''
                # if cv2.contourArea(contour) >  75 and cv2.contourArea(contour) < 40000: # Remember this was 75
                if cv2.contourArea(contour) >  0 and cv2.contourArea(contour) < 100000: # less than 512x512 to avoid image borders
                    '''75 is a threshold that determines the minimum area of a contour that will be considered an object of interest. In other words, only contours with 
                    an area greater than 75 pixels will be processed and displayed. '''
                    out_img = cv2.fillPoly(out_img, pts=[contour], color=(255, 255, 255))
                    image_rgb = cv2.drawContours(image_rgb, [contour], -1, (0, 0, 255), 1)
                    # img = (im*mask + bkg) - (im*mask + bkg).min -->img = 255*(img/img.max()) -->image_rgb = cv2.cvtColor(img.astype('uint8'), cv2.COLOR_GRAY2BGR)
            
            # Display image with contours                      # samir to facilitate code execution
            # cv2.imshow("slice", image_rgb)
            # cv2.setWindowTitle("slice","slice_%03d/%03d"%(ind, len(images)))
            # cv2.waitKey(10)
            
            
            ind+=1

            #TEST
            # Set plot title and axis labels
    
            # Show plot and clear figure for next iteration
            # plt.imshow(image_rgb)
            # plt.title("slice_%03d/%03d" % (ind, len(images)))
            # plt.show(block=False)
            # plt.pause(0.1)
            # plt.clf()

            # plt.figure(1)
            # plt.imshow(image_rgb)
            # plt.title("slice_%03d/%03d"%(ind, len(images)))
            # plt.show()  
            # plt.pause(0.1)
            # plt.clf()
            # plt.close(1)
            # ind += 1

            out.insert(j, out_img[:, :, 0])
            outputrgb.insert(j, image_rgb)
        else:
            out.insert(j, np.zeros((th.shape[0], th.shape[1]), dtype='uint8'))  # insert dumy image to represent image without contours
            outputrgb.insert(j, np.zeros((th.shape[0], th.shape[1], 3), dtype='uint8'))
 
    
    
    cv2.destroyAllWindows()

    # Return masks for all images
    # return np.asarray(out)
    return np.asarray(out), np.asarray(outputrgb)   # Saturday


# np.asarray(out)

    '''
    This function takes in a list of images and returns a processed version of those images. The processed version contains the region of interest (ROI) 
    for each image.
    For each image, the following processing steps are performed:

    Threshold the image to create a binary image using the maximum pixel value and a threshold value of -700.
    Convert the binary image to a color image.
    Find all contours in the binary image and find the contour with the largest area.
    Create a mask by filling in the area inside the contour with white and the area outside the contour with black.
    Subtract the minimum pixel value of the original image from the image, then scale the image to the range [0, 255].
    Threshold the image again to create two binary images: one for the air and one for the liquid.
    Add the two binary images together and subtract the result from the maximum pixel value to create a binary image of the ROI.
    Find all contours in the binary image of the ROI and fill in each contour with white if the area is greater than 75 pixels.
    Store the resulting ROI in a list and return it as a numpy array.
    The function also displays each image with its ROI and saves the processed images to disk (commented out in the code).'''

def graph_cut_volume(seg_vol, m1, m2, var1, var2, coef1, coef2, gamma_factor):
    '''Read DICOM volume to dicom_vol --> apply EM (to get  m2, m1, var2, var1, coef2, coef1) --> apply voi (to get seg_vol) 
    --> apply graph_cut_volume (to get seg_mask_vol)
    dicom_vol: orignal DICOM volume before any thresholding
    seg_vol: orignal DICOM volume after thresholding/separating air (threshold1) and water (threshold2)
    m2, m1, var2, var1, coef2, coef1: EM parameters for the two main classes (colon: air + water & noncolon: rest tissues)'''

    # Initialize the output mask volume with zeros.
    seg_mask_vol = np.zeros_like(seg_vol)

    # Loop over the slices of the volume.
    for i in range(seg_vol.shape[0]):  #  seg_vol.shape shape is 476 x 255 x 255
    # for i in range(len(seg_vol)): # 329x255x255   seg_vol is list

        f_neq, T = relative_frequency_of_different_labels(seg_vol[i])
        gamma= gamma_estimation(f_neq, number_of_classes=2)
        # print(gamma)
        # img2= graph_cut_em(seg_vol[i], m1, m2, var1, var2, coef1, coef2, gamma, gamma_factor)   #graph_cut_dicom
        img2= graph_cut_4m_em(seg_vol[i], gamma, gamma_factor)
        # (binary_img,  m1, m2, var1, var2, coef1, coef2, gamma, gamma_factor): 
        # img2= graph_cut_em(seg_vol[i], gamma, gamma_factor)
        # graph_cut_em(binary_img, m1, var1, coef1, gamma, gamma_factor):
        # img2, Capacities_of_edges_to_sink_node, Capacities_of_edges_from_source_node= graph_cut_dicom(dicom_vol[i], m1, m2, var1, var2, coef1, coef2, gamma, gamma_factor)

        seg_mask_vol[i] = img2

    return seg_mask_vol

def grow(img, seed, t):   #img is the volume seg_mask_vol, for instance
    """
    img: ndarray, ndim=3
        An image volume.
    
    seed: tuple, len=3
        Region growing starts from this point.

    t: int
        The image neighborhood radius for the inclusion criteria.
    """
    seg = np.zeros(img.shape, dtype=bool)  # Initialize 'segmentation' to boolean volume, same shape as 'image'.
    checked = np.zeros_like(seg)           # Initialize 'checked' to a boolean volume, same shape as 'segmentation'.
    
    # Set 'segmentation' and 'checked' at 'seed' to true.
    seg[seed] = True
    checked[seed] = True

    # Add neighbor coordinates of 'seed' to 'needs_check'.
    needs_check = get_nbhd(seed, checked, img.shape)
    
    '''This function adds neighboring voxels when necessary. It accepts the current voxel (pt), the indicator array of checked points (checked), and the dimensions of the volume (img.shape). The checked indicator is of course necessary so we don’t add points that have already been checked, and the volume dimensions argument is necessary so we don’t add points beyond the image borders.'''

    while len(needs_check) > 0: # while 'needs_check' is not empty:

        pt = needs_check.pop() # Pop 'point' from 'needs_check'.   store the last element of needs_check to pt
        
        # Its possible that the point was already checked and was
        # put in the needs_check stack multiple times.
        if checked[pt]: continue

        checked[pt] = True  # Set 'checked' at 'point' to true.

        # Handle borders.
        imin = max(pt[0]-t, 0)
        imax = min(pt[0]+t, img.shape[0]-1)
        jmin = max(pt[1]-t, 0)
        jmax = min(pt[1]+t, img.shape[1]-1)
        kmin = max(pt[2]-t, 0)
        kmax = min(pt[2]+t, img.shape[2]-1)

        # if the average of 'image' over 'neighborhood_size' distance from 'point' is greater than or equal to the value of 'image' at 'point'
        # then:
        # 1) Set 'segmentation' to true at 'point'. 2) Add neighbor coordinates of 'point' to 'needs_check'.
    
        if img[pt] >= img[imin:imax+1, jmin:jmax+1, kmin:kmax+1].mean():
            # Include the voxel in the segmentation and
            # add its neighbors to be checked.
            seg[pt] = True
            needs_check += get_nbhd(pt, checked, img.shape)

    return seg

def get_nbhd(pt, checked, dims):
    nbhd = []

    if (pt[0] > 0) and not checked[pt[0]-1, pt[1], pt[2]]:
        nbhd.append((pt[0]-1, pt[1], pt[2]))
    if (pt[1] > 0) and not checked[pt[0], pt[1]-1, pt[2]]:
        nbhd.append((pt[0], pt[1]-1, pt[2]))
    if (pt[2] > 0) and not checked[pt[0], pt[1], pt[2]-1]:
        nbhd.append((pt[0], pt[1], pt[2]-1))

    if (pt[0] < dims[0]-1) and not checked[pt[0]+1, pt[1], pt[2]]:
        nbhd.append((pt[0]+1, pt[1], pt[2]))
    if (pt[1] < dims[1]-1) and not checked[pt[0], pt[1]+1, pt[2]]:
        nbhd.append((pt[0], pt[1]+1, pt[2]))
    if (pt[2] < dims[2]-1) and not checked[pt[0], pt[1], pt[2]+1]:
        nbhd.append((pt[0], pt[1], pt[2]+1))

    return nbhd

def make_mesh(image, threshold=-300, step_size=1, spacing=(1, 1, 1)):
# def make_mesh(image, threshold=-300, step_size=1, spacing=(1/0.664, 1/0.664, 1.25)):
    p = image.transpose(2, 1, 0)
    verts, faces, norm, val = measure.marching_cubes(p, threshold, spacing=spacing, step_size=step_size, allow_degenerate=True, method='lewiner')
    # verts, faces, norm, val = measure.marching_cubes_lewiner(p, threshold, spacing=spacing, step_size=step_size, allow_degenerate=True)
    colon_mesh = mesh.Mesh(np.zeros(faces.shape[0], dtype=mesh.Mesh.dtype))
    for i, f in enumerate(faces):
        for j in range(3):
            colon_mesh.vectors[i][j] = verts[f[j], :]
    return colon_mesh

def meshprocess(fname):
    """
    Split a mesh by connectivity and order the pieces
    by increasing area.
    """
    # Print a description of the function
    # print(__doc__)

    # Load the mesh from the specified file
    em = load(fname)
    # print('samir', em)
    # Smooth the mesh using Laplacian smoothing
    eml = em.clone().smoothLaplacian()

    # Split the mesh into connected components, up to a maximum depth of 550000
    # splitem = vtkplt.splitByConnectivity(eml, maxdepth=550000)[:4]

    # Return the split and sorted mesh components
    return eml
    # return eml, splitem

def save_volume_slices(output_path, volume):# Save each slice as an individual image
    try:
        os.mkdir(output_path)
    except:
        # print('Output directory already exists!')
        # print('Output directory already exists!')
        pass
    for i in range(volume.shape[0]):
        slice_name = f"slice_{make_three_digits(i)}.png"
        filename = os.path.join(output_path, slice_name)
        plt.imshow(volume[i,:,:], cmap='gray')
        im = Img.fromarray(volume[i,:,:])
        im.save(filename)
        plt.title('Slice %d' % i)
        # plt.savefig(filename)
        # print("Saved slice %d as %s" % (i, slice_name))
        plt.close()

def make_three_digits(number): 
    number_str = str(number)
    if len(number_str) < 3:
        number_str = number_str.zfill(3)
    return number_str

# function for calculating f_neq(f) in eq(29):
def relative_frequency_of_different_labels(initially_labbeled_image_f): # Remember: initially_labbeled_image_f is the initially labeled image by EM algorithm (for example) 
 
    count = 0 # count number of different/unequal labels
    T=0       # count number of neighboring check (same and diffrent labeling)
    # padding to 

    for row in range(1, initially_labbeled_image_f.shape[0]-1, 1):       
        for col in range(1, initially_labbeled_image_f.shape[1]-1, 1): 
            # Access the pixel at position (row, col)  # label of pixel
            pixel = initially_labbeled_image_f[row, col]
            
            ''' To check that every pixel has the same label as its neighbors in the first-order neighboring system, you can use the following approach:
            Check if the pixel has the same label as its neighbors (4 in 1st order neighborhood system)
            '''
            left = initially_labbeled_image_f[row, col-1]
            top = initially_labbeled_image_f[row-1, col]
            right = initially_labbeled_image_f[row, col+1]
            bottom = initially_labbeled_image_f[row+1, col]

            # Check if the neighboring pixels have the same label as the current pixel
            if left != pixel:
                count += 1
                T+=1
            else:
                T+=1
                
            if top != pixel:
                count += 1
                T+=1
            else:
                T+=1

            if right != pixel:
                count += 1
                T+=1
            else:
                T+=1

            if bottom != pixel:
                count += 1
                T+=1
            else:
                T+=1
            # Or T+=4
    f_neq= count/T
    return f_neq, T # T just to investigate its value; it is not included in any calculations

def gamma_estimation(f_neq, number_of_classes=2):  # f_eq: relative frequency of the equal labels in the pixel pairs
    gamma= ((number_of_classes**2)/(number_of_classes-1)) * (((number_of_classes-1)/number_of_classes) - f_neq)
    return gamma

def graph_cut_4m_em(binary_img, gamma, gamma_factor=1):  # result of EM + voi
    eps = np.finfo(float).eps

    # Calculate weights for edges from source to each pixel
    val = binary_img

    capacities_from_source = np.abs(val.flatten().astype(float) - 255)
    capacities_from_source = capacities_from_source.reshape(val.shape[0], val.shape[1])

    # capacities_to_sink = np.abs(val.flatten().astype(float) - 0)
    # capacities_to_sink = capacities_to_sink.reshape(val.shape[0], val.shape[1])


    # Calculate weights for edges from each pixel to sink
    
    capacities_to_sink = np.abs(0 - val.flatten().astype(float))
    capacities_to_sink = capacities_to_sink.reshape(val.shape[0], val.shape[1])

#######################################################################
    # Create the graph
    g = maxflow.Graph[int]()
    nodeids = g.add_grid_nodes(binary_img.shape)

    # Add non-terminal edges between each adjacent pair of pixels
    height, width = binary_img.shape
    for y in range(height):
        for x in range(width):
            if x > 0:
                if binary_img[y, x] != binary_img[y, x-1]:
                    g.add_edge(nodeids[y, x], nodeids[y, x - 1], gamma*gamma_factor, gamma*gamma_factor)
                else:
                    g.add_edge(nodeids[y, x], nodeids[y, x - 1], 1, 1)
           
            if y > 0:
                if binary_img[y, x]!= binary_img[y-1, x]:
                    g.add_edge(nodeids[y, x], nodeids[y - 1, x], gamma*gamma_factor, gamma*gamma_factor)
                else:
                    g.add_edge(nodeids[y, x], nodeids[y - 1, x], 1, 1)  
   
    ''' we loop over each pixel in the image and add non-terminal edges to its adjacent pixels. 
        The weight of each edge is proportional to the absolute difference in intensity values between the two pixels, multiplied by a scaling factor gamma. 
        These edges are added using the add_edge method of the maxflow.Graph object.'''
    
    # Add terminal edges
    g.add_grid_tedges(nodeids, capacities_from_source, capacities_to_sink)

    # Find the maximum flow
    g.maxflow()

    # Get the segments of the nodes in the grid
    sgm = g.get_grid_segments(nodeids)

    # Convert segments to image
    img2 = sgm.astype(np.uint8) * 255
    # img1 = np.logical_not(sgm).astype(np.uint8) * 0

    # return img2+img1
    return img2

